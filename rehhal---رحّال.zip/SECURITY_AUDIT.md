# SECURITY_AUDIT — تقرير المراجعة الأمنية للمنصة (REHHAL · رحّال)

تاريخ التدقيق: 2026-11-26  
نطاق المراجعة: الخادم (`server.ts`)، قواعد البيانات (`firestore.rules`)، الواجهة الأمامية (`src/`)، تخزين المتصفح و`Service Worker`، وإعدادات البناء والتوثيق (`public/.well-known/assetlinks.json`).

---

## 1. ملخص التدقيق والإصلاحات المطبقة

| مجال الفحص | النتيجة | الحالة والتفاصيل |
| :--- | :--- | :--- |
| ترويسات الأمان في الخادم (`server.ts`) | **PASS (تم الإصلاح والتحقق)** | تم تعطيل `X-Powered-By` وإضافة `X-Content-Type-Options: nosniff` و`Referrer-Policy: strict-origin-when-cross-origin` و`Permissions-Policy` و`Strict-Transport-Security` عند الاتصال عبر HTTPS (دون كسر إطار المعاينة بـ `X-Frame-Options`). |
| حماية نقاط نهاية الدفع والإحالات على الخادم (`/api/payments/authorize` و`/api/referrals/register`) | **PASS (تم الإصلاح والتحقق)** | تم إضافة تحقق تشفيري لرمز هوية Firebase (`Authorization: Bearer`) عبر شهادات Google العامة؛ يرفض الخادم الآن أي طلب غير مصادق (`401`) أو لا يطابق هوية صاحب الحجز/المسوّق (`403`) أو بعملة غير `EGP` (`400`)، كما يتحقق الخادم من سجلات `referral_codes` مباشرة من Firestore. |
| أمان Service Worker وCache المتصفح | **PASS (تم الإصلاح والتحقق)** | يستبعد `public/service-worker.js` طلبات `POST`، وكافة نطاقات Firebase/Google Auth، ومسارات `/api/` و`/__/` و`/.well-known/` و`/login` و`/my-bookings` و`/profile` و`/booking/` و`/partners` و`/admin`. لا تُخزّن بيانات حجوزات أو عمولات أو مدفوعات أو مفاتيح جلسة داخل Cache أو `localStorage`. |
| قواعد أمان Firestore (`firestore.rules`) | **PASS (منشورة ومختبرة)** | تفصل القواعد قراءة وتعديل المستخدمين والحجوزات والمسوقين والعمولات وطلبات السحب وطلبات التواصل لصاحب السجل أو المشرف الموثق فقط، وتفرض `currency == 'EGP'` عند إنشاء الحجوزات والعمولات وطلبات السحب، وتقصر تقييم الرحلات على الحجوزات المكتملة (`status == 'completed'`). |
| الأسرار ومفاتيح التوقيع | **PASS** | لا توجد مفاتيح سرية أو كلمات مرور أو ملفات `.keystore` أو بصمات `SHA-256` وهمية داخل الكود المصدري أو الواجهة الأمامية. يعتمد توقيع الإحالة HMAC على `process.env.REFERRAL_HMAC_SECRET` على الخادم فقط مع بديل عشوائي مؤقت بالذاكرة. |
| حقن HTML ومحتوى مختلط (`XSS` / `Mixed Content`) | **PASS** | لم يُرصد أي استخدام لـ `dangerouslySetInnerHTML` أو `innerHTML` أو `document.write` أو روابط `href="#"`. جميع الروابط الخارجية تُفحص ببروتوكول `http:`/`https:` مع `rel="noopener noreferrer"`. |
| تدقيق الاعتماديات (`bun audit`) | **ملاحظة متابعة (Transitive)** | أظهر فحص `bun audit` أربعة تنبيهات انتقالية في حزم تابعة (`@grpc/grpc-js` داخل `firebase`، و`glob` / `minimatch` داخل `vite-plugin-pwa` و`eslint`). لا توجد مسارات استغلال مباشرة في كود التطبيق أو الخادم، ويُوصى بتحديث `firebase` و`eslint` في دورة ترقية الاعتماديات المجدولة. |

---

## 2. توصيات ما قبل الإطلاق الإنتاجي

1. تعيين متغير البيئة السري `REFERRAL_HMAC_SECRET` في إعدادات الخادم الإنتاجي حتى لا تتغير بصمة التحقق عند إعادة تشغيل الخادم.
2. تعيين `ANDROID_PACKAGE_NAME` و`ANDROID_SHA256_FINGERPRINT` الحقيقية من Google Play App Signing قبل تفعيل الـ TWA.
3. مراجعة `firestore.rules` ودورية تدوير صلاحيات المشرفين قبل مشاركة المنصة على نطاق واسع.
