import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import type { Request, Response } from 'express';

const PORT = Number(process.env.PORT) || 3000;
const IS_PROD = process.env.NODE_ENV === 'production';
const ROOT_DIR = process.cwd();

// Load Firebase project/database IDs for public referral code server verification
interface FirebaseAppletConfig {
  projectId: string;
  firestoreDatabaseId: string;
}

let firebaseConfig: FirebaseAppletConfig = {
  projectId: '',
  firestoreDatabaseId: '(default)',
};

try {
  const cfgRaw = fs.readFileSync(path.resolve(ROOT_DIR, 'firebase-applet-config.json'), 'utf8');
  const parsed = JSON.parse(cfgRaw) as Partial<FirebaseAppletConfig>;
  if (parsed.projectId) {
    firebaseConfig = {
      projectId: parsed.projectId,
      firestoreDatabaseId: parsed.firestoreDatabaseId || '(default)',
    };
  }
} catch {
  // Fallback if config not present
}

const REFERRAL_HMAC_SECRET =
  process.env.REFERRAL_HMAC_SECRET || crypto.randomBytes(32).toString('hex');

interface ReferralRecord {
  code: string;
  marketerId: string;
  marketerName: string;
  commissionRate: number;
  active: boolean;
}

interface ClickLogEntry {
  sessionKey: string;
  code: string;
  tripId: string;
  timestamp: number;
}

// In-memory deduplicated click store & verified referral cache
const clickDedupeSet = new Set<string>();
const clickCountsByCode = new Map<string, number>();
const clickHistory: ClickLogEntry[] = [];
const localReferralRegistry = new Map<string, ReferralRecord>();

// Pre-seeded curated partner referral codes for offline/catalog demo parity
localReferralRegistry.set('REHHAL101', {
  code: 'REHHAL101',
  marketerId: 'partner_demo_101',
  marketerName: 'شريك رحّال المعتمد',
  commissionRate: 0.08,
  active: true,
});

// --- Firebase ID Token Verification (RS256 against Google public x509 certs, zero IAM required) ---
const GOOGLE_CERTS_URL =
  'https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com';
let cachedGoogleCerts: Record<string, string> = {};
let certsExpiresAt = 0;

async function getGooglePublicCerts(): Promise<Record<string, string>> {
  if (Date.now() < certsExpiresAt && Object.keys(cachedGoogleCerts).length > 0) {
    return cachedGoogleCerts;
  }
  const res = await fetch(GOOGLE_CERTS_URL);
  if (!res.ok) {
    throw new Error('Failed to fetch Firebase public certificates');
  }
  const cacheControl = res.headers.get('cache-control') || '';
  const maxAgeMatch = cacheControl.match(/max-age=(\d+)/i);
  const maxAgeSec = maxAgeMatch ? Number(maxAgeMatch[1]) : 3600;
  cachedGoogleCerts = (await res.json()) as Record<string, string>;
  certsExpiresAt = Date.now() + maxAgeSec * 1000;
  return cachedGoogleCerts;
}

interface VerifiedFirebaseToken {
  uid: string;
  email?: string;
  emailVerified: boolean;
}

function decodeBase64Url(input: string): Buffer {
  const normalized = input.replace(/-/g, '+').replace(/_/g, '/');
  const padLen = (4 - (normalized.length % 4)) % 4;
  return Buffer.from(normalized + '='.repeat(padLen), 'base64');
}

async function verifyFirebaseBearerToken(req: Request): Promise<VerifiedFirebaseToken | null> {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const token = authHeader.slice(7).trim();
  const segments = token.split('.');
  if (segments.length !== 3) return null;

  try {
    const header = JSON.parse(decodeBase64Url(segments[0]).toString('utf8')) as {
      alg?: string;
      kid?: string;
    };
    const payload = JSON.parse(decodeBase64Url(segments[1]).toString('utf8')) as {
      aud?: string;
      iss?: string;
      sub?: string;
      email?: string;
      email_verified?: boolean;
      exp?: number;
      iat?: number;
    };

    if (header.alg !== 'RS256' || !header.kid) return null;
    if (!firebaseConfig.projectId) return null;
    if (payload.aud !== firebaseConfig.projectId) return null;
    if (payload.iss !== `https://securetoken.google.com/${firebaseConfig.projectId}`) return null;
    if (!payload.sub || typeof payload.sub !== 'string') return null;

    const nowSec = Math.floor(Date.now() / 1000);
    if (typeof payload.exp !== 'number' || payload.exp <= nowSec) return null;
    if (typeof payload.iat !== 'number' || payload.iat > nowSec + 300) return null;

    const certs = await getGooglePublicCerts();
    const certPem = certs[header.kid];
    if (!certPem) return null;

    const signingInput = Buffer.from(`${segments[0]}.${segments[1]}`, 'utf8');
    const signature = decodeBase64Url(segments[2]);
    const valid = crypto.verify('RSA-SHA256', signingInput, certPem, signature);
    if (!valid) return null;

    return {
      uid: payload.sub,
      email: payload.email,
      emailVerified: Boolean(payload.email_verified),
    };
  } catch {
    return null;
  }
}

function isValidReferralCodeFormat(code: string): boolean {
  return /^[A-Z0-9_\-]{3,32}$/.test(code);
}

function signReferralAttribution(payload: {
  code: string;
  marketerId: string;
  commissionRate: number;
  issuedAt: number;
}): string {
  const body = `${payload.code}|${payload.marketerId}|${payload.commissionRate}|${payload.issuedAt}`;
  const sig = crypto.createHmac('sha256', REFERRAL_HMAC_SECRET).update(body).digest('hex');
  return `${payload.issuedAt}.${sig}`;
}

function verifyReferralSignature(
  code: string,
  marketerId: string,
  commissionRate: number,
  token: string
): boolean {
  const parts = token.split('.');
  if (parts.length !== 2) return false;
  const issuedAt = Number(parts[0]);
  if (!Number.isFinite(issuedAt)) return false;
  const expected = signReferralAttribution({ code, marketerId, commissionRate, issuedAt });
  const a = Buffer.from(token);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

async function resolveReferralCodeOnServer(rawCode: string): Promise<ReferralRecord | null> {
  const code = rawCode.trim().toUpperCase();
  if (!isValidReferralCodeFormat(code)) return null;

  // 1. Check Firestore public referral_codes/{code} via REST API (authoritative)
  if (firebaseConfig.projectId) {
    try {
      const dbId = encodeURIComponent(firebaseConfig.firestoreDatabaseId);
      const docUrl = `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(
        firebaseConfig.projectId
      )}/databases/${dbId}/documents/referral_codes/${encodeURIComponent(code)}`;
      const res = await fetch(docUrl);
      if (res.ok) {
        const docJson = (await res.json()) as {
          fields?: {
            code?: { stringValue?: string };
            marketerId?: { stringValue?: string };
            marketerName?: { stringValue?: string };
            commissionRate?: { doubleValue?: number; integerValue?: string };
            active?: { booleanValue?: boolean };
          };
        };
        const fields = docJson.fields;
        if (fields && fields.marketerId?.stringValue) {
          const isActive = fields.active?.booleanValue ?? true;
          const record: ReferralRecord = {
            code: fields.code?.stringValue || code,
            marketerId: fields.marketerId.stringValue,
            marketerName: fields.marketerName?.stringValue || 'شريك رحّال',
            commissionRate:
              fields.commissionRate?.doubleValue ??
              (fields.commissionRate?.integerValue ? Number(fields.commissionRate.integerValue) : 0.08),
            active: isActive,
          };
          localReferralRegistry.set(code, record);
          return isActive ? record : null;
        }
      }
    } catch {
      // Fall back to local cache if network transient
    }
  }

  return localReferralRegistry.get(code) ?? null;
}

async function startServer() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', true);
  app.use(express.json({ limit: '256kb' }));

  // Baseline browser security headers (keeps AI Studio iframe preview functional)
  app.use((req: Request, res: Response, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    if (req.secure || req.headers['x-forwarded-proto'] === 'https') {
      res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    }
    next();
  });

  // Serve /.well-known/assetlinks.json with explicit application/json MIME type
  app.get('/.well-known/assetlinks.json', (_req: Request, res: Response) => {
    const pkg = process.env.ANDROID_PACKAGE_NAME || 'com.rehhal.app';
    const envFingerprint = (process.env.ANDROID_SHA256_FINGERPRINT || '').trim();
    if (envFingerprint) {
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Cache-Control', 'public, max-age=300');
      res.json([
        {
          relation: ['delegate_permission/common.handle_all_urls'],
          target: {
            namespace: 'android_app',
            package_name: pkg,
            sha256_cert_fingerprints: [envFingerprint],
          },
        },
      ]);
      return;
    }

    const staticAssetLinksPath = path.resolve(ROOT_DIR, 'public/.well-known/assetlinks.json');
    if (fs.existsSync(staticAssetLinksPath)) {
      res.setHeader('Content-Type', 'application/json');
      res.sendFile(staticAssetLinksPath);
      return;
    }

    res.status(404).json({ error: 'assetlinks.json not found' });
  });

  // Explicit MIME types for PWA core files (primary /manifest.webmanifest + /manifest.json alias)
  app.get('/manifest.webmanifest', (_req: Request, res: Response) => {
    res.setHeader('Content-Type', 'application/manifest+json; charset=utf-8');
    res.setHeader('Cache-Control', 'public, max-age=300');
    const p = IS_PROD
      ? path.resolve(ROOT_DIR, 'dist/manifest.webmanifest')
      : path.resolve(ROOT_DIR, 'public/manifest.webmanifest');
    res.sendFile(p);
  });

  app.get('/manifest.json', (_req: Request, res: Response) => {
    res.setHeader('Content-Type', 'application/manifest+json; charset=utf-8');
    res.setHeader('Cache-Control', 'public, max-age=300');
    const p = IS_PROD
      ? path.resolve(ROOT_DIR, 'dist/manifest.webmanifest')
      : path.resolve(ROOT_DIR, 'public/manifest.webmanifest');
    res.sendFile(p);
  });

  app.get('/service-worker.js', (_req: Request, res: Response) => {
    res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    res.setHeader('Service-Worker-Allowed', '/');
    res.setHeader('Cache-Control', 'no-cache');
    const p = IS_PROD
      ? path.resolve(ROOT_DIR, 'dist/service-worker.js')
      : path.resolve(ROOT_DIR, 'public/service-worker.js');
    res.sendFile(p);
  });

  app.get('/offline.html', (_req: Request, res: Response) => {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    const p = IS_PROD
      ? path.resolve(ROOT_DIR, 'dist/offline.html')
      : path.resolve(ROOT_DIR, 'public/offline.html');
    res.sendFile(p);
  });

  // Legacy URL redirects preserving query parameters (e.g., ?ref=CODE)
  app.get('/trips.html', (req: Request, res: Response) => {
    const qs = req.url.includes('?') ? req.url.slice(req.url.indexOf('?')) : '';
    res.redirect(301, `/trips${qs}`);
  });

  app.get('/partners.html', (req: Request, res: Response) => {
    const qs = req.url.includes('?') ? req.url.slice(req.url.indexOf('?')) : '';
    res.redirect(301, `/profile?tab=affiliate${qs ? `&${qs.slice(1)}` : ''}`);
  });

  app.get('/trip', (req: Request, res: Response) => {
    const tripId = typeof req.query.id === 'string' ? req.query.id : '';
    const ref = typeof req.query.ref === 'string' ? `?ref=${encodeURIComponent(req.query.ref)}` : '';
    if (tripId && /^[a-zA-Z0-9_\-]+$/.test(tripId)) {
      res.redirect(301, `/trip/${encodeURIComponent(tripId)}${ref}`);
      return;
    }
    res.redirect(301, `/trips${ref}`);
  });

  // --- API Routes ---
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      status: 'ok',
      service: 'rehhal-api',
      timestamp: new Date().toISOString(),
    });
  });

  // Authenticated & Firestore-backed partner referral sync
  app.post('/api/referrals/register', async (req: Request, res: Response) => {
    const authToken = await verifyFirebaseBearerToken(req);
    if (!authToken) {
      res.status(401).json({ valid: false, error: 'Authentication required' });
      return;
    }

    const { code, marketerId, marketerName, commissionRate } = req.body as {
      code?: string;
      marketerId?: string;
      marketerName?: string;
      commissionRate?: number;
    };

    if (!code || !marketerId || !marketerName) {
      res.status(400).json({ valid: false, error: 'Missing required referral fields' });
      return;
    }

    const normalized = code.trim().toUpperCase();
    if (!isValidReferralCodeFormat(normalized) || !/^[a-zA-Z0-9_\-]+$/.test(marketerId)) {
      res.status(400).json({ valid: false, error: 'Invalid referral code or marketer format' });
      return;
    }

    // Authoritatively resolve against Firestore first; never allow unverified third-party overrides
    const firestoreRecord = await resolveReferralCodeOnServer(normalized);
    if (firestoreRecord) {
      if (firestoreRecord.marketerId !== marketerId) {
        res.status(403).json({ valid: false, error: 'Referral ownership mismatch' });
        return;
      }
      localReferralRegistry.set(normalized, firestoreRecord);
      res.json({ valid: true, referral: firestoreRecord });
      return;
    }

    if (authToken.uid !== marketerId) {
      res.status(403).json({ valid: false, error: 'Unauthorized referral registration' });
      return;
    }

    const record: ReferralRecord = {
      code: normalized,
      marketerId,
      marketerName: marketerName.slice(0, 120),
      commissionRate: typeof commissionRate === 'number' && commissionRate > 0 && commissionRate <= 0.35 ? commissionRate : 0.08,
      active: true,
    };
    localReferralRegistry.set(normalized, record);
    res.json({ valid: true, referral: record });
  });

  app.post('/api/referrals/track', async (req: Request, res: Response) => {
    const { code, tripId, sessionKey } = req.body as {
      code?: string;
      tripId?: string;
      sessionKey?: string;
    };

    if (!code || typeof code !== 'string') {
      res.status(400).json({ valid: false, error: 'Referral code is required' });
      return;
    }

    const normalized = code.trim().toUpperCase();
    const record = await resolveReferralCodeOnServer(normalized);

    if (!record || !record.active) {
      res.status(404).json({ valid: false, error: 'كود الإحالة غير صالح أو غير نشط' });
      return;
    }

    const safeTripId = typeof tripId === 'string' ? tripId.slice(0, 80) : 'catalog';
    const safeSession = typeof sessionKey === 'string' && sessionKey.length >= 4 ? sessionKey.slice(0, 120) : req.ip || 'anon';
    const dedupeKey = `${safeSession}::${normalized}::${safeTripId}`;

    let deduplicated = false;
    if (!clickDedupeSet.has(dedupeKey)) {
      clickDedupeSet.add(dedupeKey);
      clickCountsByCode.set(normalized, (clickCountsByCode.get(normalized) ?? 0) + 1);
      clickHistory.push({
        sessionKey: safeSession,
        code: normalized,
        tripId: safeTripId,
        timestamp: Date.now(),
      });
    } else {
      deduplicated = true;
    }

    const issuedAt = Date.now();
    const signature = signReferralAttribution({
      code: record.code,
      marketerId: record.marketerId,
      commissionRate: record.commissionRate,
      issuedAt,
    });

    res.json({
      valid: true,
      code: record.code,
      marketerId: record.marketerId,
      marketerName: record.marketerName,
      commissionRate: record.commissionRate,
      signature,
      deduplicated,
      totalClicks: clickCountsByCode.get(normalized) ?? 1,
    });
  });

  app.post('/api/referrals/verify', async (req: Request, res: Response) => {
    const { code, marketerId, signature, currentUserId } = req.body as {
      code?: string;
      marketerId?: string;
      signature?: string;
      currentUserId?: string;
    };

    if (!code || !marketerId) {
      res.status(400).json({ valid: false, error: 'Missing referral attribution data' });
      return;
    }

    const normalized = code.trim().toUpperCase();
    const record = await resolveReferralCodeOnServer(normalized);
    if (!record || !record.active || record.marketerId !== marketerId) {
      res.status(403).json({ valid: false, error: 'تم رفض الإحالة: تعارض في بيانات المسوّق' });
      return;
    }

    if (currentUserId && currentUserId === record.marketerId) {
      res.status(403).json({ valid: false, error: 'لا يمكن استخدام رابط الإحالة الخاص بك لحجز رحلاتك' });
      return;
    }

    if (signature && !verifyReferralSignature(record.code, record.marketerId, record.commissionRate, signature)) {
      res.status(403).json({ valid: false, error: 'توقيع الإحالة غير صالح أو تم تعديله' });
      return;
    }

    res.json({
      valid: true,
      code: record.code,
      marketerId: record.marketerId,
      commissionRate: record.commissionRate,
    });
  });

  app.get('/api/referrals/stats/:code', (req: Request, res: Response) => {
    const rawParam = Array.isArray(req.params.code) ? req.params.code[0] : req.params.code;
    const code = (rawParam || '').trim().toUpperCase();
    if (!isValidReferralCodeFormat(code)) {
      res.status(400).json({ error: 'Invalid code format' });
      return;
    }
    const entries = clickHistory.filter((c) => c.code === code);
    res.json({
      code,
      uniqueClicks: clickCountsByCode.get(code) ?? 0,
      recentTrips: entries.slice(-10).map((e) => ({ tripId: e.tripId, timestamp: e.timestamp })),
    });
  });

  // Online-only authenticated payment authorization endpoint (never works offline)
  app.post('/api/payments/authorize', async (req: Request, res: Response) => {
    const authToken = await verifyFirebaseBearerToken(req);
    if (!authToken) {
      res.status(401).json({ authorized: false, error: 'يرجى تسجيل الدخول لتأكيد الدفع' });
      return;
    }

    const { bookingId, amount, currency, paymentMethod, userId } = req.body as {
      bookingId?: string;
      amount?: number;
      currency?: string;
      paymentMethod?: string;
      userId?: string;
    };

    if (
      !bookingId ||
      !/^[a-zA-Z0-9_\-]{4,128}$/.test(bookingId) ||
      typeof amount !== 'number' ||
      !Number.isFinite(amount) ||
      amount <= 0 ||
      amount > 50000000 ||
      !paymentMethod ||
      !userId
    ) {
      res.status(400).json({ authorized: false, error: 'بيانات الدفع غير مكتملة أو غير صالحة' });
      return;
    }

    if (authToken.uid !== userId) {
      res.status(403).json({ authorized: false, error: 'غير مصرح بتنفيذ الدفع لحساب آخر' });
      return;
    }

    if (currency !== 'EGP') {
      res.status(400).json({ authorized: false, error: 'العملة المعتمدة للدفع هي الجنيه المصري فقط (EGP)' });
      return;
    }

    const allowedMethods = ['mada', 'visa', 'apple_pay', 'bank_transfer'];
    if (!allowedMethods.includes(paymentMethod)) {
      res.status(400).json({ authorized: false, error: 'وسيلة الدفع غير مدعومة' });
      return;
    }

    const paymentRef = `REH-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
    res.json({
      authorized: true,
      currency: 'EGP',
      paymentRef,
      verifiedAt: new Date().toISOString(),
    });
  });

  // PWA & AssetLinks diagnostic check
  app.get('/api/pwa/diagnostics', (_req: Request, res: Response) => {
    const publicDir = IS_PROD ? path.resolve(ROOT_DIR, 'dist') : path.resolve(ROOT_DIR, 'public');
    const checks = {
      manifestWebmanifest: fs.existsSync(path.join(publicDir, 'manifest.webmanifest')),
      manifest: fs.existsSync(path.join(publicDir, 'manifest.json')),
      serviceWorker: fs.existsSync(path.join(publicDir, 'service-worker.js')),
      offlinePage: fs.existsSync(path.join(publicDir, 'offline.html')),
      icon192: fs.existsSync(path.join(publicDir, 'icons/icon-192x192.png')),
      icon512: fs.existsSync(path.join(publicDir, 'icons/icon-512x512.png')),
      iconMaskable: fs.existsSync(path.join(publicDir, 'icons/icon-maskable-512x512.png')),
      appleTouchIcon: fs.existsSync(path.join(publicDir, 'apple-touch-icon.png')),
      assetLinks: fs.existsSync(path.join(publicDir, '.well-known/assetlinks.json')),
      sha256Configured: Boolean((process.env.ANDROID_SHA256_FINGERPRINT || '').trim()),
    };
    res.json(checks);
  });

  // Reject unknown API routes with JSON 404
  app.use('/api', (_req: Request, res: Response) => {
    res.status(404).json({ error: 'API endpoint not found' });
  });

  if (IS_PROD) {
    const distDir = path.resolve(ROOT_DIR, 'dist');
    app.use(express.static(distDir, { index: false }));

    // Server-side SPA fallback for all clean URLs
    app.get('*', (_req: Request, res: Response) => {
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });

    app.use(vite.middlewares);

    // Dev SPA fallback preserving Clean URLs & ?ref= query strings on direct load / refresh
    app.get('*', async (req: Request, res: Response) => {
      try {
        const templatePath = path.resolve(ROOT_DIR, 'index.html');
        let html = fs.readFileSync(templatePath, 'utf8');
        html = await vite.transformIndexHtml(req.originalUrl, html);
        res.status(200).set({ 'Content-Type': 'text/html; charset=utf-8' }).end(html);
      } catch (err) {
        vite.ssrFixStacktrace(err as Error);
        res.status(500).end((err as Error).message);
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`REHHAL server running on http://0.0.0.0:${PORT} (${IS_PROD ? 'production' : 'development'})`);
  });
}

startServer();
