import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  }
  crcTable[n] = c >>> 0;
}

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const crcBuf = Buffer.alloc(4);
  const combined = Buffer.concat([typeBuf, data]);
  crcBuf.writeUInt32BE(crc32(combined), 0);
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}

function encodePNG(width, height, pixelFn) {
  const raw = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y++) {
    const rowStart = y * (width * 4 + 1);
    raw[rowStart] = 0; // filter none
    for (let x = 0; x < width; x++) {
      const [r, g, b, a] = pixelFn(x, y, width, height);
      const idx = rowStart + 1 + x * 4;
      raw[idx] = r;
      raw[idx + 1] = g;
      raw[idx + 2] = b;
      raw[idx + 3] = a;
    }
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // RGBA
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  const idat = zlib.deflateSync(raw, { level: 9 });
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  return Buffer.concat([
    signature,
    chunk('IHDR', ihdr),
    chunk('IDAT', idat),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

function mix(c1, c2, t) {
  const clamped = Math.max(0, Math.min(1, t));
  return [
    Math.round(c1[0] + (c2[0] - c1[0]) * clamped),
    Math.round(c1[1] + (c2[1] - c1[1]) * clamped),
    Math.round(c1[2] + (c2[2] - c1[2]) * clamped),
    255,
  ];
}

const NAVY = [11, 23, 42];
const SLATE = [18, 35, 59];
const GOLD = [197, 161, 91];
const IVORY = [244, 241, 234];

function renderCompassIcon(x, y, w, h, safeScale = 1.0) {
  const cx = w / 2;
  const cy = h / 2;
  const nx = (x - cx) / (w * 0.5 * safeScale);
  const ny = (y - cy) / (h * 0.5 * safeScale);
  const r = Math.hypot(nx, ny);

  // Outer navy-to-slate subtle radial backdrop
  let col = mix(SLATE, NAVY, Math.min(1, r * 0.85));

  // Outer gold ring
  if (Math.abs(r - 0.68) < 0.035) {
    col = GOLD;
  }
  // Inner subtle ring
  if (Math.abs(r - 0.52) < 0.012) {
    col = mix(col, GOLD, 0.45);
  }

  // Compass diamond needle (top gold, bottom ivory)
  const ax = Math.abs(nx);
  if (ny < 0 && ny > -0.52) {
    const halfW = (1 + ny / 0.52) * 0.14;
    if (ax < halfW && r > 0.07) {
      col = GOLD;
    }
  }
  if (ny > 0 && ny < 0.52) {
    const halfW = (1 - ny / 0.52) * 0.14;
    if (ax < halfW && r > 0.07) {
      col = IVORY;
    }
  }

  // Center jewel
  if (r <= 0.085 && r >= 0.05) {
    col = GOLD;
  } else if (r < 0.05) {
    col = NAVY;
  }

  return [...col, 255];
}

function renderScreenshot(x, y, w, h) {
  // Architectural mockup banner matching REHHAL colors (#0B172A, #12233B, #C5A15B)
  const topBarH = Math.round(h * 0.1);
  if (y < topBarH) {
    if (y > topBarH - 2) return [...GOLD, 255];
    return [...SLATE, 255];
  }
  const cardTop = Math.round(h * 0.16);
  const cardBottom = Math.round(h * 0.56);
  const padX = Math.round(w * 0.06);
  if (y >= cardTop && y <= cardBottom && x >= padX && x <= w - padX) {
    if (x === padX || x === w - padX || y === cardTop || y === cardBottom) {
      return [...GOLD, 255];
    }
    const t = (y - cardTop) / (cardBottom - cardTop);
    return mix(SLATE, NAVY, t);
  }
  const ctaTop = Math.round(h * 0.64);
  const ctaBottom = Math.round(h * 0.72);
  if (y >= ctaTop && y <= ctaBottom && x >= padX && x <= Math.round(w * 0.45)) {
    return [...GOLD, 255];
  }
  return [...NAVY, 255];
}

fs.mkdirSync(path.resolve('public/icons'), { recursive: true });
fs.mkdirSync(path.resolve('public/screenshots'), { recursive: true });

fs.writeFileSync('public/icons/icon-192x192.png', encodePNG(192, 192, (x, y, w, h) => renderCompassIcon(x, y, w, h, 0.92)));
fs.writeFileSync('public/icons/icon-512x512.png', encodePNG(512, 512, (x, y, w, h) => renderCompassIcon(x, y, w, h, 0.92)));
// Maskable icon keeps full iconography inside central 76% safe zone (12%+ margin all sides)
fs.writeFileSync('public/icons/icon-maskable-512x512.png', encodePNG(512, 512, (x, y, w, h) => renderCompassIcon(x, y, w, h, 0.74)));
fs.writeFileSync('public/apple-touch-icon.png', encodePNG(180, 180, (x, y, w, h) => renderCompassIcon(x, y, w, h, 0.9)));
fs.writeFileSync('public/screenshots/mobile-home.png', encodePNG(540, 960, renderScreenshot));
fs.writeFileSync('public/screenshots/desktop-home.png', encodePNG(1280, 720, renderScreenshot));

console.log('Generated all REHHAL PWA PNG icons and screenshots.');
