import assert from 'node:assert';

const BASE_URL = process.env.BASE_URL || 'http://127.0.0.1:3000';

async function runVerification() {
  console.log(`Running REHHAL live verification against ${BASE_URL}...`);

  // 1. Health & Clean URL SPA Fallback checks across all registered routes
  const cleanRoutes = [
    '/',
    '/trips',
    '/trips?category=pilgrimage',
    '/trip/umrah-makkah-madinah-signature',
    '/trip/alula-sanctuary?ref=REHHAL101',
    '/my-bookings',
    '/profile',
    '/support',
    '/about',
    '/privacy',
    '/terms',
    '/login',
    '/partners',
    '/partners/register',
    '/partners/dashboard',
    '/partners/referrals',
    '/partners/earnings',
    '/partners/bookings',
    '/partners/payouts',
    '/admin',
    '/admin/trips',
    '/admin/bookings',
    '/admin/customers',
    '/admin/marketers',
    '/admin/commissions',
    '/admin/payments',
    '/admin/reviews',
    '/admin/contacts',
    '/admin/settings',
    '/unknown-page-404',
  ];

  for (const route of cleanRoutes) {
    const res = await fetch(`${BASE_URL}${route}`);
    assert.strictEqual(res.status, 200, `Route ${route} should return 200 SPA HTML`);
    const html = await res.text();
    assert(html.includes('<div id="root"></div>'), `Route ${route} missing root mount`);
  }
  console.log(`PASS: All ${cleanRoutes.length} clean URL routes return HTTP 200 SPA shell.`);

  // 2. Legacy redirects preserve query strings & ?ref=
  const legacyTrips = await fetch(`${BASE_URL}/trips.html?ref=REHHAL101`, { redirect: 'manual' });
  assert.strictEqual(legacyTrips.status, 301);
  assert.strictEqual(legacyTrips.headers.get('location'), '/trips?ref=REHHAL101');

  const legacyTrip = await fetch(`${BASE_URL}/trip?id=alula-sanctuary&ref=REHHAL101`, { redirect: 'manual' });
  assert.strictEqual(legacyTrip.status, 301);
  assert.strictEqual(legacyTrip.headers.get('location'), '/trip/alula-sanctuary?ref=REHHAL101');

  const legacyPartners = await fetch(`${BASE_URL}/partners.html?ref=REHHAL101`, { redirect: 'manual' });
  assert.strictEqual(legacyPartners.status, 301);
  assert.strictEqual(legacyPartners.headers.get('location'), '/profile?tab=affiliate&ref=REHHAL101');
  console.log('PASS: Legacy route redirects preserve ?ref= attribution parameters.');

  // 3. Referral validation, deduplication, tamper rejection, self-referral blocking
  const sessionKey = `verify_${Date.now()}`;
  const track1 = await fetch(`${BASE_URL}/api/referrals/track`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ code: 'REHHAL101', tripId: 'alula-sanctuary', sessionKey }),
  });
  assert.strictEqual(track1.status, 200);
  const t1Json = await track1.json();
  assert.strictEqual(t1Json.valid, true);
  assert.strictEqual(t1Json.deduplicated, false);
  assert(t1Json.signature, 'Server must return HMAC signature');

  const track2 = await fetch(`${BASE_URL}/api/referrals/track`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ code: 'REHHAL101', tripId: 'alula-sanctuary', sessionKey }),
  });
  const t2Json = await track2.json();
  assert.strictEqual(t2Json.deduplicated, true, 'Duplicate click must be deduplicated');

  const verifyValid = await fetch(`${BASE_URL}/api/referrals/verify`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      code: 'REHHAL101',
      marketerId: t1Json.marketerId,
      signature: t1Json.signature,
      currentUserId: 'customer_abc',
    }),
  });
  assert.strictEqual(verifyValid.status, 200);

  const verifyTampered = await fetch(`${BASE_URL}/api/referrals/verify`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      code: 'REHHAL101',
      marketerId: 'hijacked_marketer',
      signature: t1Json.signature,
      currentUserId: 'customer_abc',
    }),
  });
  assert.strictEqual(verifyTampered.status, 403, 'Tampered marketerId must be rejected');

  const verifySelfRef = await fetch(`${BASE_URL}/api/referrals/verify`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      code: 'REHHAL101',
      marketerId: t1Json.marketerId,
      signature: t1Json.signature,
      currentUserId: t1Json.marketerId,
    }),
  });
  assert.strictEqual(verifySelfRef.status, 403, 'Self-referral must be rejected');
  console.log('PASS: Server-side referral tracking, deduplication, tamper protection, and self-referral guard verified.');

  // 4. Online Payment Authorization & Referral Registration Security Enforcement (requires Firebase Bearer token)
  const unauthPay = await fetch(`${BASE_URL}/api/payments/authorize`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      bookingId: 'bkg_live_check',
      amount: 7800,
      currency: 'EGP',
      paymentMethod: 'mada',
      userId: 'cust_live_1',
    }),
  });
  assert.strictEqual(unauthPay.status, 401, 'Unauthenticated payment authorization must be rejected with 401');

  const unauthReg = await fetch(`${BASE_URL}/api/referrals/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      code: 'SPOOF99',
      marketerId: 'attacker_uid',
      marketerName: 'Spoof',
      commissionRate: 0.35,
    }),
  });
  assert.strictEqual(unauthReg.status, 401, 'Unauthenticated referral registration must be rejected with 401');
  console.log('PASS: Server auth gates on /api/payments/authorize and /api/referrals/register verified (401).');

  // 5. PWA & Android AssetLinks & Security Headers checks
  const manifestRes = await fetch(`${BASE_URL}/manifest.webmanifest`);
  assert.strictEqual(manifestRes.status, 200);
  assert(manifestRes.headers.get('content-type')?.includes('application/manifest+json'));
  assert.strictEqual(manifestRes.headers.get('x-content-type-options'), 'nosniff');
  assert.strictEqual(manifestRes.headers.get('x-powered-by'), null);
  const manifest = await manifestRes.json();
  assert.strictEqual(manifest.name, 'رحّال REHHAL');
  assert.strictEqual(manifest.short_name, 'رحّال');
  assert.strictEqual(manifest.dir, 'rtl');
  assert.strictEqual(manifest.lang, 'ar');
  assert.strictEqual(manifest.display, 'standalone');
  assert.strictEqual(manifest.start_url, '/');
  assert.strictEqual(manifest.scope, '/');
  assert.strictEqual(manifest.theme_color, '#0B172A');
  assert.strictEqual(manifest.background_color, '#0B172A');

  for (const icon of manifest.icons) {
    const iconRes = await fetch(`${BASE_URL}${icon.src}`);
    assert.strictEqual(iconRes.status, 200, `Icon ${icon.src} must exist`);
    assert(iconRes.headers.get('content-type')?.includes('image/png'), `Icon ${icon.src} must be PNG`);
  }
  for (const shot of manifest.screenshots) {
    const shotRes = await fetch(`${BASE_URL}${shot.src}`);
    assert.strictEqual(shotRes.status, 200, `Screenshot ${shot.src} must exist`);
  }

  const swRes = await fetch(`${BASE_URL}/service-worker.js`);
  assert.strictEqual(swRes.status, 200);
  assert(swRes.headers.get('content-type')?.includes('javascript'));
  const swCode = await swRes.text();
  assert(swCode.includes('/manifest.webmanifest'), 'SW must precache /manifest.webmanifest');
  assert(swCode.includes('firestore.googleapis.com'), 'SW must bypass Firebase Firestore hosts');

  const offlineRes = await fetch(`${BASE_URL}/offline.html`);
  assert.strictEqual(offlineRes.status, 200);

  const assetLinksRes = await fetch(`${BASE_URL}/.well-known/assetlinks.json`);
  assert.strictEqual(assetLinksRes.status, 200);
  assert(assetLinksRes.headers.get('content-type')?.includes('application/json'));
  const assetLinks = await assetLinksRes.json();
  assert(Array.isArray(assetLinks) && assetLinks[0]?.target?.package_name === 'com.rehhal.app');

  const diagRes = await fetch(`${BASE_URL}/api/pwa/diagnostics`);
  const diag = await diagRes.json();
  console.log('PWA Diagnostics:', JSON.stringify(diag));
  assert.strictEqual(diag.manifestWebmanifest, true);
  assert.strictEqual(diag.manifest, true);
  assert.strictEqual(diag.serviceWorker, true);
  assert.strictEqual(diag.offlinePage, true);
  assert.strictEqual(diag.icon192, true);
  assert.strictEqual(diag.icon512, true);
  assert.strictEqual(diag.iconMaskable, true);
  assert.strictEqual(diag.appleTouchIcon, true);
  assert.strictEqual(diag.assetLinks, true);
  console.log('PASS: PWA Manifest (.webmanifest), Icons, Screenshots, Hardened SW, Offline Page, Security Headers & AssetLinks verified.');
}

runVerification().catch((err) => {
  console.error('Verification failed:', err);
  process.exit(1);
});
