import fs from 'node:fs';
import { defineConfig } from '@playwright/test';

const preinstalledShell = '/ms-playwright/chrome-headless-shell-linux64/chrome-headless-shell';
const launchOptions = fs.existsSync(preinstalledShell)
  ? { executablePath: preinstalledShell }
  : undefined;

export default defineConfig({
  testDir: './tests/e2e',
  timeout: 30000,
  use: {
    baseURL: process.env.PLAYWRIGHT_BASE_URL || 'http://127.0.0.1:3000',
    trace: 'on-first-retry',
    launchOptions,
  },
  projects: [
    {
      name: 'Desktop Chromium',
      use: { viewport: { width: 1440, height: 900 } },
    },
    {
      name: 'Mobile Android TWA Viewport',
      use: { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true },
    },
  ],
});
