# GOOGLE_PLAY_READINESS — تقرير الجاهزية للنشر على متجر Google Play

تاريخ التحديث: 2026-11-26  
إعدادات TWA المرجعية: `twa-manifest.json`  
ملف التوثيق الرقمي للروابط: `public/.well-known/assetlinks.json`

---

## 1. ملخص الحالة العامة

- **جاهزية الواجهة والـ PWA للتغليف (TWA / Bubblewrap / PWABuilder)**: **PASS (جاهز فنياً للتغليف)**
- **إنشاء ملف حزمة Android App Bundle (`.aab`) وتوقيعه**: **BLOCKED** — يتطلب تنفيذ البناء على بيئة تتضمن Android SDK وJava Keytool ومفتاح التوقيع الخاص بصاحب المشروع، ثم رفع الحزمة إلى Google Play Console.

---

## 2. قائمة التحقق التفصيلية لمتطلبات Google Play (TWA)

| المتطلب | الحالة | التفاصيل |
| :--- | :--- | :--- |
| HTTPS للرابط المنشور وعدم وجود Mixed Content | **PASS** (برمجياً) | جميع طلبات التطبيق والـ AssetLinks والصور والخطوط تعمل عبر HTTPS أو مسارات نسبية لنفس النطاق مع ترويسة `Strict-Transport-Security` عند الاتصال عبر HTTPS. |
| Web App Manifest (`manifest.webmanifest`) | **PASS** | مُهيأ بالكامل (`name: رحّال REHHAL`، `short_name: رحّال`، `start_url: /`، `scope: /`، `display: standalone`، `theme_color: #0B172A`، `background_color: #0B172A`، `dir: rtl`، `lang: ar`). |
| أيقونات Android وMaskable Icon | **PASS** | `192x192 PNG` و`512x512 PNG` و`512x512 Maskable PNG` (شعار بوصلة رحّال الأصلي مع هامش أمان كافٍ للقص الدائري)، ولقطات شاشة حقيقية لصفحة التطبيق. |
| شاشة البداية (Splash Screen) | **PASS** | مضبوطة في `manifest.webmanifest` و`twa-manifest.json` بلون `#0B172A` وزمن تلاشي `300ms`. |
| ملف `/.well-known/assetlinks.json` | **PASS (ينتظر البصمة الحقيقية)** | يُقدَّم عبر مسار `/.well-known/assetlinks.json` بترويسة `Content-Type: application/json` دون إعادة توجيه تمنع التحقق. القيمة الحالية تحتوي على العنصر الإرشادي `REPLACE_WITH_GOOGLE_PLAY_APP_SIGNING_SHA256`. |
| معرف الحزمة (Package ID) والإصدارات | **يحتاج اعتماد المالك** | القيمة المقترحة في `twa-manifest.json` هي `com.rehhal.app` مع `appVersionName: 1.0.0` و`appVersionCode: 1`. يُرجى اعتماد الاسم الرسمي بناءً على النطاق المملوك قبل البناء النهائي. |
| عمل الروابط الداخلية وDeep Links | **PASS** | جميع الروابط الداخلية (مثل `/trips` و`/trip/:id?ref=...` و`/my-bookings`) تعمل بمسارات نظيفة عبر SPA Fallback مع الحفاظ على بيانات الإحالة. |
| حماية البيانات المالية والـ Service Worker | **PASS** | الصفحات الخاصة والحجوزات والمدفوعات ومسارات Firebase معزولة عن التخزين المؤقت، كما يتطلب تأكيد الدفع توثيقاً من الخادم (401 لغير المسجلين) والعملة المعتمدة هي الجنيه المصري فقط (`EGP`). |

---

## 3. متطلبات من صاحب المشروع قبل الإطلاق على Google Play

1. **تأكيد النطاق الرسمي للإنتاج** (بدلاً من رابط المعاينة المؤقت إذا وُجد نطاق مخصص مثل `rehhal.app` أو `rehhal.com`) وتحديث `host` و`fullScopeUrl` في `twa-manifest.json`.
2. **اعتماد Package ID النهائي** (المقترح: `com.rehhal.app` — لا يجب تغييره بعد رفع أول نسخة على Google Play).
3. **إصدار مفتاح توقيع Release Keystore** محلياً بشكل سري خارج المستودع، ثم استخراج بصمة `SHA-256` لشهادة Play App Signing من Google Play Console وإضافتها في `ANDROID_SHA256_FINGERPRINT` أو `public/.well-known/assetlinks.json`.
4. **مراجعة واعتماد أسعار الباقات بالجنيه المصري (`EGP`)** في لوحة الإدارة (`/admin/trips`) وتفعيل باقات الحج والعمرة بالعملة المصرية قبل النشر للجمهور.
5. **تجهيز صفحة متجر Google Play**: نص الخصوصية (متاح على `/privacy`)، ونص الشروط (متاح على `/terms`)، وبيانات حساب الاختبار للمراجعين عند اللزوم.
