/**
 * REHHAL Firestore Rules Verification Suite (Phase 0 Security Spec)
 * Validates Dirty Dozen adversarial payloads against structural & rule invariants.
 */
import assert from 'node:assert';
import fs from 'node:fs';

const rulesContent = fs.readFileSync('firestore.rules', 'utf8');

// Verify all Eight Pillars and Dirty Dozen defenses are present in deployed rules
assert(rulesContent.includes("rules_version = '2';"), 'Must enforce rules_version 2');
assert(rulesContent.includes('match /{document=**} {\n      allow read, write: if false;\n    }'), 'Must start with default-deny safety net');
assert(rulesContent.includes('email_verified == true'), 'Must enforce verified email');
assert(rulesContent.includes("incoming().role == 'customer'"), 'Must block self-admin escalation on user create');
assert(rulesContent.includes('incoming().marketerId != request.auth.uid'), 'Must block self-referral fraud');
assert(rulesContent.includes('incoming().marketerId == existing().marketerId'), 'Must enforce immutable marketer attribution on booking update');
assert(rulesContent.includes('incoming().referralCode == existing().referralCode'), 'Must enforce immutable referral code on booking update');
assert(rulesContent.includes("incoming().status == 'pending'"), 'Must force pending status on payout request create');
assert(rulesContent.includes('affectedKeys().hasOnly('), 'Must enforce action-based update field allowlists');
assert(rulesContent.includes("data.category in ['hajj', 'umrah',"), 'Must support hajj and umrah primary categories');
assert(rulesContent.includes("incoming().status == 'pending'"), 'Must require admin approval for new marketer applications');
assert(rulesContent.includes('incoming().active == false'), 'Must require admin activation for applicant referral codes');
assert(rulesContent.includes('match /platform_reviews/{userId}'), 'Must isolate platform_reviews collection');
assert(rulesContent.includes('match /trip_reviews/{reviewId}'), 'Must isolate trip_reviews collection');
assert(rulesContent.includes("data.status == 'completed'"), 'Must enforce completed booking status for trip_reviews');
assert(rulesContent.includes("reviewId == ('trv_' + incoming().bookingId)"), 'Must prevent duplicate trip reviews per completed booking');
assert(rulesContent.includes('match /contact_requests/{requestId}'), 'Must isolate contact_requests collection');
assert(rulesContent.includes("incoming().status == 'new'"), 'Must force initial status new on contact request create');
assert(rulesContent.includes("incoming().currency == 'EGP'"), 'Must enforce EGP currency on new bookings, commissions, and payouts');
assert(rulesContent.includes(".data.currency == 'EGP'"), 'Must enforce Admin-approved EGP trip pricing before online booking');
assert(!rulesContent.includes('allow list: if isSignedIn();'), 'Must never delegate list filtering to client');

console.log('REHHAL Firestore Security Rules structural & security assertions passed.');
