const SHELL_CACHE = 'rehhal-shell-v2';
const ASSETS_CACHE = 'rehhal-assets-v2';
const FONTS_CACHE = 'rehhal-fonts-v2';
const ACTIVE_CACHES = new Set([SHELL_CACHE, ASSETS_CACHE, FONTS_CACHE]);
const OFFLINE_URL = '/offline.html';

const PRECACHE_ASSETS = [
  '/',
  '/trips',
  '/offline.html',
  '/manifest.webmanifest',
  '/icon.svg',
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png',
  '/apple-touch-icon.png',
];

// Private, auth, financial, or server routes that must NEVER be stored in Service Worker caches
const PRIVATE_OR_AUTH_PREFIXES = [
  '/api/',
  '/__/',
  '/.well-known/',
  '/login',
  '/my-bookings',
  '/profile',
  '/booking/',
  '/partners',
  '/admin',
];

// Public catalog / informational routes safe to cache (strictly stripped of query params)
const PUBLIC_CACHEABLE_EXACT = new Set([
  '/',
  '/trips',
  '/support',
  '/about',
  '/privacy',
  '/terms',
]);

// Firebase / Google Identity / API origins that must bypass SW interception completely
const EXTERNAL_BYPASS_HOSTS = [
  'firestore.googleapis.com',
  'identitytoolkit.googleapis.com',
  'securetoken.googleapis.com',
  'www.googleapis.com',
  'accounts.google.com',
  'apis.google.com',
  'firebaseinstallations.googleapis.com',
  'firebaseapp.com',
];

function isPublicCatalogNavigation(pathname) {
  return PUBLIC_CACHEABLE_EXACT.has(pathname) || pathname.startsWith('/trip/');
}

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(SHELL_CACHE)
      .then((cache) => cache.addAll(PRECACHE_ASSETS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((key) => !ACTIVE_CACHES.has(key))
            .map((key) => caches.delete(key))
        )
      )
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  let url;
  try {
    url = new URL(request.url);
  } catch {
    return;
  }

  // Only handle http/https requests
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return;

  // Never intercept or cache external Firebase, Auth, or Google OAuth requests
  if (EXTERNAL_BYPASS_HOSTS.some((host) => url.hostname === host || url.hostname.endsWith(`.${host}`))) {
    return;
  }

  // Google Fonts: Cache-First (non-sensitive static typography assets)
  if (url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') {
    event.respondWith(
      caches.open(FONTS_CACHE).then(async (cache) => {
        const cached = await cache.match(request);
        if (cached) return cached;
        try {
          const response = await fetch(request);
          if (response && (response.status === 200 || response.type === 'opaque')) {
            cache.put(request, response.clone());
          }
          return response;
        } catch {
          return new Response('', { status: 503, statusText: 'Offline' });
        }
      })
    );
    return;
  }

  // Only handle same-origin requests below this point
  if (url.origin !== self.location.origin) return;

  // Never cache private, auth, financial, or AssetLinks paths
  if (PRIVATE_OR_AUTH_PREFIXES.some((prefix) => url.pathname.startsWith(prefix))) {
    if (request.mode === 'navigate') {
      event.respondWith(
        fetch(request).catch(async () => {
          const offline = await caches.match(OFFLINE_URL);
          return offline || new Response('Offline', { status: 503 });
        })
      );
    }
    return;
  }

  // Public Navigation Requests: Network-First with normalized pathname fallback -> offline.html
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (
            response &&
            response.ok &&
            response.type === 'basic' &&
            isPublicCatalogNavigation(url.pathname)
          ) {
            const copy = response.clone();
            caches.open(SHELL_CACHE).then((cache) => cache.put(url.pathname, copy));
          }
          return response;
        })
        .catch(async () => {
          const cachedPage = await caches.match(url.pathname);
          if (cachedPage) return cachedPage;
          const offlinePage = await caches.match(OFFLINE_URL);
          return offlinePage || new Response('Offline', { status: 503 });
        })
    );
    return;
  }

  // Fingerprinted Vite build bundles under /assets/: Cache-First (immutable hashed assets)
  if (url.pathname.startsWith('/assets/')) {
    event.respondWith(
      caches.open(ASSETS_CACHE).then(async (cache) => {
        const cached = await cache.match(request);
        if (cached) return cached;
        try {
          const response = await fetch(request);
          if (response && response.ok && response.type === 'basic') {
            cache.put(request, response.clone());
          }
          return response;
        } catch {
          return new Response('', { status: 503, statusText: 'Offline' });
        }
      })
    );
    return;
  }

  // Static assets (CSS, JS, images, fonts, manifest): Stale-While-Revalidate
  if (/\.(?:js|css|png|jpg|jpeg|svg|webp|woff2?|json|webmanifest|ico)$/i.test(url.pathname)) {
    event.respondWith(
      caches.open(ASSETS_CACHE).then(async (cache) => {
        const cached = await cache.match(request);
        const networkPromise = fetch(request)
          .then((response) => {
            if (response && response.ok && response.type === 'basic') {
              cache.put(request, response.clone());
            }
            return response;
          })
          .catch(() => null);

        if (cached) {
          event.waitUntil(networkPromise);
          return cached;
        }

        const networkResponse = await networkPromise;
        return networkResponse || new Response('', { status: 503, statusText: 'Offline' });
      })
    );
  }
});
