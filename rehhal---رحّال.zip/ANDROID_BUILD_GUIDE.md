# ANDROID_BUILD_GUIDE — دليل بناء تطبيق Android (TWA / AAB) ورفعه على Google Play

هذا الدليل يوضح الخطوات العملية الكاملة لتغليف تطبيق **رحّال (REHHAL)** كـ Android Trusted Web Activity (TWA) وإصدار حزمة **Android App Bundle (`.aab`)** وربط **Digital Asset Links** بشكل صحيح دون إدخال أي بصمات أو مفاتيح مزيفة.

---

## 1. المتطلبات المسبقة

- رابط الموقع المنشور يعمل عبر **HTTPS** (مثلاً رابط الإنتاج أو المعاينة المنشورة) وملف `https://<DOMAIN>/manifest.webmanifest` يعيد `200 OK`.
- **Node.js 20+** مثبت على جهاز البناء.
- **Java JDK 17** و**Android SDK Command-Line Tools** (أو Android Studio).
- تثبيت أداة Bubblewrap الرسمية:
  ```bash
  npm install -g @bubblewrap/cli
  ```

---

## 2. مراجعة الإعدادات في `twa-manifest.json` قبل البناء

قبل توليد المشروع، راجع القيم التالية في `twa-manifest.json`:

- `packageId`: القيمة المقترحة حالياً هي `com.rehhal.app` (عدّلها لتطابق نطاقك الرسمي إذا اعتمدت نطاقاً آخر، ولا تغيّرها أبداً بعد أول رفع على Google Play).
- `host` و `fullScopeUrl`: استبدلهما بنطاق الإنتاج الرسمي عند ربط نطاق مخصص.
- `appVersionName`: `1.0.0` — `appVersionCode`: `1` (ارفعهما في كل إصدار لاحق).
- **تحذير أمني**: لا ترفع ملف `android.keystore` ولا كلمات مروره إلى مستودع الكود (`.gitignore` يمنع ذلك، واحتفظ بنسخة احتياطية مشفرة وآمنة للمفتاح).

---

## 3. الطريقة الأولى: البناء عبر PWABuilder (الأسهل)

1. انشر النسخة المحدثة وتأكد من فتح `https://<DOMAIN>/manifest.webmanifest` بنجاح.
2. افتح `https://www.pwabuilder.com` وأدخل رابط الموقع المنشور.
3. اختر **Package for stores ← Android ← Generate Package**.
4. تحقق من الحقول:
   - **Package ID**: `com.rehhal.app` (أو المعرّف المعتمد).
   - **App name**: `رحّال REHHAL`، **Launcher name**: `رحّال`.
   - **Display mode**: `standalone`، **Fallback behavior**: `Custom Tabs`.
5. نزّل الحزمة المضغوطة؛ ستحتوي على ملف `.aab` جاهز للرفع وملف `signing.keystore` وتعليمات بصمة `SHA-256`.

---

## 4. الطريقة الثانية: البناء عبر Bubblewrap CLI (للمطورين)

1. تهيئة أو تحديث مشروع TWA انطلاقاً من `twa-manifest.json` / المانيفست:
   ```bash
   npx @bubblewrap/cli init --manifest https://<YOUR-DOMAIN>/manifest.webmanifest
   ```
   *(أو استخدام `npx @bubblewrap/cli update` إذا وُجد مجلد مشروع أندرويد مهيأ).*
2. توليد شهادة التوقيع (`Upload Keystore`) عند الطلب:
   - احفظ الملف خارج المستودع (مثلاً `~/secrets/rehhal-release.keystore`) واحتفظ بكلمة المرور وAlias بأمان.
3. بناء حزمة الإنتاج `.aab` ونسخة الاختبار `.apk`:
   ```bash
   npx @bubblewrap/cli build
   ```
   سيُنشأ ملف `app-release-bundle.aab` جاهزاً للرفع على Google Play Console.

---

## 5. إعداد Digital Asset Links (`/.well-known/assetlinks.json`)

لكي يفتح التطبيق بوضع ملء الشاشة (بدون شريط عنوان Chrome أعلى التطبيق)، يجب أن يتطابق `package_name` وبصمة `SHA-256` في الموقع المنشور مع الشهادة التي يوقّع بها Google Play:

### أ) استخراج البصمة قبل النشر (للاختبار المحلي من Upload Key)
```bash
keytool -list -v -keystore ~/secrets/rehhal-release.keystore -alias rehhal-release-key
```
انسخ قيمة `SHA256:` (بصيغة أحرف كبيرة مفصولة بنقطتين `AA:BB:...`).

### ب) استخراج البصمة النهائية لنسخة Google Play (Play App Signing — إلزامي)
عند رفع أول نسخة إلى **Google Play Console**، يتولى Google توقيع الحزمة للمستخدمين بمفتاح توزيع خاص به (**App Signing Key**):
1. افتح **Google Play Console ← اختر تطبيق رحّال ← Release (أو Test and release) ← Setup ← App integrity ← App signing**.
2. انسخ بصمة **SHA-256 certificate fingerprint** من قسم **App signing key certificate** (وليس Upload key فقط).
3. عيّن متغيرات البيئة على الخادم:
   ```env
   ANDROID_PACKAGE_NAME=com.rehhal.app
   ANDROID_SHA256_FINGERPRINT=<الصق_بصمة_SHA256_الحقيقية_هنا>
   ```
   *(أو حدّث مصفوفة `sha256_cert_fingerprints` داخل `public/.well-known/assetlinks.json` قبل النشر؛ يمكنك وضع البصمتين معاً: بصمة App Signing وبصمة Upload Key للاختبار).*
4. تأكد بعد النشر أن الطلب التالي يرجع الحالة `200 OK` وبنوع `application/json` دون أي إعادة توجيه:
   ```bash
   curl -i https://<YOUR-DOMAIN>/.well-known/assetlinks.json
   ```

---

## 6. خطوات رفع النسخة إلى Google Play Console

1. أنشئ تطبيقاً جديداً في Google Play Console (اللغة الأساسية: العربية، مجاني، الفئة: السفر والمحلي).
2. ارفع ملف `app-release-bundle.aab` في مسار **Internal Testing** أولاً.
3. أضف حسابك في قائمة المختبرين وجرّب التثبيت عبر رابط الاختبار الداخلي للتأكد من:
   - اختفاء شريط متصفح Chrome العلوي (نجاح التحقق من `assetlinks.json`).
   - عمل روابط الرحلات والمشاركة وتسجيل الدخول عبر Google بسلاسة.
   - عمل تنبيه انقطاع الإنترنت وصفحة `offline.html`.
4. أكمل استبيانات **Data Safety** و**Privacy Policy URL** (`https://<YOUR-DOMAIN>/privacy`) و**Content Rating**، ثم ارسل الحزمة لمسار الإنتاج (**Production**).
