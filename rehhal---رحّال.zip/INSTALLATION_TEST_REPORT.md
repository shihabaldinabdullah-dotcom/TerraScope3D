# INSTALLATION_TEST_REPORT — تقرير اختبارات التثبيت والتشغيل والأجهزة

تاريخ التنفيذ الفعلي: 2026-11-26  
الأدوات المنفذة: `scripts/verify-rehhal.mjs` + `Playwright (Desktop Chromium 1440×900 & Mobile Android TWA Viewport 390×844 / 375×812)`

---

## 1. الاختبارات الآلية المنفذة فعلياً (Automated Results)

| الاختبار | البيئة | النتيجة | ما تم التحقق منه فعلياً |
| :--- | :--- | :--- | :--- |
| تحميل `/manifest.webmanifest` والتحقق من الحقول | الخادم المحلي + Playwright | **PASS** | `200 OK`، نوع MIME `application/manifest+json`، `name: رحّال REHHAL`، `short_name: رحّال`، `dir: rtl`، `lang: ar`، `display: standalone`، الأيقونات `192/512/maskable`. |
| تسجيل Service Worker وتفعيله | Chromium (Playwright) | **PASS** | تحقق `navigator.serviceWorker.ready` ورجوع `registration.active` على النطاق `/`. |
| زر التثبيت داخل التطبيق (`PWAInstallButton`) | Desktop & Mobile Viewports | **PASS** | زر التثبيت ظاهر في التذييل وقائمة الجوال ويفتح نافذة التوجيه عند غياب حدث التثبيت التلقائي؛ ويخفي نفسه تلقائياً عند وضع `standalone`. |
| تجربة انقطاع الإنترنت (`Offline`) | Chromium `context.setOffline(true)` | **PASS** | ظهور شريط التنبيه `وضع عدم الاتصال` فوراً عند فقد الاتصال ومنع عمليات الحجز/الدفع/التواصل دون اتصال، وتوفر `offline.html` بالخلفية. |
| الـ 30 مساراً + الروابط العميقة + 404 | `verify-rehhal.mjs` + Playwright | **PASS** | جميع المسارات تعيد `200 OK` مع حفظ `?ref=REHHAL101` عبر التنقل وإعادة التحميل والرجوع وتوجيه تسجيل الدخول، وعرض صفحة 404 للمسارات غير الموجودة. |
| التوافق البصري ووضوح الشاشات | `1440×900` و `375×812` | **PASS** | `12/12` اختبار Playwright ناجح، `scrollWidth <= innerWidth` (صفر تمرير أفقي)، عدم وجود أخطاء Console أو ملفات مفقودة. |

---

## 2. اختبارات الأجهزة الحقيقية التي تتطلب تنفيذاً يدوياً (BLOCKED / NOT TESTED في البيئة الآلية)

لأن بيئة الحاوية الحالية تشغّل متصفح Chromium في وضع Headless دون شاشة iOS حقيقية أو متجر Google Play متصل بجهاز Android فعلي:

| السيناريو | الحالة | السبب والإجراء المطلوب عند المعاينة على الأجهزة |
| :--- | :--- | :--- |
| التثبيت الفعلي على Android Chrome عبر نافذة النظام + اختبار TWA من Google Play | **NOT TESTED** | يتطلب فتح الرابط المنشور (`HTTPS`) على هاتف Android حقيقي والضغط على «تثبيت تطبيق رحّال»، ثم تثبيت حزمة Internal Testing بعد ربط `SHA-256`. |
| التثبيت الفعلي على iPhone / iPad Safari (`Add to Home Screen`) وSafe Areas في وضع Standalone | **NOT TESTED** | يتطلب جهاز iOS فعلياً: فتح الرابط في Safari ← زر المشاركة ← إضافة للشاشة الرئيسية ← التحقق من الأيقونة وشريط الحالة وSafe Area. |
| التثبيت الفعلي على Windows Edge / Chrome وmacOS Chrome / Safari (Add to Dock) | **NOT TESTED** | يتطلب فتح الرابط المنشور على Windows وmacOS في متصفح فعلي للتحقق من أيقونة التثبيت بشريط العنوان وفتح التطبيق في نافذة مستقلة. |
| تحديث Service Worker الحي بين إصدارين منشورين (`PWAUpdateBanner`) | **NOT TESTED (آلياً بين إصدارين)** | تم التحقق برمجياً من مستمع `updatefound` وإظهار `PWAUpdateBanner` وإرسال `SKIP_WAITING` + `controllerchange`؛ يلزم اختباره عملياً بعد نشر تحديث على الخادم العام. |
| تسجيل الدخول الفعلي بحساب Google وإتمام حجز + دفع + تقييم حي | **BLOCKED (في Headless بدون جلسة OAuth حية)** | يتطلب تفاعلاً يدوياً مع نافذة مصادقة Google في متصفح عادي. |
