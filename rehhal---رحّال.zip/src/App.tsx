import React, { useEffect } from 'react';
import { BrowserRouter, Navigate, Route, Routes, useNavigate } from 'react-router-dom';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Layout } from './components/Layout';
import { OfflineIndicator } from './components/OfflineIndicator';
import { PWAUpdateBanner } from './components/PWAUpdateBanner';
import { RequireAdmin, RequireAuth, RequireMarketer } from './components/RouteGuards';
import { AuthProvider } from './context/AuthContext';
import { ReferralProvider } from './context/ReferralContext';
import { SettingsProvider } from './context/SettingsContext';
import { ToastProvider } from './context/ToastContext';
import { LEGACY_HASH_ROUTE_MAP, ROUTES } from './routes/routeRegistry';

import { HomePage } from './pages/HomePage';
import { TripsPage } from './pages/TripsPage';
import { TripDetailPage } from './pages/TripDetailPage';
import { BookingDetailPage } from './pages/BookingDetailPage';
import { MyBookingsPage } from './pages/MyBookingsPage';
import { ProfilePage } from './pages/ProfilePage';
import { SupportPage } from './pages/SupportPage';
import { AboutPage } from './pages/AboutPage';
import { PrivacyPage } from './pages/PrivacyPage';
import { TermsPage } from './pages/TermsPage';
import { LoginPage } from './pages/LoginPage';
import { PartnerDashboardPage } from './pages/PartnerDashboardPage';
import { PartnerReferralsPage } from './pages/PartnerReferralsPage';
import { PartnerEarningsPage } from './pages/PartnerEarningsPage';
import { PartnerBookingsPage } from './pages/PartnerBookingsPage';
import { PartnerPayoutsPage } from './pages/PartnerPayoutsPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { AdminTripsPage } from './pages/AdminTripsPage';
import { AdminBookingsPage } from './pages/AdminBookingsPage';
import { AdminCustomersPage } from './pages/AdminCustomersPage';
import { AdminMarketersPage } from './pages/AdminMarketersPage';
import { AdminCommissionsPage } from './pages/AdminCommissionsPage';
import { AdminPaymentsPage } from './pages/AdminPaymentsPage';
import { AdminReviewsPage } from './pages/AdminReviewsPage';
import { AdminContactRequestsPage } from './pages/AdminContactRequestsPage';
import { AdminSettingsPage } from './pages/AdminSettingsPage';
import { NotFoundPage } from './pages/NotFoundPage';

/**
 * Redirects legacy hash routes (e.g. /#/trip/alula-sanctuary?ref=REHHAL101)
 * to clean BrowserRouter URLs without losing referral codes or query params.
 */
const LegacyHashRedirector: React.FC = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const hash = window.location.hash;
    if (!hash || !hash.startsWith('#/')) return;

    const [hashPath, hashQuery] = hash.split('?');
    const mapped = LEGACY_HASH_ROUTE_MAP[hashPath];
    const targetPath = mapped || hashPath.slice(1);
    const search = hashQuery ? `?${hashQuery}` : window.location.search;
    navigate(`${targetPath}${search}`, { replace: true });
  }, [navigate]);

  return null;
};

export default function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <ToastProvider>
          <SettingsProvider>
            <AuthProvider>
              <ReferralProvider>
                <LegacyHashRedirector />
                <Layout>
                  <Routes>
                    {/* Public Routes */}
                    <Route path={ROUTES.HOME} element={<HomePage />} />
                    <Route path={ROUTES.TRIPS} element={<TripsPage />} />
                    <Route path={ROUTES.TRIP_DETAIL_PATTERN} element={<TripDetailPage />} />
                    <Route path={ROUTES.SUPPORT} element={<SupportPage />} />
                    <Route path={ROUTES.ABOUT} element={<AboutPage />} />
                    <Route path={ROUTES.PRIVACY} element={<PrivacyPage />} />
                    <Route path={ROUTES.TERMS} element={<TermsPage />} />
                    <Route path={ROUTES.LOGIN} element={<LoginPage />} />
                    <Route
                      path={ROUTES.PARTNERS}
                      element={
                        <RequireAuth>
                          <Navigate to={ROUTES.profileAffiliate()} replace />
                        </RequireAuth>
                      }
                    />

                    {/* Authenticated Customer Routes */}
                    <Route
                      path={ROUTES.BOOKING_DETAIL_PATTERN}
                      element={
                        <RequireAuth>
                          <BookingDetailPage />
                        </RequireAuth>
                      }
                    />
                    <Route
                      path={ROUTES.MY_BOOKINGS}
                      element={
                        <RequireAuth>
                          <MyBookingsPage />
                        </RequireAuth>
                      }
                    />
                    <Route
                      path={ROUTES.PROFILE}
                      element={
                        <RequireAuth>
                          <ProfilePage />
                        </RequireAuth>
                      }
                    />

                    {/* Partner Registration redirected into Profile -> التسويق بالعمولة, Dashboard strictly protected */}
                    <Route
                      path={ROUTES.PARTNERS_REGISTER}
                      element={
                        <RequireAuth>
                          <Navigate to={ROUTES.profileAffiliate()} replace />
                        </RequireAuth>
                      }
                    />
                    <Route
                      path={ROUTES.PARTNERS_DASHBOARD}
                      element={
                        <RequireMarketer>
                          <PartnerDashboardPage />
                        </RequireMarketer>
                      }
                    />
                    <Route
                      path={ROUTES.PARTNERS_REFERRALS}
                      element={
                        <RequireMarketer>
                          <PartnerReferralsPage />
                        </RequireMarketer>
                      }
                    />
                    <Route
                      path={ROUTES.PARTNERS_EARNINGS}
                      element={
                        <RequireMarketer>
                          <PartnerEarningsPage />
                        </RequireMarketer>
                      }
                    />
                    <Route
                      path={ROUTES.PARTNERS_BOOKINGS}
                      element={
                        <RequireMarketer>
                          <PartnerBookingsPage />
                        </RequireMarketer>
                      }
                    />
                    <Route
                      path={ROUTES.PARTNERS_PAYOUTS}
                      element={
                        <RequireMarketer>
                          <PartnerPayoutsPage />
                        </RequireMarketer>
                      }
                    />

                    {/* Protected Admin Console */}
                    <Route
                      path={ROUTES.ADMIN}
                      element={
                        <RequireAdmin>
                          <AdminDashboardPage />
                        </RequireAdmin>
                      }
                    />
                    <Route
                      path={ROUTES.ADMIN_TRIPS}
                      element={
                        <RequireAdmin>
                          <AdminTripsPage />
                        </RequireAdmin>
                      }
                    />
                    <Route
                      path={ROUTES.ADMIN_BOOKINGS}
                      element={
                        <RequireAdmin>
                          <AdminBookingsPage />
                        </RequireAdmin>
                      }
                    />
                    <Route
                      path={ROUTES.ADMIN_CUSTOMERS}
                      element={
                        <RequireAdmin>
                          <AdminCustomersPage />
                        </RequireAdmin>
                      }
                    />
                    <Route
                      path={ROUTES.ADMIN_MARKETERS}
                      element={
                        <RequireAdmin>
                          <AdminMarketersPage />
                        </RequireAdmin>
                      }
                    />
                    <Route
                      path={ROUTES.ADMIN_COMMISSIONS}
                      element={
                        <RequireAdmin>
                          <AdminCommissionsPage />
                        </RequireAdmin>
                      }
                    />
                    <Route
                      path={ROUTES.ADMIN_PAYMENTS}
                      element={
                        <RequireAdmin>
                          <AdminPaymentsPage />
                        </RequireAdmin>
                      }
                    />
                    <Route
                      path={ROUTES.ADMIN_REVIEWS}
                      element={
                        <RequireAdmin>
                          <AdminReviewsPage />
                        </RequireAdmin>
                      }
                    />
                    <Route
                      path={ROUTES.ADMIN_CONTACTS}
                      element={
                        <RequireAdmin>
                          <AdminContactRequestsPage />
                        </RequireAdmin>
                      }
                    />
                    <Route
                      path={ROUTES.ADMIN_SETTINGS}
                      element={
                        <RequireAdmin>
                          <AdminSettingsPage />
                        </RequireAdmin>
                      }
                    />

                    {/* 404 Catch-All */}
                    <Route path="*" element={<NotFoundPage />} />
                  </Routes>
                </Layout>
                <OfflineIndicator />
                <PWAUpdateBanner />
              </ReferralProvider>
            </AuthProvider>
          </SettingsProvider>
        </ToastProvider>
      </BrowserRouter>
    </ErrorBoundary>
  );
}
