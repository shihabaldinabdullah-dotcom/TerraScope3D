export const PLATFORM_CURRENCY = 'EGP' as const;
export const PLATFORM_CURRENCY_SYMBOL = 'ج.م' as const;

export function isApprovedEgpCurrency(currency?: string | null): boolean {
  return currency === PLATFORM_CURRENCY;
}

export function formatEgpAmount(amount: number): string {
  return `${amount.toLocaleString('en-US')} ${PLATFORM_CURRENCY_SYMBOL}`;
}

export function formatCustomerAmount(
  amount?: number | null,
  currency?: string | null
): string | null {
  if (typeof amount !== 'number' || !Number.isFinite(amount) || amount <= 0) {
    return null;
  }
  if (!isApprovedEgpCurrency(currency)) {
    return null;
  }
  return formatEgpAmount(amount);
}

export function formatCustomerLedgerAmount(
  amount?: number | null,
  currency?: string | null
): { text: string; needsReview: boolean } {
  const safeAmount = typeof amount === 'number' && Number.isFinite(amount) ? amount : 0;
  if (safeAmount === 0 && (!currency || isApprovedEgpCurrency(currency))) {
    return { text: formatEgpAmount(0), needsReview: false };
  }
  if (!isApprovedEgpCurrency(currency)) {
    return {
      text: 'بانتظار مراجعة العملة من الإدارة',
      needsReview: true,
    };
  }
  return {
    text: formatEgpAmount(safeAmount),
    needsReview: false,
  };
}

export function formatAdminAmount(
  amount?: number | null,
  currency?: string | null
): { text: string; needsReview: boolean; sourceCurrency: string } {
  const sourceCurrency = currency || 'SAR';
  const safeAmount = typeof amount === 'number' && Number.isFinite(amount) ? amount : 0;
  if (isApprovedEgpCurrency(sourceCurrency)) {
    return {
      text: formatEgpAmount(safeAmount),
      needsReview: false,
      sourceCurrency: PLATFORM_CURRENCY,
    };
  }
  return {
    text: `${safeAmount.toLocaleString('en-US')} ${sourceCurrency} (تتطلب مراجعة EGP)`,
    needsReview: true,
    sourceCurrency,
  };
}
