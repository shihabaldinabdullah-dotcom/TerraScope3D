import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowRight, CheckCircle2, CreditCard, ShieldCheck, XCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { ROUTES } from '../routes/routeRegistry';
import {
  cancelPendingBooking,
  confirmBookingPayment,
  fetchBookingById,
} from '../services/firestoreService';
import type { Booking } from '../types';
import { formatCustomerLedgerAmount, isApprovedEgpCurrency } from '../utils/currency';

const STATUS_LABELS: Record<Booking['status'], string> = {
  pending_payment: 'بانتظار السداد',
  confirmed: 'مؤكد ومدفوع',
  completed: 'رحلة مكتملة',
  cancelled: 'ملغي',
};

export const BookingDetailPage: React.FC = () => {
  const { bookingId = '' } = useParams();
  const { user, isAdmin } = useAuth();
  const { showToast } = useToast();
  const isOnline = useOnlineStatus();

  const [booking, setBooking] = useState<Booking | null>(null);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'mada' | 'visa' | 'apple_pay' | 'bank_transfer'>('mada');

  const loadBooking = () => {
    setLoading(true);
    fetchBookingById(bookingId)
      .then((b) => setBooking(b))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadBooking();
  }, [bookingId]);

  const handlePayNow = async () => {
    if (!booking || !user || processing) return;
    if (!isOnline) {
      showToast('لا يمكن تأكيد الدفع دون اتصال بالإنترنت.', 'error');
      return;
    }
    setProcessing(true);
    try {
      const ref = await confirmBookingPayment({
        bookingId: booking.id,
        userId: user.uid,
        amount: booking.totalAmount,
        paymentMethod,
      });
      showToast(`تم توثيق الدفع بنجاح (${ref})`, 'success');
      loadBooking();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'فشل تنفيذ الدفع', 'error');
    } finally {
      setProcessing(false);
    }
  };

  const handleCancel = async () => {
    if (!booking || processing) return;
    if (!isOnline) {
      showToast('يتطلب إلغاء الحجز اتصالاً بالإنترنت.', 'error');
      return;
    }
    setProcessing(true);
    try {
      await cancelPendingBooking(booking.id);
      showToast('تم إلغاء الحجز بنجاح', 'info');
      loadBooking();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'تعذر إلغاء الحجز', 'error');
    } finally {
      setProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-12">
        <div className="h-72 rounded-2xl bg-[#12233B] animate-pulse" />
      </div>
    );
  }

  if (!booking) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-3">الحجز غير موجود</h1>
        <Link
          to={ROUTES.MY_BOOKINGS}
          className="min-h-[44px] inline-flex items-center justify-center rounded-xl bg-[#C5A15B] text-[#0B172A] px-6 py-2.5 text-sm font-bold"
        >
          الانتقال إلى حجوزاتي
        </Link>
      </div>
    );
  }

  const isBookingOwner = user?.uid === booking.userId;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 sm:py-10 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <Link
          to={isAdmin ? ROUTES.ADMIN_BOOKINGS : ROUTES.MY_BOOKINGS}
          className="min-h-[40px] inline-flex items-center gap-2 text-sm text-[#CBD5E1] hover:text-[#C5A15B]"
        >
          <ArrowRight className="w-4 h-4" />
          <span>{isAdmin ? 'العودة إلى حجوزات الإدارة' : 'العودة إلى حجوزاتي'}</span>
        </Link>
        <span className="text-xs font-mono-num text-[#9BA8BC]">رقم الحجز: {booking.id}</span>
      </div>

      <div className="rounded-2xl bg-[#12233B] border border-[#C5A15B]/30 p-6 sm:p-8 space-y-6">
        <div className="flex flex-wrap items-start justify-between gap-4 pb-5 border-b border-white/10">
          <div>
            <span className="text-xs text-[#C5A15B] block mb-1">تفاصيل الحجز</span>
            <h1 className="text-2xl font-bold text-[#F4F1EA]">{booking.tripTitle}</h1>
          </div>
          <div className="text-left">
            <span className="text-xs text-[#9BA8BC] block">حالة الطلب</span>
            <span className="text-sm font-bold text-[#C5A15B]">{STATUS_LABELS[booking.status]}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
          <div className="rounded-xl bg-[#0B172A] p-4 border border-white/10 space-y-1">
            <span className="text-xs text-[#9BA8BC]">بيانات العميل</span>
            <div className="font-semibold text-[#F4F1EA]">{booking.customerName}</div>
            <div className="text-xs text-[#CBD5E1]">{booking.customerEmail}</div>
            <div className="text-xs text-[#CBD5E1] font-mono-num">{booking.customerPhone}</div>
          </div>

          <div className="rounded-xl bg-[#0B172A] p-4 border border-white/10 space-y-1">
            <span className="text-xs text-[#9BA8BC]">تفاصيل الموعد والسداد</span>
            <div className="font-semibold text-[#F4F1EA] font-mono-num">التاريخ: {booking.travelDate}</div>
            <div className="text-xs text-[#CBD5E1] font-mono-num">عدد الضيوف: {booking.guests}</div>
            <div className="text-base font-bold text-[#C5A15B] font-mono-num pt-1">
              الإجمالي: {formatCustomerLedgerAmount(booking.totalAmount, booking.currency).text}
            </div>
          </div>
        </div>

        {booking.referralCode && (
          <div className="rounded-xl bg-[#0B172A] border border-[#C5A15B]/25 p-4 flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="text-[#CBD5E1]">
              تم توثيق الإحالة عبر كود الشريك:{' '}
              <strong className="text-[#C5A15B] font-mono-num">{booking.referralCode}</strong>
            </span>
            <span className="text-[#9BA8BC]">حالة العمولة: {booking.commissionStatus}</span>
          </div>
        )}

        {booking.paymentStatus === 'paid' && (
          <div className="rounded-xl bg-emerald-500/10 border border-emerald-500/35 p-4 flex items-center gap-3 text-sm text-emerald-200">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <div className="font-bold">تم تأكيد الدفع بنجاح</div>
              {booking.paymentRef && (
                <div className="text-xs font-mono-num text-emerald-300 mt-0.5">
                  المرجع البنكي: {booking.paymentRef} · وسيلة الدفع: {booking.paymentMethod}
                </div>
              )}
            </div>
          </div>
        )}

        {booking.status === 'cancelled' && (
          <div className="rounded-xl bg-red-500/10 border border-red-500/35 p-4 flex items-center gap-3 text-sm text-red-200">
            <XCircle className="w-5 h-5 text-red-400 shrink-0" />
            <span>تم إلغاء هذا الحجز.</span>
          </div>
        )}

        {/* Payment Action Panel for Pending Booking Owner */}
        {isBookingOwner && booking.status === 'pending_payment' && (
          <div className="pt-4 border-t border-white/10 space-y-4">
            <h2 className="text-base font-bold text-[#F4F1EA] flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-[#C5A15B]" />
              <span>إتمام الدفع وتأكيد الحجز</span>
            </h2>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'mada', label: 'بطاقة مدى' },
                { id: 'visa', label: 'Visa / Mastercard' },
                { id: 'apple_pay', label: 'Apple Pay' },
                { id: 'bank_transfer', label: 'تحويل بنكي' },
              ].map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setPaymentMethod(m.id as typeof paymentMethod)}
                  className={`min-h-[44px] rounded-xl border px-3 py-2 text-xs font-semibold transition ${
                    paymentMethod === m.id
                      ? 'bg-[#C5A15B] text-[#0B172A] border-[#C5A15B]'
                      : 'bg-[#0B172A] text-[#CBD5E1] border-white/15 hover:border-[#C5A15B]/50'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <button
                type="button"
                onClick={handlePayNow}
                disabled={processing || !isOnline || !isApprovedEgpCurrency(booking.currency)}
                className="flex-1 min-h-[48px] rounded-xl bg-[#C5A15B] text-[#0B172A] text-sm font-bold hover:opacity-90 disabled:opacity-50 transition"
              >
                {processing
                  ? 'جاري التحقق من السداد...'
                  : isApprovedEgpCurrency(booking.currency)
                  ? `تأكيد ودفع ${formatCustomerLedgerAmount(booking.totalAmount, booking.currency).text}`
                  : 'بانتظار مراجعة العملة من الإدارة'}
              </button>
              <button
                type="button"
                onClick={handleCancel}
                disabled={processing || !isOnline}
                className="min-h-[48px] rounded-xl border border-red-500/40 text-red-300 px-5 text-sm font-semibold hover:bg-red-500/10 disabled:opacity-50 transition"
              >
                إلغاء الحجز
              </button>
            </div>

            <div className="flex items-center gap-2 text-xs text-[#9BA8BC]">
              <ShieldCheck className="w-4 h-4 text-[#C5A15B]" />
              <span>تتطلب عملية الدفع اتصالاً مباشراً بالخادم لتوثيق العملية ومنع التكرار.</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
