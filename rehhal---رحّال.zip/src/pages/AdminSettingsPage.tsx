import React, { useEffect, useState } from 'react';
import { AdminSubNav } from '../components/SubNav';
import { usePlatformSettings } from '../context/SettingsContext';
import { useToast } from '../context/ToastContext';
import {
  adminSavePlatformSettings,
  DEFAULT_PLATFORM_SETTINGS,
  fetchPlatformSettings,
} from '../services/firestoreService';
import type { PlatformSettings } from '../types';

export const AdminSettingsPage: React.FC = () => {
  const { showToast } = useToast();
  const { refreshSettings } = usePlatformSettings();
  const [settings, setSettings] = useState<PlatformSettings>(DEFAULT_PLATFORM_SETTINGS);
  const [pwaDiagnostics, setPwaDiagnostics] = useState<Record<string, boolean> | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchPlatformSettings().then(setSettings);
    fetch('/api/pwa/diagnostics')
      .then((r) => (r.ok ? r.json() : null))
      .then(setPwaDiagnostics)
      .catch(() => undefined);
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await adminSavePlatformSettings(settings);
      await refreshSettings();
      showToast('تم حفظ إعدادات المنصة والتواصل وتحديثها مباشرة', 'success');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'تعذر حفظ الإعدادات', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <AdminSubNav />
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        <form
          onSubmit={handleSave}
          className="lg:col-span-7 rounded-2xl bg-[#12233B] border border-white/10 p-6 space-y-5"
        >
            <div>
              <h1 className="text-xl font-bold text-[#F4F1EA]">إعدادات المنصة والتواصل</h1>
              <p className="text-xs text-[#9BA8BC] mt-1">
                العملة الأساسية المعتمدة في المنصة: الجنيه المصري (EGP / ج.م). تنعكس أرقام التواصل والنبذة وروابط التواصل مباشرة في التذييل وصفحة تواصل معنا.
              </p>
              {settings.currency !== 'EGP' && (
                <div className="mt-3 rounded-xl border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs text-amber-200">
                  تنبيه: الإعدادات المحفوظة كانت مضبوطة على {settings.currency}. يرجى مراجعة الحد الأدنى للسحب بالجنيه المصري (ج.م) ثم الحفظ لتوحيد الإعدادات على EGP.
                </div>
              )}
            </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="set-rate" className="block text-xs text-[#CBD5E1] mb-1">
                نسبة العمولة الافتراضية (مثل 0.08)
              </label>
              <input
                id="set-rate"
                type="number"
                step="0.01"
                min="0.01"
                max="0.35"
                value={settings.commissionRate}
                onChange={(e) => setSettings({ ...settings, commissionRate: Number(e.target.value) })}
                className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-sm font-mono-num text-[#F4F1EA]"
              />
            </div>

            <div>
              <label htmlFor="set-min" className="block text-xs text-[#CBD5E1] mb-1">
                الحد الأدنى للسحب (ج.م)
              </label>
              <input
                id="set-min"
                type="number"
                min="50"
                max="10000"
                value={settings.minPayoutAmount}
                onChange={(e) => setSettings({ ...settings, minPayoutAmount: Number(e.target.value) })}
                className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-sm font-mono-num text-[#F4F1EA]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="set-email" className="block text-xs text-[#CBD5E1] mb-1">
                بريد الدعم الرسمي
              </label>
              <input
                id="set-email"
                type="email"
                value={settings.supportEmail}
                onChange={(e) => setSettings({ ...settings, supportEmail: e.target.value })}
                dir="ltr"
                className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-sm text-[#F4F1EA]"
              />
            </div>

            <div>
              <label htmlFor="set-phone" className="block text-xs text-[#CBD5E1] mb-1">
                رقم الهاتف الرسمي (للاتصال المباشر)
              </label>
              <input
                id="set-phone"
                type="tel"
                value={settings.supportPhone}
                onChange={(e) => setSettings({ ...settings, supportPhone: e.target.value })}
                dir="ltr"
                className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-sm font-mono-num text-[#F4F1EA]"
              />
            </div>
          </div>

          <div>
            <label htmlFor="set-whatsapp" className="block text-xs text-[#CBD5E1] mb-1">
              رقم الواتساب الرسمي (بالصيغة الدولية مثل +966500000100)
            </label>
            <input
              id="set-whatsapp"
              type="tel"
              value={settings.whatsappNumber || ''}
              onChange={(e) => setSettings({ ...settings, whatsappNumber: e.target.value })}
              dir="ltr"
              placeholder="+966500000100"
              className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-sm font-mono-num text-[#F4F1EA]"
            />
          </div>

          <div>
            <label htmlFor="set-about" className="block text-xs text-[#CBD5E1] mb-1">
              نبذة عن منصة رحّال (تظهر في الصفحة الرئيسية والتذييل)
            </label>
            <textarea
              id="set-about"
              rows={3}
              maxLength={600}
              value={settings.aboutText || ''}
              onChange={(e) => setSettings({ ...settings, aboutText: e.target.value })}
              className="w-full rounded-xl bg-[#0B172A] border border-white/15 px-3 py-2 text-sm text-[#F4F1EA]"
            />
          </div>

          <div className="pt-2 border-t border-white/10 space-y-3">
            <h2 className="text-xs font-bold text-[#C5A15B]">
              روابط حسابات التواصل الاجتماعي (تظهر في التذييل عند تعبئتها فقط)
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label htmlFor="set-x" className="block text-[11px] text-[#9BA8BC] mb-1">
                  رابط منصة X
                </label>
                <input
                  id="set-x"
                  type="url"
                  value={settings.xUrl || ''}
                  onChange={(e) => setSettings({ ...settings, xUrl: e.target.value })}
                  dir="ltr"
                  placeholder="https://x.com/..."
                  className="w-full min-h-[40px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-xs text-[#F4F1EA]"
                />
              </div>
              <div>
                <label htmlFor="set-ig" className="block text-[11px] text-[#9BA8BC] mb-1">
                  رابط إنستغرام
                </label>
                <input
                  id="set-ig"
                  type="url"
                  value={settings.instagramUrl || ''}
                  onChange={(e) => setSettings({ ...settings, instagramUrl: e.target.value })}
                  dir="ltr"
                  placeholder="https://instagram.com/..."
                  className="w-full min-h-[40px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-xs text-[#F4F1EA]"
                />
              </div>
              <div>
                <label htmlFor="set-tiktok" className="block text-[11px] text-[#9BA8BC] mb-1">
                  رابط تيك توك
                </label>
                <input
                  id="set-tiktok"
                  type="url"
                  value={settings.tiktokUrl || ''}
                  onChange={(e) => setSettings({ ...settings, tiktokUrl: e.target.value })}
                  dir="ltr"
                  placeholder="https://tiktok.com/@..."
                  className="w-full min-h-[40px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-xs text-[#F4F1EA]"
                />
              </div>
              <div>
                <label htmlFor="set-snap" className="block text-[11px] text-[#9BA8BC] mb-1">
                  رابط سناب شات
                </label>
                <input
                  id="set-snap"
                  type="url"
                  value={settings.snapchatUrl || ''}
                  onChange={(e) => setSettings({ ...settings, snapchatUrl: e.target.value })}
                  dir="ltr"
                  placeholder="https://snapchat.com/add/..."
                  className="w-full min-h-[40px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-xs text-[#F4F1EA]"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="min-h-[46px] rounded-xl bg-[#C5A15B] text-[#0B172A] px-6 py-2.5 text-sm font-bold hover:opacity-90 disabled:opacity-50"
          >
            {saving ? 'جاري الحفظ...' : 'حفظ الإعدادات'}
          </button>
        </form>

        <div className="lg:col-span-5 rounded-2xl bg-[#12233B] border border-white/10 p-6 space-y-4">
          <h2 className="text-lg font-bold text-[#F4F1EA]">فحص جاهزية PWA و Android</h2>
          {pwaDiagnostics ? (
            <ul className="space-y-2.5 text-xs">
              {Object.entries(pwaDiagnostics).map(([k, ok]) => (
                <li key={k} className="flex items-center justify-between border-b border-white/10 pb-2">
                  <span className="font-mono-num text-[#CBD5E1]">{k}</span>
                  <span className={ok ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                    {ok ? 'متوفر' : 'يتطلب إعداداً'}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-xs text-[#9BA8BC]">جاري التحقق من ملفات PWA...</p>
          )}
        </div>
      </div>
    </div>
  );
};
