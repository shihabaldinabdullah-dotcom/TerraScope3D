import React, { useEffect } from 'react';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { LogIn, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useReferral } from '../context/ReferralContext';
import { useToast } from '../context/ToastContext';
import { ROUTES } from '../routes/routeRegistry';

export const LoginPage: React.FC = () => {
  const { user, signingIn, signInWithGoogle } = useAuth();
  const { activeReferral } = useReferral();
  const { showToast } = useToast();
  const [searchParams] = useSearchParams();
  const location = useLocation();
  const navigate = useNavigate();

  const rawRedirect =
    searchParams.get('redirect') ||
    (location.state as { from?: string } | null)?.from ||
    ROUTES.HOME;

  // Prevent open-redirect attacks: only allow safe internal app paths
  const safeRedirect = rawRedirect.startsWith('/') && !rawRedirect.startsWith('//')
    ? rawRedirect
    : ROUTES.HOME;

  useEffect(() => {
    if (user) {
      navigate(safeRedirect, { replace: true });
    }
  }, [user, navigate, safeRedirect]);

  const handleLogin = async () => {
    try {
      const signedUser = await signInWithGoogle();
      if (signedUser) {
        showToast('تم تسجيل الدخول بنجاح', 'success');
        navigate(safeRedirect, { replace: true });
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'تعذر تسجيل الدخول عبر Google';
      showToast(msg, 'error');
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-14">
      <div className="rounded-2xl bg-[#12233B] border border-[#C5A15B]/30 p-8 space-y-6 text-center">
        <div>
          <div className="font-brand-latin text-2xl font-bold text-[#C5A15B] mb-1">REHHAL</div>
          <h1 className="text-2xl font-bold text-[#F4F1EA]">تسجيل الدخول إلى رحّال</h1>
          <p className="text-sm text-[#9BA8BC] mt-2 leading-relaxed">
            استخدم حساب Google للدخول السريع والآمن وإتمام حجوزاتك أو إدارة حساب الشريك.
          </p>
        </div>

        {activeReferral && (
          <div className="rounded-xl bg-[#0B172A] border border-[#C5A15B]/30 p-3.5 text-xs text-[#CBD5E1]">
            كود الإحالة النشط{' '}
            <strong className="text-[#C5A15B] font-mono-num">{activeReferral.code}</strong>{' '}
            سيتم الاحتفاظ به تلقائياً بعد تسجيل الدخول.
          </div>
        )}

        <button
          type="button"
          onClick={handleLogin}
          disabled={signingIn}
          className="w-full min-h-[48px] inline-flex items-center justify-center gap-2.5 rounded-xl bg-[#C5A15B] text-[#0B172A] px-6 py-3 text-base font-bold hover:opacity-90 disabled:opacity-50 transition"
        >
          <LogIn className="w-5 h-5" />
          <span>{signingIn ? 'جاري المصادقة...' : 'المتابعة باستخدام Google'}</span>
        </button>

        <div className="flex items-center justify-center gap-2 text-xs text-[#9BA8BC]">
          <ShieldCheck className="w-4 h-4 text-[#C5A15B]" />
          <span>يتم حفظ مسار العودة إلى: {safeRedirect}</span>
        </div>
      </div>
    </div>
  );
};
