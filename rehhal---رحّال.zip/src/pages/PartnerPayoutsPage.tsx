import React, { useEffect, useState } from 'react';
import { PartnerSubNav } from '../components/SubNav';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { fetchMarketerPayouts, submitPayoutRequest } from '../services/firestoreService';
import type { PayoutRequest } from '../types';
import { formatCustomerLedgerAmount } from '../utils/currency';

const PAYOUT_STATUS_AR: Record<PayoutRequest['status'], string> = {
  pending: 'قيد المراجعة',
  approved: 'معتمد للصرف',
  paid: 'تم التحويل',
  rejected: 'مرفوض',
};

export const PartnerPayoutsPage: React.FC = () => {
  const { marketer, refreshProfile } = useAuth();
  const { showToast } = useToast();
  const isOnline = useOnlineStatus();

  const [payouts, setPayouts] = useState<PayoutRequest[]>([]);
  const [amount, setAmount] = useState('');
  const [iban, setIban] = useState('');
  const [bankName, setBankName] = useState('');
  const [accountHolder, setAccountHolder] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const loadPayouts = () => {
    if (!marketer) return;
    fetchMarketerPayouts(marketer.uid).then(setPayouts);
  };

  useEffect(() => {
    if (marketer) {
      setAccountHolder((p) => p || marketer.fullName);
      loadPayouts();
    }
  }, [marketer]);

  if (!marketer) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    if (!isOnline) {
      showToast('لا يمكن إرسال طلب السحب دون اتصال بالإنترنت', 'error');
      return;
    }

    const numericAmount = Number(amount);
    if (!Number.isFinite(numericAmount) || numericAmount < 100) {
      showToast('الحد الأدنى للسحب 100 ج.م', 'error');
      return;
    }

    setSubmitting(true);
    try {
      await submitPayoutRequest({
        marketer,
        amount: numericAmount,
        iban,
        bankName,
        accountHolder,
      });
      showToast('تم إرسال طلب السحب للمراجعة بنجاح', 'success');
      setAmount('');
      await refreshProfile();
      loadPayouts();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'تعذر تقديم طلب السحب', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div>
      <PartnerSubNav />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-5">
          <form
            onSubmit={handleSubmit}
            className="rounded-2xl bg-[#12233B] border border-[#C5A15B]/30 p-6 space-y-4"
          >
            <div>
              <h1 className="text-xl font-bold text-[#F4F1EA]">طلب سحب الأرباح</h1>
              <p className="text-xs text-[#9BA8BC] mt-1">
                الرصيد القابل للسحب:{' '}
                <strong className="text-[#C5A15B] font-mono-num">
                  {formatCustomerLedgerAmount(marketer.availableBalance, marketer.currency).text}
                </strong>
              </p>
            </div>

            <div>
              <label htmlFor="payout-amount" className="block text-xs font-semibold text-[#CBD5E1] mb-1.5">
                المبلغ المطلوب (ج.م) *
              </label>
              <input
                id="payout-amount"
                type="number"
                min={100}
                max={Math.max(100, marketer.availableBalance)}
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="500"
                className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA] font-mono-num"
              />
            </div>

            <div>
              <label htmlFor="payout-bank" className="block text-xs font-semibold text-[#CBD5E1] mb-1.5">
                اسم البنك *
              </label>
              <input
                id="payout-bank"
                type="text"
                required
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                placeholder="مصرف الراجحي / البنك الأهلي"
                className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA]"
              />
            </div>

            <div>
              <label htmlFor="payout-iban" className="block text-xs font-semibold text-[#CBD5E1] mb-1.5">
                رقم الآيبان (IBAN) *
              </label>
              <input
                id="payout-iban"
                type="text"
                required
                value={iban}
                onChange={(e) => setIban(e.target.value)}
                placeholder="SA0000000000000000000000"
                className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA] font-mono-num uppercase"
                dir="ltr"
              />
            </div>

            <div>
              <label htmlFor="payout-holder" className="block text-xs font-semibold text-[#CBD5E1] mb-1.5">
                اسم صاحب الحساب *
              </label>
              <input
                id="payout-holder"
                type="text"
                required
                value={accountHolder}
                onChange={(e) => setAccountHolder(e.target.value)}
                className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA]"
              />
            </div>

            <button
              type="submit"
              disabled={submitting || !isOnline || marketer.availableBalance < 100}
              className="w-full min-h-[48px] rounded-xl bg-[#C5A15B] text-[#0B172A] text-sm font-bold hover:opacity-90 disabled:opacity-50 transition"
            >
              {submitting ? 'جاري إرسال الطلب...' : 'إرسال طلب السحب'}
            </button>
          </form>
        </div>

        <div className="lg:col-span-7 space-y-4">
          <h2 className="text-lg font-bold text-[#F4F1EA]">سجل طلبات السحب</h2>
          <div className="rounded-2xl bg-[#12233B] border border-white/10 overflow-x-auto">
            {payouts.length === 0 ? (
              <div className="p-8 text-center text-sm text-[#9BA8BC]">لا توجد طلبات سحب مسجلة حتى الآن.</div>
            ) : (
              <table className="w-full text-right text-sm">
                <thead className="border-b border-white/10 text-xs text-[#9BA8BC]">
                  <tr>
                    <th className="px-4 py-3">رقم الطلب</th>
                    <th className="px-4 py-3">المبلغ</th>
                    <th className="px-4 py-3">البنك</th>
                    <th className="px-4 py-3">الحالة</th>
                    <th className="px-4 py-3">ملاحظات الإدارة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/10">
                  {payouts.map((p) => (
                    <tr key={p.id} className="hover:bg-white/5">
                      <td className="px-4 py-3 font-mono-num text-xs">{p.id}</td>
                      <td className="px-4 py-3 font-mono-num font-bold text-[#C5A15B]">
                        {formatCustomerLedgerAmount(p.amount, p.currency).text}
                      </td>
                      <td className="px-4 py-3 text-xs">{p.bankName}</td>
                      <td className="px-4 py-3 text-xs">{PAYOUT_STATUS_AR[p.status]}</td>
                      <td className="px-4 py-3 text-xs text-[#9BA8BC]">{p.adminNote || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
