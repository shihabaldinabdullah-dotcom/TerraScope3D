import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  Calendar,
  ArrowRight,
  Check,
  FileText,
  MessageCircle,
  Phone,
  Share2,
  ShieldCheck,
  Star,
  Users,
} from 'lucide-react';
import { ContactRequestModal } from '../components/ContactRequestModal';
import { useAuth } from '../context/AuthContext';
import { useReferral } from '../context/ReferralContext';
import { useToast } from '../context/ToastContext';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { ROUTES } from '../routes/routeRegistry';
import {
  createBookingWithAttribution,
  fetchTripById,
  fetchTripReviews,
  fetchUserCompletedBookingsForTrip,
  saveTripReview,
} from '../services/firestoreService';
import {
  TRIP_CATEGORY_LABELS,
  type Booking,
  type ContactRequestMethod,
  type Trip,
  type TripReview,
} from '../types';
import { formatEgpAmount, isApprovedEgpCurrency } from '../utils/currency';

export const TripDetailPage: React.FC = () => {
  const { tripId = '' } = useParams();
  const navigate = useNavigate();
  const { user, profile, marketer, isMarketer } = useAuth();
  const { activeReferral, verifyBeforeBooking, referralError } = useReferral();
  const { showToast } = useToast();
  const isOnline = useOnlineStatus();

  const [trip, setTrip] = useState<Trip | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [contactModalOpen, setContactModalOpen] = useState(false);
  const [contactModalMethod, setContactModalMethod] = useState<ContactRequestMethod>('whatsapp');

  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [travelDate, setTravelDate] = useState('');
  const [guests, setGuests] = useState(2);
  const [notes, setNotes] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  // Trip Reviews (strictly gated to completed bookings only)
  const [tripReviews, setTripReviews] = useState<TripReview[]>([]);
  const [completedBookings, setCompletedBookings] = useState<Booking[]>([]);
  const [selectedBookingId, setSelectedBookingId] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [savingReview, setSavingReview] = useState(false);

  const loadReviews = useCallback(async (id: string) => {
    const list = await fetchTripReviews(id);
    setTripReviews(list);
    return list;
  }, []);

  useEffect(() => {
    setLoading(true);
    fetchTripById(tripId)
      .then((found) => {
        setTrip(found);
        if (found?.departureDates?.length) {
          setTravelDate(found.departureDates[0]);
        } else {
          setTravelDate('');
        }
      })
      .finally(() => setLoading(false));

    if (tripId) {
      loadReviews(tripId);
    }
  }, [tripId, loadReviews]);

  useEffect(() => {
    if (user) {
      setCustomerName((prev) => prev || profile?.displayName || user.displayName || '');
      setCustomerEmail((prev) => prev || profile?.email || user.email || '');
      setCustomerPhone((prev) => prev || profile?.phone || '');
    }
  }, [user, profile]);

  useEffect(() => {
    if (!user || !tripId) {
      setCompletedBookings([]);
      setSelectedBookingId('');
      return;
    }
    fetchUserCompletedBookingsForTrip(user.uid, tripId).then((eligible) => {
      setCompletedBookings(eligible);
      if (eligible.length > 0) {
        setSelectedBookingId((prev) =>
          eligible.some((b) => b.id === prev) ? prev : eligible[0].id
        );
      }
    });
  }, [user, tripId]);

  useEffect(() => {
    if (!selectedBookingId) return;
    const existing = tripReviews.find((r) => r.bookingId === selectedBookingId);
    if (existing) {
      setReviewRating(existing.rating);
      setReviewComment(existing.comment || '');
    } else {
      setReviewRating(5);
      setReviewComment('');
    }
  }, [selectedBookingId, tripReviews]);

  const averageReview = useMemo(() => {
    if (tripReviews.length === 0) return null;
    const sum = tripReviews.reduce((acc, r) => acc + r.rating, 0);
    return (sum / tripReviews.length).toFixed(1);
  }, [tripReviews]);

  const handleCopyShareLink = async () => {
    if (!trip) return;
    const refToShare =
      isMarketer && marketer?.referralCode ? marketer.referralCode : activeReferral?.code || '';
    const shareUrl = refToShare
      ? ROUTES.absoluteTripShareUrl(trip.id, refToShare)
      : `${window.location.origin}${ROUTES.tripDetail(trip.id)}`;
    try {
      await navigator.clipboard.writeText(shareUrl);
      showToast('تم نسخ رابط الرحلة بنجاح', 'success');
    } catch {
      showToast('تعذر النسخ التلقائي، يمكنك نسخ الرابط من شريط العنوان', 'info');
    }
  };

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trip || submitting) return;

    if (!user) {
      const returnPath = ROUTES.tripDetail(trip.id, activeReferral?.code);
      showToast('يرجى تسجيل الدخول لإتمام الحجز وسيتم الاحتفاظ ببيانات الإحالة', 'info');
      navigate(ROUTES.loginWithRedirect(returnPath));
      return;
    }

    if (!isOnline) {
      setFormError('لا يمكن إنشاء الحجز دون اتصال بالإنترنت.');
      return;
    }

    if (customerName.trim().length < 2) {
      setFormError('يرجى إدخال الاسم الكامل بشكل صحيح.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customerEmail.trim())) {
      setFormError('يرجى إدخال بريد إلكتروني صحيح.');
      return;
    }
    if (customerPhone.trim().length < 6) {
      setFormError('يرجى إدخال رقم جوال صحيح للتواصل.');
      return;
    }
    if (!travelDate) {
      setFormError('يرجى اختيار تاريخ الرحلة.');
      return;
    }
    if (guests < 1 || guests > trip.maxGuests) {
      setFormError(`عدد الضيوف يجب أن يكون بين 1 و ${trip.maxGuests}.`);
      return;
    }

    setFormError(null);
    setSubmitting(true);

    try {
      const verifiedReferral = await verifyBeforeBooking(user.uid);
      const bookingId = await createBookingWithAttribution({
        userId: user.uid,
        customerName,
        customerEmail,
        customerPhone,
        trip,
        travelDate,
        guests,
        notes,
        referral: verifiedReferral,
      });
      showToast('تم إنشاء طلب الحجز بنجاح، انتقل لتأكيد الدفع.', 'success');
      navigate(ROUTES.bookingDetail(bookingId));
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'حدث خطأ أثناء إنشاء الحجز.';
      setFormError(msg);
      showToast(msg, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleTripReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !trip || !selectedBookingId || savingReview) return;
    if (!isOnline) {
      showToast('يتطلب حفظ التقييم اتصالاً بالإنترنت.', 'error');
      return;
    }
    setSavingReview(true);
    try {
      await saveTripReview({
        tripId: trip.id,
        bookingId: selectedBookingId,
        userId: user.uid,
        userName: profile?.displayName || user.displayName || 'ضيف رحّال',
        rating: reviewRating,
        comment: reviewComment,
      });
      await loadReviews(trip.id);
      showToast('شكراً لك، تم حفظ تقييمك لهذه الرحلة بنجاح', 'success');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'تعذر حفظ التقييم', 'error');
    } finally {
      setSavingReview(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="h-96 rounded-2xl bg-[#12233B] animate-pulse" />
      </div>
    );
  }

  if (!trip) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-3">الرحلة غير موجودة</h1>
        <p className="text-sm text-[#9BA8BC] mb-6">قد يكون الرابط غير صحيح أو تم إيقاف هذه الباقة.</p>
        <Link
          to={ROUTES.TRIPS}
          className="min-h-[44px] inline-flex items-center justify-center rounded-xl bg-[#C5A15B] text-[#0B172A] px-6 py-2.5 text-sm font-bold"
        >
          العودة إلى قائمة الرحلات
        </Link>
      </div>
    );
  }

  const hasApprovedPrice =
    typeof trip.price === 'number' && trip.price > 0 && isApprovedEgpCurrency(trip.currency);
  const hasBookableDates = Array.isArray(trip.departureDates) && trip.departureDates.length > 0;
  const canBookOnline = hasApprovedPrice && hasBookableDates && trip.active;
  const totalAmount = hasApprovedPrice ? (trip.price as number) * guests : 0;
  const existingSelectedReview = tripReviews.find((r) => r.bookingId === selectedBookingId);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10 space-y-10">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <Link
          to={ROUTES.TRIPS}
          className="min-h-[40px] inline-flex items-center gap-2 text-sm text-[#CBD5E1] hover:text-[#C5A15B] transition"
        >
          <ArrowRight className="w-4 h-4" />
          <span>العودة إلى جميع الرحلات</span>
        </Link>
        <button
          type="button"
          onClick={handleCopyShareLink}
          className="min-h-[40px] inline-flex items-center gap-2 rounded-xl border border-[#C5A15B]/40 px-4 py-2 text-xs font-semibold text-[#C5A15B] hover:bg-[#C5A15B]/10 transition"
        >
          <Share2 className="w-4 h-4" />
          <span>{isMarketer ? 'نسخ رابط الإحالة الخاص بي' : 'مشاركة رابط الرحلة'}</span>
        </button>
      </div>

      {referralError && (
        <div className="rounded-xl border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-sm text-amber-200">
          {referralError}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Right Column: Trip Photography, Specs, Services & Terms */}
        <div className="lg:col-span-7 space-y-6">
          <div className="rounded-2xl overflow-hidden border border-white/10 bg-[#12233B] aspect-[16/10]">
            <img
              src={trip.imageUrl}
              alt={trip.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2 text-xs text-[#C5A15B]">
              <span>{TRIP_CATEGORY_LABELS[trip.category]}</span>
              <span aria-hidden="true">·</span>
              <span>{trip.destination}</span>
              {typeof trip.durationDays === 'number' && trip.durationDays > 0 && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-num">{trip.durationDays} أيام</span>
                </>
              )}
              <span aria-hidden="true">·</span>
              <span className="font-mono-num">الحد الأقصى {trip.maxGuests} ضيفاً</span>
              {averageReview && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="inline-flex items-center gap-1 font-mono-num text-[#F4F1EA]">
                    <Star className="w-3.5 h-3.5 text-[#C5A15B] fill-[#C5A15B]" />
                    {averageReview} ({tripReviews.length})
                  </span>
                </>
              )}
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-[#F4F1EA]">{trip.title}</h1>
            <p className="text-base text-[#CBD5E1] leading-relaxed">{trip.description}</p>
          </div>

          {trip.highlights && trip.highlights.length > 0 && (
            <div className="rounded-2xl bg-[#12233B] border border-white/10 p-6">
              <h2 className="text-lg font-bold text-[#F4F1EA] mb-4">مميزات البرنامج</h2>
              <ul className="space-y-3">
                {trip.highlights.map((item) => (
                  <li key={item} className="flex items-start gap-3 text-sm text-[#CBD5E1]">
                    <Check className="w-4 h-4 text-[#C5A15B] shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {trip.services && trip.services.length > 0 && (
            <div className="rounded-2xl bg-[#12233B] border border-white/10 p-6">
              <h2 className="text-lg font-bold text-[#F4F1EA] mb-4">الخدمات المشمولة</h2>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {trip.services.map((srv) => (
                  <li key={srv} className="flex items-start gap-2.5 text-sm text-[#CBD5E1]">
                    <Check className="w-4 h-4 text-[#C5A15B] shrink-0 mt-0.5" />
                    <span>{srv}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {trip.terms && trip.terms.trim() && (
            <div className="rounded-2xl bg-[#12233B] border border-white/10 p-6 space-y-2">
              <h2 className="text-lg font-bold text-[#F4F1EA] flex items-center gap-2">
                <FileText className="w-4 h-4 text-[#C5A15B]" />
                <span>الشروط والأحكام الخاصة بالبرنامج</span>
              </h2>
              <p className="text-sm text-[#CBD5E1] leading-relaxed whitespace-pre-line">
                {trip.terms}
              </p>
            </div>
          )}
        </div>

        {/* Left Column: Contiguous Booking Module */}
        <div id="booking-form" className="lg:col-span-5 lg:sticky lg:top-24">
          {canBookOnline ? (
            <form
              onSubmit={handleBookingSubmit}
              className="rounded-2xl bg-[#12233B] border border-[#C5A15B]/30 p-6 space-y-4"
            >
              <div className="flex items-baseline justify-between pb-4 border-b border-white/10">
                <div>
                  <span className="text-xs text-[#9BA8BC] block">السعر للفرد</span>
                  <span className="text-2xl font-bold text-[#F4F1EA] font-mono-num">
                    {formatEgpAmount(trip.price as number)}
                  </span>
                </div>
                {activeReferral && (
                  <span className="text-xs text-[#C5A15B] font-mono-num">
                    كود إحالة: {activeReferral.code}
                  </span>
                )}
              </div>

              {formError && (
                <div className="rounded-xl bg-red-500/15 border border-red-500/40 px-4 py-2.5 text-xs text-red-200">
                  {formError}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="booking-date"
                    className="block text-xs font-semibold text-[#CBD5E1] mb-1.5"
                  >
                    تاريخ الانطلاق *
                  </label>
                  <div className="relative">
                    <Calendar className="w-4 h-4 text-[#C5A15B] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <select
                      id="booking-date"
                      value={travelDate}
                      onChange={(e) => setTravelDate(e.target.value)}
                      required
                      className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 pr-9 pl-3 text-sm text-[#F4F1EA] font-mono-num"
                    >
                      {trip.departureDates.map((d) => (
                        <option key={d} value={d}>
                          {d}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="booking-guests"
                    className="block text-xs font-semibold text-[#CBD5E1] mb-1.5"
                  >
                    عدد الضيوف *
                  </label>
                  <div className="relative">
                    <Users className="w-4 h-4 text-[#C5A15B] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      id="booking-guests"
                      type="number"
                      min={1}
                      max={trip.maxGuests}
                      value={guests}
                      onChange={(e) =>
                        setGuests(Math.max(1, Math.min(trip.maxGuests, Number(e.target.value) || 1)))
                      }
                      required
                      className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 pr-9 pl-3 text-sm text-[#F4F1EA] font-mono-num"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label
                  htmlFor="booking-name"
                  className="block text-xs font-semibold text-[#CBD5E1] mb-1.5"
                >
                  الاسم الكامل *
                </label>
                <input
                  id="booking-name"
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  required
                  placeholder="الاسم الثلاثي"
                  className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="booking-email"
                    className="block text-xs font-semibold text-[#CBD5E1] mb-1.5"
                  >
                    البريد الإلكتروني *
                  </label>
                  <input
                    id="booking-email"
                    type="email"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    required
                    placeholder="name@example.com"
                    className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA]"
                  />
                </div>
                <div>
                  <label
                    htmlFor="booking-phone"
                    className="block text-xs font-semibold text-[#CBD5E1] mb-1.5"
                  >
                    رقم الجوال *
                  </label>
                  <input
                    id="booking-phone"
                    type="tel"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    required
                    placeholder="05XXXXXXXX"
                    className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA] font-mono-num"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="booking-notes"
                  className="block text-xs font-semibold text-[#CBD5E1] mb-1.5"
                >
                  ملاحظات إضافية (اختياري)
                </label>
                <textarea
                  id="booking-notes"
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  maxLength={500}
                  placeholder="تفضيلات السكن أو الوجبات..."
                  className="w-full rounded-xl bg-[#0B172A] border border-white/15 px-3.5 py-2.5 text-sm text-[#F4F1EA]"
                />
              </div>

              <div className="rounded-xl bg-[#0B172A] border border-white/10 p-4 flex items-center justify-between">
                <span className="text-sm text-[#CBD5E1]">الإجمالي المستحق</span>
                <span className="text-xl font-bold text-[#C5A15B] font-mono-num">
                  {formatEgpAmount(totalAmount)}
                </span>
              </div>

              {user ? (
                <button
                  type="submit"
                  disabled={submitting || !isOnline}
                  className="w-full min-h-[48px] rounded-xl bg-[#C5A15B] text-[#0B172A] text-base font-bold hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition"
                >
                  {submitting ? 'جاري تأكيد إنشاء الحجز...' : 'متابعة إلى تأكيد الدفع'}
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    const returnPath = ROUTES.tripDetail(trip.id, activeReferral?.code);
                    showToast('يرجى تسجيل الدخول لإتمام الحجز وسيتم الاحتفاظ ببيانات الإحالة', 'info');
                    navigate(ROUTES.loginWithRedirect(returnPath));
                  }}
                  className="w-full min-h-[48px] rounded-xl bg-[#C5A15B] text-[#0B172A] text-base font-bold hover:opacity-90 transition"
                >
                  تسجيل الدخول وإتمام الحجز
                </button>
              )}

              <div className="flex items-center gap-2 text-xs text-[#9BA8BC]">
                <ShieldCheck className="w-4 h-4 text-[#C5A15B] shrink-0" />
                <span>
                  يتم التحقق من الحجز وربط الإحالة عبر الخادم بشكل محمي ولا يمكن تعديلها من المتصفح.
                </span>
              </div>
            </form>
          ) : (
            <div className="rounded-2xl bg-[#12233B] border border-[#C5A15B]/30 p-6 space-y-4">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-lg font-bold text-[#F4F1EA]">
                  التسعير بـ ج.م والحجز عند الاستفسار
                </h2>
                {activeReferral && (
                  <span className="text-xs text-[#C5A15B] font-mono-num">
                    كود إحالة: {activeReferral.code}
                  </span>
                )}
              </div>
              <p className="text-sm text-[#CBD5E1] leading-relaxed">
                العملة المعتمدة للحجز في منصة رحّال هي الجنيه المصري (ج.م). اطلب التواصل من فريق رحّال لتأكيد السعر النهائي والموعد المتاح وإتمام الحجز.
              </p>
              <div className="flex flex-col gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setContactModalMethod('whatsapp');
                    setContactModalOpen(true);
                  }}
                  className="min-h-[46px] inline-flex items-center justify-center gap-2 rounded-xl border border-emerald-500/45 bg-emerald-600/20 text-emerald-200 px-5 py-2.5 text-sm font-bold hover:bg-emerald-600/30 transition"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span>اطلب التواصل عبر واتساب</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setContactModalMethod('phone');
                    setContactModalOpen(true);
                  }}
                  className="min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl border border-white/20 bg-[#0B172A] text-[#F4F1EA] px-5 py-2 text-sm font-semibold hover:border-[#C5A15B] hover:text-[#C5A15B] transition"
                >
                  <Phone className="w-4 h-4 text-[#C5A15B]" />
                  <span>اطلب التواصل</span>
                </button>

                {!user && (
                  <button
                    type="button"
                    onClick={() => {
                      const returnPath = ROUTES.tripDetail(trip.id, activeReferral?.code);
                      showToast('يرجى تسجيل الدخول لمتابعة الطلب وسيتم الاحتفاظ ببيانات الإحالة', 'info');
                      navigate(ROUTES.loginWithRedirect(returnPath));
                    }}
                    className="min-h-[46px] inline-flex items-center justify-center rounded-xl bg-[#C5A15B] text-[#0B172A] px-5 py-2.5 text-sm font-bold hover:opacity-90 transition"
                  >
                    تسجيل الدخول ومتابعة الطلب
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Trip Reviews Section (Completely separate from Platform Reviews; strictly gated to completed bookings) */}
      <section className="rounded-2xl bg-[#12233B] border border-white/10 p-6 sm:p-8 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <h2 className="text-xl font-bold text-[#F4F1EA]">تقييمات المشاركين في الرحلة</h2>
            <p className="text-xs text-[#9BA8BC] mt-1">
              تقييمات حقيقية من الضيوف الذين أتمّوا حجزهم لهذه الرحلة عبر منصة رحّال
            </p>
          </div>
          {averageReview && (
            <div className="inline-flex items-center gap-2 rounded-xl bg-[#0B172A] border border-[#C5A15B]/35 px-4 py-2">
              <Star className="w-4 h-4 text-[#C5A15B] fill-[#C5A15B]" />
              <span className="text-base font-bold text-[#F4F1EA] font-mono-num">
                {averageReview} / 5
              </span>
              <span className="text-xs text-[#9BA8BC] font-mono-num">
                ({tripReviews.length} تقييم)
              </span>
            </div>
          )}
        </div>

        {/* Eligible Completed-Booking Review Submission Form */}
        {completedBookings.length > 0 ? (
          <form
            onSubmit={handleTripReviewSubmit}
            className="rounded-xl bg-[#0B172A] border border-[#C5A15B]/30 p-5 space-y-4"
          >
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h3 className="text-sm font-bold text-[#F4F1EA]">
                {existingSelectedReview ? 'تحديث تقييمك للرحلة' : 'أضف تقييمك للرحلة'}
              </h3>
              {completedBookings.length > 1 && (
                <select
                  value={selectedBookingId}
                  onChange={(e) => setSelectedBookingId(e.target.value)}
                  aria-label="اختر الحجز المكتمل"
                  className="min-h-[38px] rounded-lg bg-[#12233B] border border-white/15 px-3 text-xs text-[#F4F1EA] font-mono-num"
                >
                  {completedBookings.map((b) => (
                    <option key={b.id} value={b.id}>
                      حجز {b.travelDate} ({b.id.slice(0, 10)})
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div>
              <span className="block text-xs text-[#CBD5E1] mb-2">التقييم (من 1 إلى 5) *</span>
              <div className="flex items-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setReviewRating(star)}
                    aria-label={`تقييم ${star} من 5`}
                    className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-lg border border-white/10 bg-[#12233B] hover:border-[#C5A15B] transition"
                  >
                    <Star
                      className={`w-5 h-5 ${
                        star <= reviewRating
                          ? 'text-[#C5A15B] fill-[#C5A15B]'
                          : 'text-[#9BA8BC]/40'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label htmlFor="trip-review-comment" className="block text-xs text-[#CBD5E1] mb-1.5">
                تعليقك حول الرحلة (اختياري)
              </label>
              <textarea
                id="trip-review-comment"
                rows={3}
                maxLength={1000}
                value={reviewComment}
                onChange={(e) => setReviewComment(e.target.value)}
                placeholder="شارك تجربتك في التنظيم والإقامة والخدمات..."
                className="w-full rounded-xl bg-[#12233B] border border-white/15 px-3.5 py-2.5 text-sm text-[#F4F1EA]"
              />
            </div>

            <button
              type="submit"
              disabled={savingReview}
              className="min-h-[44px] rounded-xl bg-[#C5A15B] text-[#0B172A] px-5 py-2 text-sm font-bold hover:opacity-90 disabled:opacity-50 transition"
            >
              {savingReview
                ? 'جاري الحفظ...'
                : existingSelectedReview
                ? 'تحديث التقييم'
                : 'نشر تقييم الرحلة'}
            </button>
          </form>
        ) : (
          <div className="rounded-xl bg-[#0B172A]/80 border border-white/10 px-4 py-3 text-xs sm:text-sm text-[#9BA8BC]">
            التقييم متاح فقط للمشاركين الذين أتمّوا حجزهم لهذه الرحلة.
          </div>
        )}

        {/* Display Trip Reviews */}
        {tripReviews.length === 0 ? (
          <p className="text-sm text-[#9BA8BC]">لا توجد تقييمات لهذه الرحلة حتى الآن.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {tripReviews.map((rev) => (
              <div
                key={rev.id}
                className="rounded-xl bg-[#0B172A] border border-white/10 p-4 space-y-2"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-bold text-[#F4F1EA]">{rev.userName}</span>
                  <div className="inline-flex items-center gap-0.5">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star
                        key={s}
                        className={`w-3.5 h-3.5 ${
                          s <= rev.rating ? 'text-[#C5A15B] fill-[#C5A15B]' : 'text-white/15'
                        }`}
                      />
                    ))}
                  </div>
                </div>
                {rev.comment && (
                  <p className="text-xs sm:text-sm text-[#CBD5E1] leading-relaxed">{rev.comment}</p>
                )}
              </div>
            ))}
          </div>
        )}
      </section>

      <ContactRequestModal
        open={contactModalOpen}
        initialMethod={contactModalMethod}
        onClose={() => setContactModalOpen(false)}
      />
    </div>
  );
};
