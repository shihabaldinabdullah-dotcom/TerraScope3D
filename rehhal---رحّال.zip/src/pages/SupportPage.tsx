import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ExternalLink, HelpCircle, Mail, MessageCircle, Phone, Send } from 'lucide-react';
import { ContactRequestModal } from '../components/ContactRequestModal';
import { useAuth } from '../context/AuthContext';
import { usePlatformSettings } from '../context/SettingsContext';
import { useToast } from '../context/ToastContext';
import { ROUTES } from '../routes/routeRegistry';
import { createSupportTicket, fetchUserTickets } from '../services/firestoreService';
import type { ContactRequestMethod, SupportTicket } from '../types';

function isValidExternalUrl(url?: string): boolean {
  if (!url) return false;
  try {
    const u = new URL(url.trim());
    return u.protocol === 'https:' || u.protocol === 'http:';
  } catch {
    return false;
  }
}

export const SupportPage: React.FC = () => {
  const { user, profile } = useAuth();
  const { settings } = usePlatformSettings();
  const { showToast } = useToast();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [subject, setSubject] = useState('');
  const [bookingId, setBookingId] = useState('');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [contactModalOpen, setContactModalOpen] = useState(false);
  const [contactModalMethod, setContactModalMethod] = useState<ContactRequestMethod>('whatsapp');

  useEffect(() => {
    if (user) {
      fetchUserTickets(user.uid).then(setTickets).catch(() => undefined);
    }
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      showToast('يرجى تسجيل الدخول لإرسال تذكرة دعم', 'info');
      return;
    }
    if (subject.trim().length < 3 || message.trim().length < 10) {
      showToast('يرجى كتابة عنوان واضح وتفاصيل كافية للرسالة', 'error');
      return;
    }

    setSubmitting(true);
    try {
      await createSupportTicket({
        userId: user.uid,
        name: profile?.displayName || user.displayName || 'عميل رحّال',
        email: user.email || settings.supportEmail || 'user@rehhal.sa',
        subject,
        message,
        bookingId,
      });
      showToast('تم استلام تذكرة الدعم وسيتواصل معك فريقنا قريباً', 'success');
      setSubject('');
      setBookingId('');
      setMessage('');
      fetchUserTickets(user.uid).then(setTickets);
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'تعذر إرسال التذكرة', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const cleanPhone = (settings.supportPhone || '').replace(/\s+/g, '');
  const socialLinks = [
    { label: 'إكس (X)', url: settings.xUrl },
    { label: 'إنستغرام', url: settings.instagramUrl },
    { label: 'تيك توك', url: settings.tiktokUrl },
    { label: 'سناب شات', url: settings.snapchatUrl },
  ].filter((s) => isValidExternalUrl(s.url));

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 sm:py-10 space-y-8">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-[#F4F1EA]">تواصل معنا والدعم</h1>
        <p className="text-sm text-[#9BA8BC] mt-1">
          فريق خدمة ضيوف الرحمن متاح للإجابة عن استفسارات برامج الحج والعمرة والحجوزات
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-2xl bg-[#12233B] border border-white/10 p-6 space-y-5">
            {settings.supportEmail && (
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-[#C5A15B]" />
                <div>
                  <div className="text-xs text-[#9BA8BC]">البريد الرسمي</div>
                  <a
                    href={`mailto:${settings.supportEmail}`}
                    className="text-sm font-semibold text-[#F4F1EA] hover:text-[#C5A15B]"
                    dir="ltr"
                  >
                    {settings.supportEmail}
                  </a>
                </div>
              </div>
            )}

            {cleanPhone && (
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-[#C5A15B]" />
                  <div>
                    <div className="text-xs text-[#9BA8BC]">خدمة العملاء الهاتفية</div>
                    <div className="text-sm font-semibold text-[#F4F1EA]">طلب اتصال مباشر مع فريق الدعم</div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setContactModalMethod('phone');
                    setContactModalOpen(true);
                  }}
                  className="w-full min-h-[42px] inline-flex items-center justify-center gap-2 rounded-xl border border-white/20 bg-[#0B172A] px-4 py-2.5 text-xs font-bold text-[#F4F1EA] hover:border-[#C5A15B] hover:text-[#C5A15B] transition"
                >
                  <span>اطلب التواصل</span>
                </button>
              </div>
            )}

            <div className="pt-1">
              <button
                type="button"
                onClick={() => {
                  setContactModalMethod('whatsapp');
                  setContactModalOpen(true);
                }}
                className="w-full min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-600/20 border border-emerald-500/50 px-4 py-2.5 text-sm font-bold text-emerald-200 hover:bg-emerald-600/30 transition"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span>اطلب التواصل عبر واتساب</span>
              </button>
            </div>

            {socialLinks.length > 0 && (
              <div className="pt-3 border-t border-white/10 space-y-2">
                <div className="text-xs text-[#9BA8BC]">حسابات التواصل المعتمدة</div>
                <div className="flex flex-wrap gap-3 text-xs">
                  {socialLinks.map((item) => (
                    <a
                      key={item.label}
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 rounded-lg border border-white/15 bg-[#0B172A] px-3 py-1.5 text-[#CBD5E1] hover:border-[#C5A15B] hover:text-[#C5A15B] transition"
                    >
                      <span>{item.label}</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>

          {tickets.length > 0 && (
            <div className="rounded-2xl bg-[#12233B] border border-white/10 p-6 space-y-3">
              <h2 className="text-base font-bold text-[#F4F1EA]">تذاكرك السابقة</h2>
              <div className="space-y-2.5">
                {tickets.map((t) => (
                  <div key={t.id} className="rounded-xl bg-[#0B172A] border border-white/10 p-3 text-xs">
                    <div className="font-semibold text-[#F4F1EA]">{t.subject}</div>
                    <div className="text-[#9BA8BC] mt-1">الحالة: {t.status}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="lg:col-span-7">
          {user ? (
            <form
              onSubmit={handleSubmit}
              className="rounded-2xl bg-[#12233B] border border-white/10 p-6 space-y-4"
            >
              <h2 className="text-lg font-bold text-[#F4F1EA] flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-[#C5A15B]" />
                <span>فتح تذكرة دعم جديدة</span>
              </h2>

              <div>
                <label htmlFor="support-subject" className="block text-xs font-semibold text-[#CBD5E1] mb-1.5">
                  عنوان الموضوع *
                </label>
                <input
                  id="support-subject"
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="استفسار حول موعد الرحلة أو السداد"
                  className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA]"
                />
              </div>

              <div>
                <label htmlFor="support-booking" className="block text-xs font-semibold text-[#CBD5E1] mb-1.5">
                  رقم الحجز (اختياري)
                </label>
                <input
                  id="support-booking"
                  type="text"
                  value={bookingId}
                  onChange={(e) => setBookingId(e.target.value)}
                  placeholder="bkg_..."
                  className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA] font-mono-num"
                />
              </div>

              <div>
                <label htmlFor="support-message" className="block text-xs font-semibold text-[#CBD5E1] mb-1.5">
                  تفاصيل الطلب *
                </label>
                <textarea
                  id="support-message"
                  rows={4}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="اشرح استفسارك بالتفصيل..."
                  className="w-full rounded-xl bg-[#0B172A] border border-white/15 px-3.5 py-2.5 text-sm text-[#F4F1EA]"
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="min-h-[46px] inline-flex items-center justify-center gap-2 rounded-xl bg-[#C5A15B] text-[#0B172A] px-6 py-2.5 text-sm font-bold hover:opacity-90 disabled:opacity-50 transition"
              >
                <Send className="w-4 h-4" />
                <span>{submitting ? 'جاري الإرسال...' : 'إرسال التذكرة'}</span>
              </button>
            </form>
          ) : (
            <div className="rounded-2xl bg-[#12233B] border border-white/10 p-8 text-center space-y-4">
              <p className="text-sm text-[#CBD5E1]">سجّل دخولك لفتح تذكرة دعم مرتبطة بحسابك ومتابعة الردود.</p>
              <Link
                to={ROUTES.loginWithRedirect(ROUTES.SUPPORT)}
                className="min-h-[44px] inline-flex items-center justify-center rounded-xl bg-[#C5A15B] text-[#0B172A] px-6 py-2.5 text-sm font-bold"
              >
                تسجيل الدخول
              </Link>
            </div>
          )}
        </div>
      </div>

      <ContactRequestModal
        open={contactModalOpen}
        initialMethod={contactModalMethod}
        onClose={() => setContactModalOpen(false)}
      />
    </div>
  );
};
