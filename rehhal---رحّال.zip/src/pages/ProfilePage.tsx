import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import {
  AlertTriangle,
  BadgePercent,
  Briefcase,
  CalendarCheck,
  Clock,
  Copy,
  ExternalLink,
  Link2,
  LogOut,
  MousePointerClick,
  Shield,
  Star,
  TrendingUp,
  UserCheck,
  Wallet,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { CURATED_TRIPS } from '../data/curatedTrips';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { ROUTES } from '../routes/routeRegistry';
import {
  fetchMarketerCommissions,
  fetchMarketerReferredBookings,
  fetchMyPlatformReview,
  registerPartnerMarketer,
  savePlatformReview,
} from '../services/firestoreService';
import type { Booking, CommissionRecord } from '../types';
import { formatCustomerLedgerAmount, formatEgpAmount, isApprovedEgpCurrency } from '../utils/currency';

type ProfileTab = 'info' | 'review' | 'affiliate';

export const ProfilePage: React.FC = () => {
  const { user, profile, marketer, isAdmin, isMarketer, refreshProfile, updateProfileInfo, logout } =
    useAuth();
  const { showToast } = useToast();
  const isOnline = useOnlineStatus();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  const rawTab = searchParams.get('tab');
  const activeTab: ProfileTab =
    rawTab === 'affiliate' ? 'affiliate' : rawTab === 'review' ? 'review' : 'info';

  // Profile Info state
  const [displayName, setDisplayName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [saving, setSaving] = useState(false);

  // Platform Review state (completely separate from trips & marketers)
  const [platformRating, setPlatformRating] = useState(5);
  const [platformComment, setPlatformComment] = useState('');
  const [hasExistingPlatformReview, setHasExistingPlatformReview] = useState(false);
  const [savingPlatformReview, setSavingPlatformReview] = useState(false);

  // Affiliate join application state (for non-marketers)
  const [appFullName, setAppFullName] = useState('');
  const [appPhone, setAppPhone] = useState('');
  const [appCity, setAppCity] = useState('');
  const [appChannel, setAppChannel] = useState('');
  const [requestedCode, setRequestedCode] = useState('');
  const [applying, setApplying] = useState(false);
  const [applyError, setApplyError] = useState<string | null>(null);

  // Marketer quick summary state (loaded strictly when isMarketer === true)
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [commissions, setCommissions] = useState<CommissionRecord[]>([]);
  const [clicksCount, setClicksCount] = useState(0);

  useEffect(() => {
    setDisplayName(profile?.displayName || user?.displayName || '');
    setPhone(profile?.phone || '');
    setCity(profile?.city || '');

    if (user) {
      setAppFullName((p) => p || profile?.displayName || user.displayName || '');
      setAppPhone((p) => p || profile?.phone || '');
      setAppCity((p) => p || profile?.city || '');
      setRequestedCode((p) => p || `REH${user.uid.slice(0, 5).toUpperCase()}`);

      fetchMyPlatformReview(user.uid).then((rev) => {
        if (rev) {
          setPlatformRating(rev.rating);
          setPlatformComment(rev.comment || '');
          setHasExistingPlatformReview(true);
        }
      });
    }
  }, [profile, user]);

  useEffect(() => {
    if (!isMarketer || !marketer) return;
    fetchMarketerReferredBookings(marketer.uid).then(setBookings);
    fetchMarketerCommissions(marketer.uid).then(setCommissions);
    fetch(`/api/referrals/stats/${encodeURIComponent(marketer.referralCode)}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d && typeof d.uniqueClicks === 'number') setClicksCount(d.uniqueClicks);
      })
      .catch(() => undefined);
  }, [isMarketer, marketer]);

  const switchTab = (next: ProfileTab) => {
    const nextParams = new URLSearchParams(searchParams);
    if (next === 'info') {
      nextParams.delete('tab');
    } else {
      nextParams.set('tab', next);
    }
    setSearchParams(nextParams, { replace: true });
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (displayName.trim().length < 2) {
      showToast('يجب أن يتكون الاسم من حرفين على الأقل', 'error');
      return;
    }
    setSaving(true);
    try {
      await updateProfileInfo({ displayName, phone, city });
      showToast('تم حفظ بيانات الملف الشخصي في قاعدة البيانات', 'success');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'تعذر حفظ التعديلات', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleSavePlatformReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || savingPlatformReview) return;
    if (!isOnline) {
      showToast('يتطلب إرسال تقييم المنصة اتصالاً بالإنترنت.', 'error');
      return;
    }
    setSavingPlatformReview(true);
    try {
      await savePlatformReview({
        userId: user.uid,
        userName: profile?.displayName || user.displayName || 'عميل رحّال',
        rating: platformRating,
        comment: platformComment,
      });
      setHasExistingPlatformReview(true);
      showToast('شكراً لك، تم حفظ تقييمك لمنصة رحّال بنجاح', 'success');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'تعذر حفظ تقييم المنصة', 'error');
    } finally {
      setSavingPlatformReview(false);
    }
  };

  const handleApplyMarketer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || applying) return;
    if (!isOnline) {
      setApplyError('يتطلب تقديم طلب التسويق بالعمولة اتصالاً بالإنترنت.');
      return;
    }
    setApplyError(null);
    setApplying(true);
    try {
      await registerPartnerMarketer({
        uid: user.uid,
        fullName: appFullName,
        phone: appPhone,
        city: appCity,
        channel: appChannel,
        requestedCode,
      });
      await refreshProfile();
      showToast('تم استلام طلب التسويق بالعمولة بنجاح وهو الآن بانتظار اعتماد الإدارة', 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'تعذر تقديم طلب الانضمام';
      setApplyError(msg);
      showToast(msg, 'error');
    } finally {
      setApplying(false);
    }
  };

  const handleCopyMainLink = async () => {
    if (!marketer) return;
    const shareUrl = ROUTES.absoluteTripShareUrl(CURATED_TRIPS[0].id, marketer.referralCode);
    try {
      await navigator.clipboard.writeText(shareUrl);
      showToast('تم نسخ رابط الإحالة الخاص بك', 'success');
    } catch {
      showToast('تعذر النسخ التلقائي', 'error');
    }
  };

  const handleSignOut = async () => {
    await logout();
    showToast('تم تسجيل الخروج بنجاح', 'info');
    navigate(ROUTES.HOME);
  };

  const pendingEgpAmount = commissions
    .filter((c) => c.status === 'pending' && isApprovedEgpCurrency(c.currency))
    .reduce((acc, c) => acc + c.amount, 0);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 sm:py-10 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-[#F4F1EA]">الملف الشخصي</h1>
          <p className="text-sm text-[#9BA8BC] mt-1">{user?.email}</p>
        </div>
        <button
          type="button"
          onClick={handleSignOut}
          className="min-h-[44px] inline-flex items-center gap-2 rounded-xl border border-red-500/40 px-4 py-2 text-sm font-semibold text-red-300 hover:bg-red-500/10 transition"
        >
          <LogOut className="w-4 h-4" />
          <span>تسجيل الخروج</span>
        </button>
      </div>

      {/* Quick Cards inside Profile */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Link
          to={ROUTES.MY_BOOKINGS}
          className="rounded-2xl bg-[#12233B] border border-white/10 hover:border-[#C5A15B]/50 p-5 flex items-center gap-3 transition text-right"
        >
          <CalendarCheck className="w-5 h-5 text-[#C5A15B] shrink-0" />
          <div>
            <div className="text-sm font-bold text-[#F4F1EA]">حجوزاتي</div>
            <div className="text-xs text-[#9BA8BC]">عرض وإدارة حجوزات الحج والعمرة</div>
          </div>
        </Link>

        <button
          type="button"
          onClick={() => switchTab(activeTab === 'review' ? 'info' : 'review')}
          className={`rounded-2xl bg-[#12233B] border p-5 flex items-center gap-3 transition text-right ${
            activeTab === 'review'
              ? 'border-[#C5A15B] bg-[#C5A15B]/10'
              : 'border-white/10 hover:border-[#C5A15B]/50'
          }`}
        >
          <Star className="w-5 h-5 text-[#C5A15B] shrink-0" />
          <div>
            <div className="text-sm font-bold text-[#F4F1EA]">تقييم المنصة</div>
            <div className="text-xs text-[#9BA8BC]">
              {hasExistingPlatformReview ? 'تحديث تقييمك لرحّال' : 'شاركنا رأيك في منصة رحّال'}
            </div>
          </div>
        </button>

        <button
          type="button"
          onClick={() => switchTab(activeTab === 'affiliate' ? 'info' : 'affiliate')}
          className={`rounded-2xl bg-[#12233B] border p-5 flex items-center gap-3 transition text-right ${
            activeTab === 'affiliate'
              ? 'border-[#C5A15B] bg-[#C5A15B]/10'
              : 'border-white/10 hover:border-[#C5A15B]/50'
          }`}
        >
          <Briefcase className="w-5 h-5 text-[#C5A15B] shrink-0" />
          <div>
            <div className="text-sm font-bold text-[#F4F1EA]">التسويق بالعمولة</div>
            <div className="text-xs text-[#9BA8BC]">
              {isMarketer
                ? 'لوحة المسوّق والإحالات والأرباح'
                : marketer?.status === 'pending'
                ? 'طلبك قيد مراجعة الإدارة'
                : 'الانضمام ومتابعة الإحالات'}
            </div>
          </div>
        </button>

        {isAdmin && (
          <Link
            to={ROUTES.ADMIN}
            className="rounded-2xl bg-[#12233B] border border-[#C5A15B]/35 hover:border-[#C5A15B] p-5 flex items-center gap-3 transition text-right"
          >
            <Shield className="w-5 h-5 text-[#C5A15B] shrink-0" />
            <div>
              <div className="text-sm font-bold text-[#F4F1EA]">إدارة المنصة</div>
              <div className="text-xs text-[#C5A15B]">صلاحية مشرف عام</div>
            </div>
          </Link>
        )}
      </div>

      {/* Tab Switcher */}
      <div className="flex flex-wrap items-center gap-2 border-b border-white/10 pb-3">
        <button
          type="button"
          onClick={() => switchTab('info')}
          className={`min-h-[40px] px-4 py-2 rounded-xl text-sm font-semibold transition whitespace-nowrap ${
            activeTab === 'info' ? 'bg-[#C5A15B] text-[#0B172A]' : 'text-[#CBD5E1] hover:bg-white/5'
          }`}
        >
          البيانات الأساسية
        </button>
        <button
          type="button"
          onClick={() => switchTab('review')}
          className={`min-h-[40px] px-4 py-2 rounded-xl text-sm font-semibold transition whitespace-nowrap ${
            activeTab === 'review' ? 'bg-[#C5A15B] text-[#0B172A]' : 'text-[#CBD5E1] hover:bg-white/5'
          }`}
        >
          تقييم المنصة
        </button>
        <button
          type="button"
          onClick={() => switchTab('affiliate')}
          className={`min-h-[40px] px-4 py-2 rounded-xl text-sm font-semibold transition whitespace-nowrap ${
            activeTab === 'affiliate'
              ? 'bg-[#C5A15B] text-[#0B172A]'
              : 'text-[#CBD5E1] hover:bg-white/5'
          }`}
        >
          التسويق بالعمولة
        </button>
      </div>

      {activeTab === 'info' ? (
        <form
          onSubmit={handleSaveProfile}
          className="rounded-2xl bg-[#12233B] border border-white/10 p-6 space-y-4"
        >
          <div className="flex items-center gap-2 text-base font-bold text-[#F4F1EA] pb-3 border-b border-white/10">
            <UserCheck className="w-5 h-5 text-[#C5A15B]" />
            <span>تحديث البيانات الأساسية</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="profile-name"
                className="block text-xs font-semibold text-[#CBD5E1] mb-1.5"
              >
                الاسم الكامل *
              </label>
              <input
                id="profile-name"
                type="text"
                required
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA]"
              />
            </div>

            <div>
              <label
                htmlFor="profile-phone"
                className="block text-xs font-semibold text-[#CBD5E1] mb-1.5"
              >
                رقم الجوال
              </label>
              <input
                id="profile-phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="05XXXXXXXX"
                className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA] font-mono-num"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="profile-city"
              className="block text-xs font-semibold text-[#CBD5E1] mb-1.5"
            >
              المدينة
            </label>
            <input
              id="profile-city"
              type="text"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="مكة المكرمة، المدينة المنورة، الرياض..."
              className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA]"
            />
          </div>

          <button
            type="submit"
            disabled={saving}
            className="min-h-[46px] rounded-xl bg-[#C5A15B] text-[#0B172A] px-6 py-2.5 text-sm font-bold hover:opacity-90 disabled:opacity-50 transition"
          >
            {saving ? 'جاري الحفظ...' : 'حفظ التغييرات'}
          </button>
        </form>
      ) : activeTab === 'review' ? (
        <form
          onSubmit={handleSavePlatformReview}
          className="rounded-2xl bg-[#12233B] border border-[#C5A15B]/30 p-6 sm:p-8 space-y-5"
        >
          <div>
            <h2 className="text-xl font-bold text-[#F4F1EA]">تقييم منصة رحّال</h2>
            <p className="text-xs sm:text-sm text-[#9BA8BC] mt-1">
              يخص هذا التقييم تجربتك العامة في استخدام موقع وتطبيق رحّال وخدمة العملاء، ويصل للإدارة مباشرة لتحسين المنصة.
            </p>
          </div>

          <div>
            <span className="block text-xs font-semibold text-[#CBD5E1] mb-2">
              التقييم العام للمنصة (من 1 إلى 5) *
            </span>
            <div className="flex items-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setPlatformRating(star)}
                  aria-label={`تقييم المنصة ${star} من 5`}
                  className="min-h-[44px] min-w-[44px] inline-flex items-center justify-center rounded-xl border border-white/15 bg-[#0B172A] hover:border-[#C5A15B] transition"
                >
                  <Star
                    className={`w-5 h-5 ${
                      star <= platformRating
                        ? 'text-[#C5A15B] fill-[#C5A15B]'
                        : 'text-[#9BA8BC]/40'
                    }`}
                  />
                </button>
              ))}
              <span className="text-sm font-bold text-[#C5A15B] font-mono-num mr-2">
                {platformRating} / 5
              </span>
            </div>
          </div>

          <div>
            <label
              htmlFor="platform-review-comment"
              className="block text-xs font-semibold text-[#CBD5E1] mb-1.5"
            >
              ملاحظاتك ومقترحاتك (اختياري)
            </label>
            <textarea
              id="platform-review-comment"
              rows={4}
              maxLength={1000}
              value={platformComment}
              onChange={(e) => setPlatformComment(e.target.value)}
              placeholder="اكتب رأيك في سهولة التصفح والوضوح وسرعة الحجز..."
              className="w-full rounded-xl bg-[#0B172A] border border-white/15 px-3.5 py-2.5 text-sm text-[#F4F1EA]"
            />
          </div>

          <button
            type="submit"
            disabled={savingPlatformReview || !isOnline}
            className="min-h-[46px] rounded-xl bg-[#C5A15B] text-[#0B172A] px-6 py-2.5 text-sm font-bold hover:opacity-90 disabled:opacity-50 transition"
          >
            {savingPlatformReview
              ? 'جاري الحفظ...'
              : hasExistingPlatformReview
              ? 'تحديث تقييم المنصة'
              : 'إرسال تقييم المنصة'}
          </button>
        </form>
      ) : isMarketer && marketer ? (
        /* Role-Protected Marketer Dashboard Hub inside Profile */
        <div className="space-y-6">
          <div className="rounded-2xl bg-[#12233B] border border-[#C5A15B]/35 p-6 flex flex-wrap items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold text-[#F4F1EA]">لوحة المسوّق — {marketer.fullName}</h2>
              <p className="text-xs text-[#9BA8BC] mt-1">
                كود الإحالة المفعّل:{' '}
                <strong className="text-[#C5A15B] font-mono-num">{marketer.referralCode}</strong>
                {' · '}نسبة العمولة:{' '}
                <span className="font-mono-num">{Math.round(marketer.commissionRate * 100)}%</span>
              </p>
            </div>
            <div className="flex flex-wrap gap-2.5">
              <Link
                to={ROUTES.PARTNERS_DASHBOARD}
                className="min-h-[42px] inline-flex items-center gap-2 rounded-xl bg-[#C5A15B] text-[#0B172A] px-4 py-2 text-xs font-bold hover:opacity-90 transition"
              >
                <span>فتح اللوحة الكاملة</span>
              </Link>
              <Link
                to={ROUTES.PARTNERS_PAYOUTS}
                className="min-h-[42px] inline-flex items-center gap-2 rounded-xl border border-[#C5A15B]/45 text-[#C5A15B] px-4 py-2 text-xs font-semibold hover:bg-[#C5A15B]/10 transition"
              >
                <Wallet className="w-4 h-4" />
                <span>طلبات السحب</span>
              </Link>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="rounded-2xl bg-[#12233B] border border-white/10 p-5">
              <div className="flex items-center justify-between text-xs text-[#9BA8BC] mb-2">
                <span>الرصيد القابل للسحب</span>
                <Wallet className="w-4 h-4 text-[#C5A15B]" />
              </div>
              <div className="text-2xl font-bold text-[#C5A15B] font-mono-num">
                {formatCustomerLedgerAmount(marketer.availableBalance, marketer.currency).text}
              </div>
            </div>

            <div className="rounded-2xl bg-[#12233B] border border-white/10 p-5">
              <div className="flex items-center justify-between text-xs text-[#9BA8BC] mb-2">
                <span>عمولات قيد الاستحقاق</span>
                <TrendingUp className="w-4 h-4 text-[#C5A15B]" />
              </div>
              <div className="text-2xl font-bold text-[#F4F1EA] font-mono-num">
                {formatEgpAmount(pendingEgpAmount)}
              </div>
            </div>

            <div className="rounded-2xl bg-[#12233B] border border-white/10 p-5">
              <div className="flex items-center justify-between text-xs text-[#9BA8BC] mb-2">
                <span>الحجوزات المحالة</span>
                <ExternalLink className="w-4 h-4 text-[#C5A15B]" />
              </div>
              <div className="text-2xl font-bold text-[#F4F1EA] font-mono-num">
                {bookings.length}
              </div>
            </div>

            <div className="rounded-2xl bg-[#12233B] border border-white/10 p-5">
              <div className="flex items-center justify-between text-xs text-[#9BA8BC] mb-2">
                <span>النقرات الفريدة</span>
                <MousePointerClick className="w-4 h-4 text-[#C5A15B]" />
              </div>
              <div className="text-2xl font-bold text-[#F4F1EA] font-mono-num">{clicksCount}</div>
            </div>
          </div>

          <div className="rounded-2xl bg-[#12233B] border border-white/10 p-6 space-y-4">
            <h3 className="text-sm font-bold text-[#F4F1EA]">رابط المشاركة السريع لأهم باقة</h3>
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                readOnly
                value={ROUTES.absoluteTripShareUrl(CURATED_TRIPS[0].id, marketer.referralCode)}
                aria-label="رابط الإحالة الخاص بك"
                className="flex-1 min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-xs text-[#CBD5E1] font-mono-num"
                dir="ltr"
              />
              <button
                type="button"
                onClick={handleCopyMainLink}
                className="min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-[#C5A15B] text-[#0B172A] px-5 py-2 text-sm font-bold hover:opacity-90 transition shrink-0"
              >
                <Copy className="w-4 h-4" />
                <span>نسخ الرابط</span>
              </button>
            </div>

            <div className="pt-2 grid grid-cols-2 sm:grid-cols-4 gap-3">
              <Link
                to={ROUTES.PARTNERS_REFERRALS}
                className="rounded-xl bg-[#0B172A] border border-white/10 hover:border-[#C5A15B]/50 p-3 text-xs font-semibold text-[#F4F1EA] flex items-center gap-2 transition"
              >
                <Link2 className="w-4 h-4 text-[#C5A15B]" />
                <span>روابط المشاركة</span>
              </Link>
              <Link
                to={ROUTES.PARTNERS_BOOKINGS}
                className="rounded-xl bg-[#0B172A] border border-white/10 hover:border-[#C5A15B]/50 p-3 text-xs font-semibold text-[#F4F1EA] flex items-center gap-2 transition"
              >
                <CalendarCheck className="w-4 h-4 text-[#C5A15B]" />
                <span>سجل الإحالات</span>
              </Link>
              <Link
                to={ROUTES.PARTNERS_EARNINGS}
                className="rounded-xl bg-[#0B172A] border border-white/10 hover:border-[#C5A15B]/50 p-3 text-xs font-semibold text-[#F4F1EA] flex items-center gap-2 transition"
              >
                <BadgePercent className="w-4 h-4 text-[#C5A15B]" />
                <span>الأرباح والعمولات</span>
              </Link>
              <Link
                to={ROUTES.PARTNERS_PAYOUTS}
                className="rounded-xl bg-[#0B172A] border border-white/10 hover:border-[#C5A15B]/50 p-3 text-xs font-semibold text-[#F4F1EA] flex items-center gap-2 transition"
              >
                <Wallet className="w-4 h-4 text-[#C5A15B]" />
                <span>طلبات السحب</span>
              </Link>
            </div>
          </div>
        </div>
      ) : marketer?.status === 'pending' ? (
        <div className="rounded-2xl bg-[#12233B] border border-[#C5A15B]/35 p-8 text-center space-y-3">
          <Clock className="w-10 h-10 text-[#C5A15B] mx-auto" />
          <h2 className="text-xl font-bold text-[#F4F1EA]">
            طلب التسويق بالعمولة قيد مراجعة الإدارة
          </h2>
          <p className="text-sm text-[#CBD5E1] max-w-lg mx-auto leading-relaxed">
            تم استلام طلبك بنجاح لرمز الإحالة المقترح{' '}
            <strong className="text-[#C5A15B] font-mono-num">{marketer.referralCode}</strong>.
            ستظهر لك لوحة المسوّق وروابط المشاركة والعمولات وطلبات السحب فور اعتماد الإدارة لصلاحية المسوّق.
          </p>
        </div>
      ) : marketer?.status === 'suspended' ? (
        <div className="rounded-2xl bg-[#12233B] border border-red-500/40 p-8 text-center space-y-3">
          <AlertTriangle className="w-10 h-10 text-red-400 mx-auto" />
          <h2 className="text-xl font-bold text-[#F4F1EA]">حساب التسويق بالعمولة موقوف مؤقتاً</h2>
          <p className="text-sm text-[#CBD5E1] max-w-lg mx-auto">
            تم إيقاف صلاحية المسوّق لهذا الحساب من قِبل الإدارة. يمكنك التواصل معنا عبر مركز الدعم للاستفسار.
          </p>
          <Link
            to={ROUTES.SUPPORT}
            className="min-h-[44px] inline-flex items-center justify-center rounded-xl border border-white/20 px-5 py-2 text-sm font-semibold text-[#F4F1EA] hover:bg-white/5"
          >
            التواصل مع الدعم
          </Link>
        </div>
      ) : (
        <div className="rounded-2xl bg-[#12233B] border border-[#C5A15B]/30 p-6 sm:p-8 space-y-5">
          <div>
            <h2 className="text-xl font-bold text-[#F4F1EA]">
              طلب الانضمام إلى برنامج التسويق بالعمولة
            </h2>
            <p className="text-xs sm:text-sm text-[#9BA8BC] mt-1">
              قدّم طلبك لتفعيل صلاحية المسوّق. بعد موافقة الإدارة، تفتح لك لوحة المسوّق وروابط المشاركة ومتابعة العمولات وطلبات السحب هنا.
            </p>
          </div>

          <form onSubmit={handleApplyMarketer} className="space-y-4">
            {applyError && (
              <div className="rounded-xl bg-red-500/15 border border-red-500/40 px-4 py-2.5 text-xs text-red-200">
                {applyError}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="aff-name" className="block text-xs font-semibold text-[#CBD5E1] mb-1.5">
                  الاسم الكامل *
                </label>
                <input
                  id="aff-name"
                  type="text"
                  required
                  value={appFullName}
                  onChange={(e) => setAppFullName(e.target.value)}
                  className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA]"
                />
              </div>

              <div>
                <label htmlFor="aff-phone" className="block text-xs font-semibold text-[#CBD5E1] mb-1.5">
                  رقم الجوال *
                </label>
                <input
                  id="aff-phone"
                  type="tel"
                  required
                  value={appPhone}
                  onChange={(e) => setAppPhone(e.target.value)}
                  placeholder="05XXXXXXXX"
                  className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA] font-mono-num"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="aff-city" className="block text-xs font-semibold text-[#CBD5E1] mb-1.5">
                  المدينة *
                </label>
                <input
                  id="aff-city"
                  type="text"
                  required
                  value={appCity}
                  onChange={(e) => setAppCity(e.target.value)}
                  placeholder="مكة المكرمة"
                  className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA]"
                />
              </div>

              <div>
                <label htmlFor="aff-channel" className="block text-xs font-semibold text-[#CBD5E1] mb-1.5">
                  قناة التسويق (اختياري)
                </label>
                <input
                  id="aff-channel"
                  type="text"
                  value={appChannel}
                  onChange={(e) => setAppChannel(e.target.value)}
                  placeholder="حساب تواصل أو موقع"
                  className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA]"
                />
              </div>
            </div>

            <div>
              <label htmlFor="aff-code" className="block text-xs font-semibold text-[#CBD5E1] mb-1.5">
                كود الإحالة المطلوب (أحرف وأرقام إنجليزية) *
              </label>
              <input
                id="aff-code"
                type="text"
                required
                value={requestedCode}
                onChange={(e) => setRequestedCode(e.target.value.toUpperCase())}
                placeholder="REH2027"
                dir="ltr"
                className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#C5A15B] font-mono-num uppercase"
              />
            </div>

            <button
              type="submit"
              disabled={applying || !isOnline}
              className="min-h-[48px] rounded-xl bg-[#C5A15B] text-[#0B172A] px-6 py-2.5 text-sm font-bold hover:opacity-90 disabled:opacity-50 transition"
            >
              {applying ? 'جاري إرسال طلب الانضمام...' : 'تقديم طلب الانضمام للتسويق بالعمولة'}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
