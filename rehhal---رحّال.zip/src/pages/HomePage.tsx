import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Compass } from 'lucide-react';
import { HeroSlider } from '../components/HeroSlider';
import { TripCard } from '../components/TripCard';
import { useReferral } from '../context/ReferralContext';
import { usePlatformSettings } from '../context/SettingsContext';
import { CURATED_TRIPS } from '../data/curatedTrips';
import { ROUTES } from '../routes/routeRegistry';
import { fetchTrips } from '../services/firestoreService';
import { isPilgrimageCategory, type Trip } from '../types';
import { formatCustomerAmount } from '../utils/currency';

interface ProgramCardData {
  key: string;
  categoryLabel: string;
  title: string;
  subtitle: string;
  imageUrl: string;
  detailTo: string;
  bookTo: string;
  price?: number | null;
  currency?: string;
  durationDays?: number | null;
}

export const HomePage: React.FC = () => {
  const [trips, setTrips] = useState<Trip[]>(() => CURATED_TRIPS.filter((t) => t.active));
  const { activeReferral } = useReferral();
  const { settings } = usePlatformSettings();

  useEffect(() => {
    fetchTrips().then((data) => {
      const activeOnly = data.filter((t) => t.active);
      if (activeOnly.length > 0) setTrips(activeOnly);
    });
  }, []);

  const sliderTrips = useMemo(() => {
    const marked = trips
      .filter((t) => t.sliderVisible)
      .sort((a, b) => (a.sliderOrder ?? 99) - (b.sliderOrder ?? 99));
    if (marked.length > 0) return marked;
    const pilgrimage = trips.filter((t) => isPilgrimageCategory(t.category));
    return pilgrimage.length > 0 ? pilgrimage.slice(0, 4) : trips.slice(0, 4);
  }, [trips]);

  const pilgrimagePrograms = useMemo<ProgramCardData[]>(() => {
    const hajjTrip = trips.find((t) => t.category === 'hajj');
    const umrahFirstTrip =
      trips.find((t) => t.category === 'umrah' && t.id === 'umrah-makkah-madinah-signature') ||
      trips.find((t) => t.category === 'umrah');
    const umrahSecondTrip =
      trips.find((t) => t.category === 'umrah' && t.id !== umrahFirstTrip?.id) ||
      trips.find((t) => t.category === 'umrah');

    const programs: ProgramCardData[] = [];

    if (hajjTrip) {
      const detailUrl = ROUTES.tripDetail(hajjTrip.id, activeReferral?.code);
      programs.push({
        key: 'program-hajj',
        categoryLabel: 'الحج',
        title: hajjTrip.title,
        subtitle: hajjTrip.subtitle,
        imageUrl: hajjTrip.imageUrl,
        detailTo: detailUrl,
        bookTo: `${detailUrl}#booking-form`,
        price: hajjTrip.price,
        currency: hajjTrip.currency,
        durationDays: hajjTrip.durationDays,
      });
    } else {
      programs.push({
        key: 'program-hajj',
        categoryLabel: 'الحج',
        title: 'برامج الحج المتكاملة',
        subtitle: 'باقات منظمة في المشاعر المقدسة بإقامة ميسّرة وإشراف متكامل.',
        imageUrl: '/src/assets/images/trip_hajj_makkah_1795679215457.jpg',
        detailTo: ROUTES.tripsWithCategory('hajj'),
        bookTo: ROUTES.tripsWithCategory('hajj'),
      });
    }

    if (umrahFirstTrip) {
      const detailUrl = ROUTES.tripDetail(umrahFirstTrip.id, activeReferral?.code);
      programs.push({
        key: 'program-umrah-1',
        categoryLabel: 'العمرة',
        title: umrahFirstTrip.title,
        subtitle: umrahFirstTrip.subtitle,
        imageUrl: umrahFirstTrip.imageUrl,
        detailTo: detailUrl,
        bookTo: `${detailUrl}#booking-form`,
        price: umrahFirstTrip.price,
        currency: umrahFirstTrip.currency,
        durationDays: umrahFirstTrip.durationDays,
      });
    } else {
      programs.push({
        key: 'program-umrah-1',
        categoryLabel: 'العمرة',
        title: 'برامج العمرة الميسّرة',
        subtitle: 'رحلات مريحة بين مكة المكرمة والمدينة المنورة طوال العام.',
        imageUrl: '/src/assets/images/trip_madinah_nabawi_1795679214521.jpg',
        detailTo: ROUTES.tripsWithCategory('umrah'),
        bookTo: ROUTES.tripsWithCategory('umrah'),
      });
    }

    if (umrahSecondTrip && umrahSecondTrip.id !== umrahFirstTrip?.id) {
      const detailUrl = ROUTES.tripDetail(umrahSecondTrip.id, activeReferral?.code);
      programs.push({
        key: 'program-umrah-2',
        categoryLabel: 'العمرة',
        title: umrahSecondTrip.title,
        subtitle: umrahSecondTrip.subtitle,
        imageUrl: umrahSecondTrip.imageUrl,
        detailTo: detailUrl,
        bookTo: `${detailUrl}#booking-form`,
        price: umrahSecondTrip.price,
        currency: umrahSecondTrip.currency,
        durationDays: umrahSecondTrip.durationDays,
      });
    }

    return programs;
  }, [trips, activeReferral?.code]);

  const leisureTrips = useMemo(
    () => trips.filter((t) => !isPilgrimageCategory(t.category)).slice(0, 3),
    [trips]
  );

  return (
    <div>
      {/* 1. Primary Visual Focal Point: Admin-Controlled Featured Trips Carousel */}
      <HeroSlider slides={sliderTrips} refCode={activeReferral?.code} />

      {/* 2. Choose Your Trip Section: Clean Cards with High-Contrast Text & Buttons */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
        <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
          <div className="max-w-2xl">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#FFFFFF]">
              اختار رحلة
            </h2>
            <p className="text-sm sm:text-base text-[#E2E8F0] mt-2.5 leading-relaxed">
              رحلتك المميزة تبدأ باختيارك، اكتشف برامج الحج والعمرة واختر الرحلة المناسبة لك، واترك لنا الاهتمام بباقي التفاصيل.
            </p>
          </div>
          <Link
            to={ROUTES.tripsWithCategory('pilgrimage')}
            className="min-h-[44px] inline-flex items-center gap-1.5 text-sm font-bold text-[#C5A15B] hover:underline whitespace-nowrap"
          >
            <span>عرض جميع برامج الحج والعمرة</span>
            <ArrowLeft className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {pilgrimagePrograms.map((item) => {
            const approvedEgpPrice = formatCustomerAmount(item.price, item.currency);
            return (
              <article
                key={item.key}
                className="group rounded-2xl overflow-hidden bg-[#12233B] border border-white/15 hover:border-[#C5A15B]/55 transition-all duration-300 flex flex-col"
              >
                <Link
                  to={item.detailTo}
                  className="block aspect-[16/10] overflow-hidden bg-[#0B172A]"
                >
                  <img
                    src={item.imageUrl}
                    alt={item.title}
                    loading="lazy"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-500"
                  />
                </Link>

                <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2 text-xs font-bold text-[#C5A15B]">
                      <span>{item.categoryLabel}</span>
                      {typeof item.durationDays === 'number' && item.durationDays > 0 && (
                        <span className="font-mono-num text-[#CBD5E1]">
                          {item.durationDays} أيام
                        </span>
                      )}
                    </div>
                    <h3 className="text-lg sm:text-xl font-bold text-[#FFFFFF] leading-snug">
                      <Link to={item.detailTo} className="hover:text-[#C5A15B] transition-colors">
                        {item.title}
                      </Link>
                    </h3>
                    <p className="text-sm text-[#E2E8F0] line-clamp-2 leading-relaxed">
                      {item.subtitle}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-white/10 space-y-3">
                    <div className="text-sm font-mono-num">
                      {approvedEgpPrice ? (
                        <span className="text-base font-extrabold text-[#FFFFFF]">
                          تبدأ من {approvedEgpPrice}
                        </span>
                      ) : (
                        <span className="text-xs sm:text-sm font-semibold text-[#CBD5E1]">
                          التسعير بالجنيه المصري (ج.م) عند الاستفسار
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-2.5">
                      <Link
                        to={item.bookTo}
                        className="min-h-[44px] inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#C5A15B] text-[#0B172A] px-3 py-2 text-xs sm:text-sm font-extrabold hover:opacity-90 transition whitespace-nowrap"
                      >
                        <span>احجز الآن</span>
                        <ArrowLeft className="w-3.5 h-3.5" />
                      </Link>
                      <Link
                        to={item.detailTo}
                        className="min-h-[44px] inline-flex items-center justify-center rounded-xl border border-white/25 bg-[#0B172A]/70 text-[#FFFFFF] px-3 py-2 text-xs sm:text-sm font-bold hover:border-[#C5A15B] hover:text-[#C5A15B] transition whitespace-nowrap"
                      >
                        التفاصيل
                      </Link>
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* 3. Leisure Trips Section (Clean Secondary Options Without Priority Labels) */}
      {leisureTrips.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 py-10 border-t border-white/10">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-[#F4F1EA]">
                الرحلات الترفيهية
              </h2>
              <p className="text-xs sm:text-sm text-[#CBD5E1] mt-1">
                خيارات سياحية متنوعة لضيوفنا خارج مواسم الحج والعمرة
              </p>
            </div>
            <Link
              to={ROUTES.tripsWithCategory('leisure')}
              className="min-h-[42px] inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-[#CBD5E1] hover:text-[#C5A15B] transition whitespace-nowrap"
            >
              <span>عرض جميع الرحلات</span>
              <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {leisureTrips.map((trip) => (
              <TripCard key={trip.id} trip={trip} refCode={activeReferral?.code} compact />
            ))}
          </div>
        </section>
      )}

      {/* 4. Brief Editorial About Strip */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-10 border-t border-white/10">
        <div className="rounded-2xl bg-[#12233B]/80 border border-white/15 p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-[#C5A15B]">
              <Compass className="w-4 h-4" />
              <span>نبذة عن رحّال</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-[#FFFFFF]">
              رحلة منظمة وواضحة من الاختيار حتى إتمام الحجز
            </h2>
            <p className="text-sm sm:text-base text-[#E2E8F0] leading-relaxed">
              {settings.aboutText ||
                'منصة رحّال (REHHAL) متخصصة في تنظيم وتقديم برامج الحج والعمرة وتسهيل الوصول إلى تفاصيل الرحلات وإتمام الحجز بوضوح وموثوقية.'}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <Link
              to={ROUTES.ABOUT}
              className="min-h-[44px] inline-flex items-center justify-center rounded-xl border border-[#C5A15B]/55 px-5 py-2 text-sm font-bold text-[#FFFFFF] hover:border-[#C5A15B] hover:text-[#C5A15B] transition whitespace-nowrap"
            >
              اقرأ المزيد عن رحّال
            </Link>
            <Link
              to={ROUTES.SUPPORT}
              className="min-h-[44px] inline-flex items-center justify-center rounded-xl bg-[#C5A15B] text-[#0B172A] px-5 py-2 text-sm font-extrabold hover:opacity-90 transition whitespace-nowrap"
            >
              تواصل معنا
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};
