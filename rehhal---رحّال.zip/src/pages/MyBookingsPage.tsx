import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CalendarCheck, ArrowLeft } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { ROUTES } from '../routes/routeRegistry';
import { fetchCustomerBookings } from '../services/firestoreService';
import type { Booking } from '../types';
import { formatCustomerLedgerAmount } from '../utils/currency';

const STATUS_AR: Record<Booking['status'], string> = {
  pending_payment: 'بانتظار الدفع',
  confirmed: 'مؤكد',
  completed: 'مكتمل',
  cancelled: 'ملغي',
};

export const MyBookingsPage: React.FC = () => {
  const { user } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | Booking['status']>('all');

  useEffect(() => {
    if (!user) return;
    fetchCustomerBookings(user.uid)
      .then(setBookings)
      .finally(() => setLoading(false));
  }, [user]);

  const filtered = filter === 'all' ? bookings : bookings.filter((b) => b.status === filter);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 sm:py-10 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-[#F4F1EA]">حجوزاتي</h1>
          <p className="text-sm text-[#9BA8BC] mt-1">متابعة حالة الطلبات والفواتير والرحلات القادمة</p>
        </div>
        <Link
          to={ROUTES.TRIPS}
          className="min-h-[44px] inline-flex items-center gap-2 rounded-xl bg-[#C5A15B] text-[#0B172A] px-5 py-2.5 text-sm font-bold"
        >
          <span>حجز رحلة جديدة</span>
          <ArrowLeft className="w-4 h-4" />
        </Link>
      </div>

      <div className="flex flex-wrap gap-2">
        {[
          { id: 'all', label: 'الكل' },
          { id: 'pending_payment', label: 'بانتظار الدفع' },
          { id: 'confirmed', label: 'مؤكدة' },
          { id: 'completed', label: 'مكتملة' },
          { id: 'cancelled', label: 'ملغاة' },
        ].map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setFilter(item.id as typeof filter)}
            className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold transition ${
              filter === item.id
                ? 'bg-[#C5A15B] text-[#0B172A]'
                : 'bg-[#12233B] text-[#CBD5E1] border border-white/10 hover:text-white'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1, 2].map((n) => (
            <div key={n} className="h-28 rounded-2xl bg-[#12233B] animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl bg-[#12233B] border border-white/10 p-10 text-center space-y-4">
          <CalendarCheck className="w-10 h-10 text-[#C5A15B] mx-auto" />
          <div className="text-base font-bold text-[#F4F1EA]">لا توجد حجوزات في هذا التصنيف</div>
          <Link
            to={ROUTES.TRIPS}
            className="min-h-[44px] inline-flex items-center justify-center rounded-xl bg-[#C5A15B] text-[#0B172A] px-6 py-2.5 text-sm font-bold"
          >
            استكشاف الرحلات
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map((b) => (
            <Link
              key={b.id}
              to={ROUTES.bookingDetail(b.id)}
              className="block rounded-2xl bg-[#12233B] border border-white/10 hover:border-[#C5A15B]/50 p-5 transition"
            >
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="text-xs text-[#9BA8BC] font-mono-num">
                    {b.id} · موعد الرحلة: {b.travelDate} · {b.guests} ضيوف
                  </div>
                  <h2 className="text-lg font-bold text-[#F4F1EA]">{b.tripTitle}</h2>
                </div>
                <div className="text-left">
                  <div className="text-base font-bold text-[#C5A15B] font-mono-num">
                    {formatCustomerLedgerAmount(b.totalAmount, b.currency).text}
                  </div>
                  <div className="text-xs text-[#CBD5E1] mt-1">{STATUS_AR[b.status]}</div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
};
