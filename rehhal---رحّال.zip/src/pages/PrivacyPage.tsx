import React from 'react';
import { Link } from 'react-router-dom';
import { ROUTES } from '../routes/routeRegistry';

export const PrivacyPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10 sm:py-14 space-y-8">
      <div className="space-y-2">
        <p className="text-xs font-semibold text-[#C5A15B]">الالتزام بحماية البيانات</p>
        <h1 className="text-2xl sm:text-4xl font-bold text-[#F4F1EA]">سياسة الخصوصية</h1>
        <p className="text-xs text-[#9BA8BC]">آخر تحديث: نوفمبر 2026</p>
      </div>

      <div className="rounded-2xl bg-[#12233B] border border-white/10 p-6 sm:p-8 space-y-6 text-sm text-[#CBD5E1] leading-relaxed">
        <section className="space-y-2">
          <h2 className="text-base font-bold text-[#F4F1EA]">1. البيانات التي نجمعها</h2>
          <p>
            تجمع منصة رحّال بيانات الحساب والحجز اللازمة لتنظيم رحلات الحج والعمرة والرحلات المختارة،
            وتشمل الاسم الكامل، البريد الإلكتروني، رقم الجوال، والمدينة، إضافة إلى تفاصيل الحجز المختار.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-[#F4F1EA]">2. حماية الخصوصية وعزل الصلاحيات</h2>
          <p>
            يتم عزل البيانات الشخصية والحجوزات وتقييمات المنصة بحيث لا يطّلع عليها إلا صاحب الحساب
            المصادق عليه والإدارة المخولة وفق قواعد الأمان المعتمدة في قاعدة البيانات.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-[#F4F1EA]">3. حفظ بيانات الجلسة والإحالة</h2>
          <p>
            تُستخدم ذاكرة المتصفح المؤقتة للاحتفاظ بسير الحجز أو رمز الإحالة عند الانتقال لتسجيل الدخول
            دون مشاركة بياناتك مع أي أطراف تسويقية خارجية.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-[#F4F1EA]">4. طلبات التعديل والاستفسار</h2>
          <p>
            يمكنك تحديث بيانات ملفك الشخصي في أي وقت عبر صفحة الملف الشخصي، أو مراسلتنا لطلبات
            الدعم عبر صفحة{' '}
            <Link to={ROUTES.SUPPORT} className="text-[#C5A15B] hover:underline">
              تواصل معنا
            </Link>
            .
          </p>
        </section>
      </div>
    </div>
  );
};
