import React, { useEffect, useState } from 'react';
import { Plus, Sliders } from 'lucide-react';
import { AdminSubNav } from '../components/SubNav';
import { useToast } from '../context/ToastContext';
import { adminSaveTrip, fetchTrips } from '../services/firestoreService';
import { TRIP_CATEGORY_LABELS, type ProgramTier, type Trip, type TripCategory } from '../types';
import { formatAdminAmount, isApprovedEgpCurrency } from '../utils/currency';

const EMPTY_TRIP: Trip = {
  id: '',
  title: '',
  subtitle: '',
  destination: '',
  category: 'umrah',
  durationDays: 5,
  price: 0,
  currency: 'EGP',
  maxGuests: 14,
  rating: 4.9,
  imageUrl: '/src/assets/images/trip_umrah_makkah_suite_1795679215191.jpg',
  description: '',
  highlights: ['إقامة قريبة من الحرم', 'مرشد ومشرف معتمد'],
  services: ['الإقامة الفندقية', 'الاستقبال والتنقلات', 'الدعم والإشراف طوال الرحلة'],
  terms: '',
  departureDates: ['2027-01-15', '2027-02-01'],
  active: true,
  featured: true,
  sliderVisible: false,
  sliderOrder: 10,
  displayOrder: 10,
  programTier: 'umrah',
};

function parseLines(raw: string): string[] {
  return raw
    .split(/[\n،,]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

export const AdminTripsPage: React.FC = () => {
  const { showToast } = useToast();
  const [trips, setTrips] = useState<Trip[]>([]);
  const [editing, setEditing] = useState<Trip>(EMPTY_TRIP);
  const [highlightsText, setHighlightsText] = useState(EMPTY_TRIP.highlights.join('\n'));
  const [servicesText, setServicesText] = useState((EMPTY_TRIP.services || []).join('\n'));
  const [datesText, setDatesText] = useState(EMPTY_TRIP.departureDates.join(', '));
  const [isNew, setIsNew] = useState(true);
  const [saving, setSaving] = useState(false);

  const loadTrips = () => {
    fetchTrips().then(setTrips);
  };

  useEffect(() => {
    loadTrips();
  }, []);

  const startNew = () => {
    setEditing(EMPTY_TRIP);
    setHighlightsText(EMPTY_TRIP.highlights.join('\n'));
    setServicesText((EMPTY_TRIP.services || []).join('\n'));
    setDatesText(EMPTY_TRIP.departureDates.join(', '));
    setIsNew(true);
  };

  const selectForEdit = (t: Trip) => {
    setEditing({
      ...EMPTY_TRIP,
      ...t,
      sliderVisible: Boolean(t.sliderVisible),
      sliderOrder: typeof t.sliderOrder === 'number' ? t.sliderOrder : 10,
      displayOrder: typeof t.displayOrder === 'number' ? t.displayOrder : 10,
      programTier:
        t.programTier || (t.category === 'hajj' ? 'hajj' : t.category === 'umrah' ? 'umrah' : 'leisure'),
    });
    setHighlightsText((t.highlights || []).join('\n'));
    setServicesText((t.services || []).join('\n'));
    setDatesText((t.departureDates || []).join(', '));
    setIsNew(false);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^[a-zA-Z0-9_\-]{2,80}$/.test(editing.id.trim())) {
      showToast('معرّف الرحلة يجب أن يكون باللغة الإنجليزية بدون مسافات (مثل: tabuk-canyon)', 'error');
      return;
    }
    setSaving(true);
    try {
      await adminSaveTrip(
        {
          ...editing,
          id: editing.id.trim(),
          highlights: parseLines(highlightsText),
          services: parseLines(servicesText),
          departureDates: parseLines(datesText),
        },
        isNew
      );
      showToast(isNew ? 'تمت إضافة الرحلة بنجاح' : 'تم تحديث بيانات الرحلة والسلايدر', 'success');
      startNew();
      loadTrips();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'تعذر حفظ الرحلة', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <AdminSubNav />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-5">
          <form
            onSubmit={handleSave}
            className="rounded-2xl bg-[#12233B] border border-[#C5A15B]/30 p-6 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h1 className="text-lg font-bold text-[#F4F1EA]">
                {isNew ? 'إضافة رحلة جديدة' : `تعديل: ${editing.title}`}
              </h1>
              {!isNew && (
                <button
                  type="button"
                  onClick={startNew}
                  className="text-xs text-[#C5A15B] hover:underline"
                >
                  إلغاء التعديل
                </button>
              )}
            </div>

            <div>
              <label htmlFor="trip-id" className="block text-xs text-[#CBD5E1] mb-1">
                المعرّف الإنجليزي (Slug) *
              </label>
              <input
                id="trip-id"
                type="text"
                required
                disabled={!isNew}
                value={editing.id}
                onChange={(e) => setEditing({ ...editing, id: e.target.value })}
                placeholder="umrah-vip-program"
                className="w-full min-h-[42px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-sm text-[#F4F1EA] font-mono-num disabled:opacity-60"
                dir="ltr"
              />
            </div>

            <div>
              <label htmlFor="trip-title" className="block text-xs text-[#CBD5E1] mb-1">
                اسم الرحلة *
              </label>
              <input
                id="trip-title"
                type="text"
                required
                value={editing.title}
                onChange={(e) => setEditing({ ...editing, title: e.target.value })}
                className="w-full min-h-[42px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-sm text-[#F4F1EA]"
              />
            </div>

            <div>
              <label htmlFor="trip-subtitle" className="block text-xs text-[#CBD5E1] mb-1">
                العنوان المختصر *
              </label>
              <input
                id="trip-subtitle"
                type="text"
                required
                value={editing.subtitle}
                onChange={(e) => setEditing({ ...editing, subtitle: e.target.value })}
                className="w-full min-h-[42px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-sm text-[#F4F1EA]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="trip-dest" className="block text-xs text-[#CBD5E1] mb-1">
                  الوجهة *
                </label>
                <input
                  id="trip-dest"
                  type="text"
                  required
                  value={editing.destination}
                  onChange={(e) => setEditing({ ...editing, destination: e.target.value })}
                  className="w-full min-h-[42px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-sm text-[#F4F1EA]"
                />
              </div>

              <div>
                <label htmlFor="trip-cat" className="block text-xs text-[#CBD5E1] mb-1">
                  التصنيف *
                </label>
                <select
                  id="trip-cat"
                  value={editing.category}
                  onChange={(e) => {
                    const nextCat = e.target.value as TripCategory;
                    const nextTier: ProgramTier =
                      nextCat === 'hajj' ? 'hajj' : nextCat === 'umrah' ? 'umrah' : 'leisure';
                    setEditing({ ...editing, category: nextCat, programTier: nextTier });
                  }}
                  className="w-full min-h-[42px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-sm text-[#F4F1EA]"
                >
                  <option value="hajj">الحج</option>
                  <option value="umrah">العمرة</option>
                  <option value="desert">ترفيهية · صحراوية</option>
                  <option value="coastal">ترفيهية · بحرية</option>
                  <option value="mountain">ترفيهية · جبلية</option>
                  <option value="heritage">ترفيهية · تراثية</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="trip-tier" className="block text-xs text-[#CBD5E1] mb-1">
                  تصنيف العرض بالصفحة الرئيسية
                </label>
                <select
                  id="trip-tier"
                  value={editing.programTier || 'umrah'}
                  onChange={(e) =>
                    setEditing({ ...editing, programTier: e.target.value as ProgramTier })
                  }
                  className="w-full min-h-[42px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-sm text-[#F4F1EA]"
                >
                  <option value="hajj">الحج</option>
                  <option value="umrah">العمرة</option>
                  <option value="umrah_vip">برامج العمرة</option>
                  <option value="leisure">الرحلات الترفيهية</option>
                </select>
              </div>

              <div>
                <label htmlFor="trip-image" className="block text-xs text-[#CBD5E1] mb-1">
                  رابط الصورة *
                </label>
                <input
                  id="trip-image"
                  type="text"
                  required
                  value={editing.imageUrl}
                  onChange={(e) => setEditing({ ...editing, imageUrl: e.target.value })}
                  dir="ltr"
                  className="w-full min-h-[42px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-xs font-mono-num text-[#F4F1EA]"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label htmlFor="trip-price" className="block text-xs text-[#CBD5E1] mb-1">
                  السعر (اختياري)
                </label>
                <input
                  id="trip-price"
                  type="number"
                  min={0}
                  value={editing.price ?? ''}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      price: e.target.value === '' ? null : Number(e.target.value),
                    })
                  }
                  placeholder="عند الاستفسار"
                  className="w-full min-h-[42px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-sm font-mono-num text-[#F4F1EA]"
                />
              </div>
              <div>
                <label htmlFor="trip-currency" className="block text-xs text-[#CBD5E1] mb-1">
                  عملة السعر *
                </label>
                <select
                  id="trip-currency"
                  value={editing.currency || 'SAR'}
                  onChange={(e) => setEditing({ ...editing, currency: e.target.value })}
                  className="w-full min-h-[42px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-xs font-bold text-[#F4F1EA]"
                >
                  <option value="EGP">EGP (جنيه مصري معتمد)</option>
                  <option value="SAR">SAR (مراجعة قبل التفعيل)</option>
                </select>
              </div>
              <div>
                <label htmlFor="trip-days" className="block text-xs text-[#CBD5E1] mb-1">
                  الأيام (اختياري)
                </label>
                <input
                  id="trip-days"
                  type="number"
                  min={1}
                  max={60}
                  value={editing.durationDays ?? ''}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      durationDays: e.target.value === '' ? null : Number(e.target.value),
                    })
                  }
                  className="w-full min-h-[42px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-sm font-mono-num text-[#F4F1EA]"
                />
              </div>
              <div>
                <label htmlFor="trip-guests" className="block text-xs text-[#CBD5E1] mb-1">
                  الضيوف *
                </label>
                <input
                  id="trip-guests"
                  type="number"
                  min={1}
                  max={100}
                  required
                  value={editing.maxGuests}
                  onChange={(e) => setEditing({ ...editing, maxGuests: Number(e.target.value) })}
                  className="w-full min-h-[42px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-sm font-mono-num text-[#F4F1EA]"
                />
              </div>
            </div>

            {/* Homepage Slider & Ordering Controls */}
            <div className="rounded-xl bg-[#0B172A] border border-[#C5A15B]/25 p-3.5 space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-[#C5A15B]">
                <Sliders className="w-4 h-4" />
                <span>التحكم بالسلايدر والترتيب</span>
              </div>
              <label className="flex items-center gap-2 text-xs text-[#CBD5E1] cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(editing.sliderVisible)}
                  onChange={(e) => setEditing({ ...editing, sliderVisible: e.target.checked })}
                  className="w-4 h-4 accent-[#C5A15B]"
                />
                <span>إظهار هذه الرحلة في سلايدر الصفحة الرئيسية</span>
              </label>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="trip-slider-order" className="block text-[11px] text-[#9BA8BC] mb-1">
                    ترتيب السلايدر
                  </label>
                  <input
                    id="trip-slider-order"
                    type="number"
                    min={0}
                    max={999}
                    value={editing.sliderOrder ?? 10}
                    onChange={(e) =>
                      setEditing({ ...editing, sliderOrder: Number(e.target.value) })
                    }
                    className="w-full min-h-[38px] rounded-lg bg-[#12233B] border border-white/15 px-3 text-xs font-mono-num text-[#F4F1EA]"
                  />
                </div>
                <div>
                  <label htmlFor="trip-display-order" className="block text-[11px] text-[#9BA8BC] mb-1">
                    ترتيب العرض العام
                  </label>
                  <input
                    id="trip-display-order"
                    type="number"
                    min={0}
                    max={9999}
                    value={editing.displayOrder ?? 10}
                    onChange={(e) =>
                      setEditing({ ...editing, displayOrder: Number(e.target.value) })
                    }
                    className="w-full min-h-[38px] rounded-lg bg-[#12233B] border border-white/15 px-3 text-xs font-mono-num text-[#F4F1EA]"
                  />
                </div>
              </div>
            </div>

            <div>
              <label htmlFor="trip-desc" className="block text-xs text-[#CBD5E1] mb-1">
                الوصف الكامل *
              </label>
              <textarea
                id="trip-desc"
                rows={3}
                required
                minLength={10}
                value={editing.description}
                onChange={(e) => setEditing({ ...editing, description: e.target.value })}
                className="w-full rounded-xl bg-[#0B172A] border border-white/15 px-3 py-2 text-sm text-[#F4F1EA]"
              />
            </div>

            <div>
              <label htmlFor="trip-highlights" className="block text-xs text-[#CBD5E1] mb-1">
                المميزات (كل سطر ميزة)
              </label>
              <textarea
                id="trip-highlights"
                rows={2}
                value={highlightsText}
                onChange={(e) => setHighlightsText(e.target.value)}
                className="w-full rounded-xl bg-[#0B172A] border border-white/15 px-3 py-2 text-xs text-[#F4F1EA]"
              />
            </div>

            <div>
              <label htmlFor="trip-services" className="block text-xs text-[#CBD5E1] mb-1">
                الخدمات المشمولة (كل سطر خدمة)
              </label>
              <textarea
                id="trip-services"
                rows={2}
                value={servicesText}
                onChange={(e) => setServicesText(e.target.value)}
                className="w-full rounded-xl bg-[#0B172A] border border-white/15 px-3 py-2 text-xs text-[#F4F1EA]"
              />
            </div>

            <div>
              <label htmlFor="trip-dates" className="block text-xs text-[#CBD5E1] mb-1">
                تواريخ الانطلاق المتاحة (مفصولة بفاصلة)
              </label>
              <input
                id="trip-dates"
                type="text"
                value={datesText}
                onChange={(e) => setDatesText(e.target.value)}
                dir="ltr"
                placeholder="2027-01-15, 2027-02-01"
                className="w-full min-h-[40px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-xs font-mono-num text-[#F4F1EA]"
              />
            </div>

            <div>
              <label htmlFor="trip-terms" className="block text-xs text-[#CBD5E1] mb-1">
                الشروط والأحكام الخاصة بالبرنامج (اختياري)
              </label>
              <textarea
                id="trip-terms"
                rows={2}
                value={editing.terms || ''}
                onChange={(e) => setEditing({ ...editing, terms: e.target.value })}
                className="w-full rounded-xl bg-[#0B172A] border border-white/15 px-3 py-2 text-xs text-[#F4F1EA]"
              />
            </div>

            <label className="flex items-center gap-2 text-xs text-[#CBD5E1] cursor-pointer">
              <input
                type="checkbox"
                checked={editing.active}
                onChange={(e) => setEditing({ ...editing, active: e.target.checked })}
                className="w-4 h-4 accent-[#C5A15B]"
              />
              <span>الرحلة متاحة ومفعّلة للعرض والحجز</span>
            </label>

            <button
              type="submit"
              disabled={saving}
              className="w-full min-h-[46px] inline-flex items-center justify-center gap-2 rounded-xl bg-[#C5A15B] text-[#0B172A] text-sm font-bold hover:opacity-90 disabled:opacity-50"
            >
              <Plus className="w-4 h-4" />
              <span>{saving ? 'جاري الحفظ...' : isNew ? 'إضافة الرحلة' : 'حفظ التعديلات'}</span>
            </button>
          </form>
        </div>

        <div className="lg:col-span-7 space-y-4">
          <h2 className="text-lg font-bold text-[#F4F1EA]">
            قائمة البرامج والرحلات ({trips.length})
          </h2>

          {trips.some((t) => !isApprovedEgpCurrency(t.currency)) && (
            <div className="rounded-xl border border-amber-500/40 bg-amber-500/10 p-4 text-xs sm:text-sm text-amber-200 leading-relaxed">
              تنبيه مراجعة العملات: توجد باقات محفوظة بقيم <strong className="font-mono-num">SAR</strong> سابقة ولا تُعرض أسعارها للمستخدمين كـ <strong className="font-bold">ج.م</strong>. راجع كل باقة وحدّث سعرها بالجنيه المصري ثم غيّر العملة إلى <strong className="font-mono-num">EGP</strong> لاعتمادها.
            </div>
          )}

          <div className="space-y-3">
            {trips.map((t) => {
              const adminPrice = formatAdminAmount(t.price, t.currency);
              return (
                <div
                  key={t.id}
                  className="rounded-2xl bg-[#12233B] border border-white/10 p-4 flex flex-wrap items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-[#C5A15B] font-mono-num">
                      <span>{t.id}</span>
                      <span>·</span>
                      <span>{TRIP_CATEGORY_LABELS[t.category]}</span>
                      <span>·</span>
                      <span className={adminPrice.needsReview ? 'text-amber-300' : 'text-[#C5A15B]'}>
                        {typeof t.price === 'number' && t.price > 0
                          ? adminPrice.text
                          : 'بدون سعر محدد'}
                      </span>
                      {t.sliderVisible && (
                        <span className="rounded bg-[#C5A15B]/20 px-2 py-0.5 text-[11px] font-bold text-[#C5A15B]">
                          سلايدر #{t.sliderOrder ?? '-'}
                        </span>
                      )}
                      {!t.active && (
                        <span className="rounded bg-red-500/20 px-2 py-0.5 text-[11px] text-red-300">
                          موقفة
                        </span>
                      )}
                    </div>
                    <div className="text-base font-bold text-[#F4F1EA]">{t.title}</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => selectForEdit(t)}
                    className="min-h-[40px] rounded-xl border border-[#C5A15B]/40 px-4 py-1.5 text-xs font-semibold text-[#C5A15B] hover:bg-[#C5A15B]/10 transition"
                  >
                    تعديل
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
