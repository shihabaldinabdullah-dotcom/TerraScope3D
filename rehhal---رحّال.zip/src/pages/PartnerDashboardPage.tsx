import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Copy, ExternalLink, MousePointerClick, TrendingUp, Wallet } from 'lucide-react';
import { PartnerSubNav } from '../components/SubNav';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { CURATED_TRIPS } from '../data/curatedTrips';
import { ROUTES } from '../routes/routeRegistry';
import {
  fetchMarketerCommissions,
  fetchMarketerReferredBookings,
} from '../services/firestoreService';
import type { Booking, CommissionRecord } from '../types';
import { formatCustomerLedgerAmount, formatEgpAmount, isApprovedEgpCurrency } from '../utils/currency';

export const PartnerDashboardPage: React.FC = () => {
  const { marketer } = useAuth();
  const { showToast } = useToast();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [commissions, setCommissions] = useState<CommissionRecord[]>([]);
  const [clicksCount, setClicksCount] = useState(0);

  useEffect(() => {
    if (!marketer) return;
    fetchMarketerReferredBookings(marketer.uid).then(setBookings);
    fetchMarketerCommissions(marketer.uid).then(setCommissions);
    fetch(`/api/referrals/stats/${encodeURIComponent(marketer.referralCode)}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d && typeof d.uniqueClicks === 'number') setClicksCount(d.uniqueClicks);
      })
      .catch(() => undefined);
  }, [marketer]);

  if (!marketer) return null;

  const sampleShareUrl = ROUTES.absoluteTripShareUrl(
    CURATED_TRIPS[0].id,
    marketer.referralCode
  );

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(sampleShareUrl);
      showToast('تم نسخ رابط الإحالة الخاص بك', 'success');
    } catch {
      showToast('تعذر النسخ التلقائي', 'error');
    }
  };

  const pendingEgpAmount = commissions
    .filter((c) => c.status === 'pending' && isApprovedEgpCurrency(c.currency))
    .reduce((acc, c) => acc + c.amount, 0);

  return (
    <div>
      <PartnerSubNav />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-[#F4F1EA]">
              مرحباً {marketer.fullName}
            </h1>
            <p className="text-sm text-[#9BA8BC] mt-1">
              كود الإحالة: <strong className="text-[#C5A15B] font-mono-num">{marketer.referralCode}</strong>
              {' · '}نسبة العمولة: <span className="font-mono-num">{Math.round(marketer.commissionRate * 100)}%</span>
            </p>
          </div>
          <Link
            to={ROUTES.PARTNERS_PAYOUTS}
            className="min-h-[44px] inline-flex items-center gap-2 rounded-xl bg-[#C5A15B] text-[#0B172A] px-5 py-2.5 text-sm font-bold"
          >
            <Wallet className="w-4 h-4" />
            <span>طلب سحب الأرباح</span>
          </Link>
        </div>

        {/* KPI Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="rounded-2xl bg-[#12233B] border border-white/10 p-5">
            <div className="flex items-center justify-between text-xs text-[#9BA8BC] mb-2">
              <span>الرصيد القابل للسحب</span>
              <Wallet className="w-4 h-4 text-[#C5A15B]" />
            </div>
            <div className="text-2xl font-bold text-[#C5A15B] font-mono-num">
              {formatCustomerLedgerAmount(marketer.availableBalance, marketer.currency).text}
            </div>
          </div>

          <div className="rounded-2xl bg-[#12233B] border border-white/10 p-5">
            <div className="flex items-center justify-between text-xs text-[#9BA8BC] mb-2">
              <span>عمولات قيد الاستحقاق</span>
              <TrendingUp className="w-4 h-4 text-[#C5A15B]" />
            </div>
            <div className="text-2xl font-bold text-[#F4F1EA] font-mono-num">
              {formatEgpAmount(pendingEgpAmount)}
            </div>
          </div>

          <div className="rounded-2xl bg-[#12233B] border border-white/10 p-5">
            <div className="flex items-center justify-between text-xs text-[#9BA8BC] mb-2">
              <span>الحجوزات المحالة</span>
              <ExternalLink className="w-4 h-4 text-[#C5A15B]" />
            </div>
            <div className="text-2xl font-bold text-[#F4F1EA] font-mono-num">
              {bookings.length}
            </div>
          </div>

          <div className="rounded-2xl bg-[#12233B] border border-white/10 p-5">
            <div className="flex items-center justify-between text-xs text-[#9BA8BC] mb-2">
              <span>نقرات الإحالة الفريدة</span>
              <MousePointerClick className="w-4 h-4 text-[#C5A15B]" />
            </div>
            <div className="text-2xl font-bold text-[#F4F1EA] font-mono-num">
              {clicksCount}
            </div>
          </div>
        </div>

        {/* Quick Share Box */}
        <div className="rounded-2xl bg-[#12233B] border border-[#C5A15B]/30 p-6 space-y-3">
          <h2 className="text-base font-bold text-[#F4F1EA]">رابط المشاركة السريع لأشهر رحلة</h2>
          <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              readOnly
              value={sampleShareUrl}
              aria-label="رابط الإحالة"
              className="flex-1 min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-xs text-[#CBD5E1] font-mono-num"
              dir="ltr"
            />
            <button
              type="button"
              onClick={handleCopy}
              className="min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-[#C5A15B] text-[#0B172A] px-5 py-2 text-sm font-bold hover:opacity-90 transition shrink-0"
            >
              <Copy className="w-4 h-4" />
              <span>نسخ الرابط</span>
            </button>
          </div>
          <div className="pt-1">
            <Link to={ROUTES.PARTNERS_REFERRALS} className="text-xs font-semibold text-[#C5A15B] hover:underline">
              إنشاء روابط مخصصة لجميع الرحلات ←
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
