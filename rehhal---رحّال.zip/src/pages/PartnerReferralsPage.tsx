import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Copy, ExternalLink } from 'lucide-react';
import { PartnerSubNav } from '../components/SubNav';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { CURATED_TRIPS } from '../data/curatedTrips';
import { ROUTES } from '../routes/routeRegistry';
import { fetchTrips } from '../services/firestoreService';
import type { Trip } from '../types';
import { formatEgpAmount, isApprovedEgpCurrency } from '../utils/currency';

export const PartnerReferralsPage: React.FC = () => {
  const { marketer } = useAuth();
  const { showToast } = useToast();
  const [trips, setTrips] = useState<Trip[]>(CURATED_TRIPS);

  useEffect(() => {
    fetchTrips().then((data) => {
      if (data.length > 0) setTrips(data.filter((t) => t.active));
    });
  }, []);

  if (!marketer) return null;

  const copyLink = async (url: string, title: string) => {
    try {
      await navigator.clipboard.writeText(url);
      showToast(`تم نسخ رابط الإحالة لرحلة: ${title}`, 'success');
    } catch {
      showToast('تعذر النسخ إلى الحافظة', 'error');
    }
  };

  return (
    <div>
      <PartnerSubNav />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-[#F4F1EA]">روابط الإحالة القابلة للمشاركة</h1>
          <p className="text-sm text-[#9BA8BC] mt-1">
            كل رابط يحتوي على كودك الموثق{' '}
            <strong className="text-[#C5A15B] font-mono-num">{marketer.referralCode}</strong>
          </p>
        </div>

        <div className="space-y-4">
          {trips.map((trip) => {
            const shareUrl = ROUTES.absoluteTripShareUrl(trip.id, marketer.referralCode);
            const expectedCommission =
              typeof trip.price === 'number' &&
              trip.price > 0 &&
              isApprovedEgpCurrency(trip.currency)
                ? Math.round(trip.price * marketer.commissionRate)
                : null;
            return (
              <div
                key={trip.id}
                className="rounded-2xl bg-[#12233B] border border-white/10 p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="text-xs text-[#C5A15B]">
                    {trip.destination} ·{' '}
                    {expectedCommission !== null ? (
                      <>
                        عمولة متوقعة للفرد:{' '}
                        <span className="font-mono-num">{formatEgpAmount(expectedCommission)}</span>
                      </>
                    ) : (
                      <span>تُحتسب العمولة بـ ج.م عند تأكيد التسعير</span>
                    )}
                  </div>
                  <h2 className="text-base font-bold text-[#F4F1EA]">{trip.title}</h2>
                  <div className="text-xs text-[#9BA8BC] font-mono-num break-all" dir="ltr">
                    {shareUrl}
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => copyLink(shareUrl, trip.title)}
                    className="min-h-[42px] inline-flex items-center gap-2 rounded-xl bg-[#C5A15B] text-[#0B172A] px-4 py-2 text-xs font-bold hover:opacity-90 transition"
                  >
                    <Copy className="w-4 h-4" />
                    <span>نسخ الرابط</span>
                  </button>
                  <Link
                    to={ROUTES.tripDetail(trip.id, marketer.referralCode)}
                    className="min-h-[42px] inline-flex items-center gap-1.5 rounded-xl border border-white/20 px-4 py-2 text-xs font-semibold text-[#F4F1EA] hover:bg-white/5 transition"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>معاينة</span>
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
