import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Compass, ShieldCheck } from 'lucide-react';
import { usePlatformSettings } from '../context/SettingsContext';
import { ROUTES } from '../routes/routeRegistry';

export const AboutPage: React.FC = () => {
  const { settings } = usePlatformSettings();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10 sm:py-14 space-y-8">
      <div className="space-y-3">
        <p className="text-xs font-semibold text-[#C5A15B]">من نحن</p>
        <h1 className="text-2xl sm:text-4xl font-bold text-[#F4F1EA]">منصة رحّال (REHHAL)</h1>
        <p className="text-base text-[#CBD5E1] leading-relaxed">
          {settings.aboutText ||
            'منصة رحّال متخصصة في تنظيم وتقديم برامج الحج والعمرة وتسهيل الوصول إلى تفاصيل الرحلات وإتمام الحجز بوضوح وموثوقية.'}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="rounded-2xl bg-[#12233B] border border-white/10 p-6 space-y-3">
          <Compass className="w-6 h-6 text-[#C5A15B]" />
          <h2 className="text-lg font-bold text-[#F4F1EA]">تخصصنا الأساسي</h2>
          <p className="text-sm text-[#CBD5E1] leading-relaxed">
            تركّز رحّال على تقديم باقات الحج والعمرة في مكة المكرمة والمدينة المنورة بمعلومات واضحة
            تشمل الإقامة، الخدمات الميدانية، المواعيد المعتمدة، وإجراءات الحجز المنظمة، مع توفير
            رحلات ترفيهية مختارة كخدمة مساندة.
          </p>
        </div>

        <div className="rounded-2xl bg-[#12233B] border border-white/10 p-6 space-y-3">
          <ShieldCheck className="w-6 h-6 text-[#C5A15B]" />
          <h2 className="text-lg font-bold text-[#F4F1EA]">وضوح البيانات والخدمة</h2>
          <p className="text-sm text-[#CBD5E1] leading-relaxed">
            نلتزم بعرض تفاصيل البرامج والأسعار والمواعيد المعتمدة فقط، مع ربط تقييمات الرحلات
            بالحجوزات المكتملة الفعلية وإتاحة قنوات تواصل مباشرة لخدمة ضيوف الرحمن.
          </p>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-4 pt-2">
        <Link
          to={ROUTES.tripsWithCategory('pilgrimage')}
          className="min-h-[44px] inline-flex items-center gap-2 rounded-xl bg-[#C5A15B] text-[#0B172A] px-6 py-2.5 text-sm font-bold hover:opacity-90 transition"
        >
          <span>استعراض برامج الحج والعمرة</span>
          <ArrowLeft className="w-4 h-4" />
        </Link>
        <Link
          to={ROUTES.SUPPORT}
          className="min-h-[44px] inline-flex items-center rounded-xl border border-white/20 px-5 py-2.5 text-sm font-semibold text-[#F4F1EA] hover:border-[#C5A15B]"
        >
          تواصل معنا
        </Link>
      </div>
    </div>
  );
};
