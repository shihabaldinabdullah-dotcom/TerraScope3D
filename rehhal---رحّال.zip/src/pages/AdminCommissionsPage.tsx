import React, { useEffect, useState } from 'react';
import { AdminSubNav } from '../components/SubNav';
import { adminFetchAllCommissions } from '../services/firestoreService';
import type { CommissionRecord } from '../types';
import { formatAdminAmount } from '../utils/currency';

export const AdminCommissionsPage: React.FC = () => {
  const [commissions, setCommissions] = useState<CommissionRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminFetchAllCommissions()
      .then(setCommissions)
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <AdminSubNav />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <h1 className="text-2xl font-bold text-[#F4F1EA]">سجل العمولات العام</h1>

        <div className="rounded-2xl bg-[#12233B] border border-white/10 overflow-x-auto">
          {loading ? (
            <div className="p-8 text-center text-sm text-[#9BA8BC]">جاري التحميل...</div>
          ) : commissions.length === 0 ? (
            <div className="p-8 text-center text-sm text-[#9BA8BC]">لا توجد عمولات مسجلة بعد.</div>
          ) : (
            <table className="w-full text-right text-sm">
              <thead className="border-b border-white/10 text-xs text-[#9BA8BC]">
                <tr>
                  <th className="px-4 py-3">رقم الحجز</th>
                  <th className="px-4 py-3">كود الإحالة</th>
                  <th className="px-4 py-3">الرحلة</th>
                  <th className="px-4 py-3">قيمة الحجز</th>
                  <th className="px-4 py-3">العمولة</th>
                  <th className="px-4 py-3">الحالة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {commissions.map((c) => (
                  <tr key={c.id} className="hover:bg-white/5">
                    <td className="px-4 py-3 font-mono-num text-xs">{c.bookingId}</td>
                    <td className="px-4 py-3 font-mono-num text-[#C5A15B]">{c.referralCode}</td>
                    <td className="px-4 py-3 text-xs">{c.tripTitle}</td>
                    <td className="px-4 py-3 font-mono-num">
                      {formatAdminAmount(c.bookingAmount, c.currency).text}
                    </td>
                    <td className="px-4 py-3 font-mono-num font-bold text-[#C5A15B]">
                      {formatAdminAmount(c.amount, c.currency).text}
                    </td>
                    <td className="px-4 py-3 text-xs">{c.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
