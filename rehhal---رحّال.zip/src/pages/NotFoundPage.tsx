import React from 'react';
import { Link } from 'react-router-dom';
import { Compass, Home } from 'lucide-react';
import { ROUTES } from '../routes/routeRegistry';

export const NotFoundPage: React.FC = () => {
  return (
    <div className="max-w-lg mx-auto px-4 py-20 text-center">
      <div className="rounded-2xl bg-[#12233B] border border-[#C5A15B]/30 p-8 space-y-5">
        <div className="font-mono-num text-4xl font-bold text-[#C5A15B]">404</div>
        <h1 className="text-2xl font-bold text-[#F4F1EA]">الصفحة غير موجودة</h1>
        <p className="text-sm text-[#CBD5E1] leading-relaxed">
          الرابط الذي تحاول الوصول إليه غير معرف أو تم نقله. يمكنك العودة إلى الصفحة الرئيسية أو استعراض الرحلات المتاحة.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
          <Link
            to={ROUTES.HOME}
            className="min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-[#C5A15B] text-[#0B172A] px-5 py-2.5 text-sm font-bold"
          >
            <Home className="w-4 h-4" />
            <span>الصفحة الرئيسية</span>
          </Link>
          <Link
            to={ROUTES.TRIPS}
            className="min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl border border-[#C5A15B]/40 text-[#F4F1EA] px-5 py-2.5 text-sm font-semibold hover:bg-white/5"
          >
            <Compass className="w-4 h-4 text-[#C5A15B]" />
            <span>تصفح الرحلات</span>
          </Link>
        </div>
      </div>
    </div>
  );
};
