import React, { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, SlidersHorizontal } from 'lucide-react';
import { TripCard } from '../components/TripCard';
import { CURATED_TRIPS } from '../data/curatedTrips';
import { useReferral } from '../context/ReferralContext';
import { fetchTrips } from '../services/firestoreService';
import { isPilgrimageCategory, type Trip } from '../types';

type FilterTab = 'all' | 'pilgrimage' | 'hajj' | 'umrah' | 'leisure';

const FILTER_TABS: { id: FilterTab; label: string }[] = [
  { id: 'all', label: 'جميع البرامج' },
  { id: 'pilgrimage', label: 'برامج الحج والعمرة' },
  { id: 'hajj', label: 'الحج' },
  { id: 'umrah', label: 'العمرة' },
  { id: 'leisure', label: 'الرحلات الترفيهية' },
];

function parseFilterTab(raw: string | null): FilterTab {
  if (raw === 'pilgrimage' || raw === 'hajj' || raw === 'umrah' || raw === 'leisure') {
    return raw;
  }
  return 'all';
}

export const TripsPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [trips, setTrips] = useState<Trip[]>(() => CURATED_TRIPS.filter((t) => t.active));
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<FilterTab>(() =>
    parseFilterTab(searchParams.get('category'))
  );
  const [sortBy, setSortBy] = useState<'featured' | 'price_asc' | 'price_desc'>('featured');
  const { activeReferral } = useReferral();

  useEffect(() => {
    setCategory(parseFilterTab(searchParams.get('category')));
  }, [searchParams]);

  useEffect(() => {
    fetchTrips()
      .then((data) => {
        const activeOnly = data.filter((t) => t.active);
        if (activeOnly.length > 0) setTrips(activeOnly);
      })
      .finally(() => setLoading(false));
  }, []);

  const handleCategoryChange = (next: FilterTab) => {
    setCategory(next);
    const nextParams = new URLSearchParams(searchParams);
    if (next === 'all') {
      nextParams.delete('category');
    } else {
      nextParams.set('category', next);
    }
    setSearchParams(nextParams, { replace: true });
  };

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const list = trips.filter((t) => {
      const matchesCat =
        category === 'all'
          ? true
          : category === 'pilgrimage'
          ? isPilgrimageCategory(t.category)
          : category === 'leisure'
          ? !isPilgrimageCategory(t.category)
          : t.category === category;
      const matchesQuery =
        !q ||
        t.title.toLowerCase().includes(q) ||
        t.destination.toLowerCase().includes(q) ||
        t.subtitle.toLowerCase().includes(q);
      return matchesCat && matchesQuery;
    });

    if (sortBy === 'price_asc') {
      return [...list].sort((a, b) => {
        const pa = typeof a.price === 'number' && a.price > 0 ? a.price : Number.MAX_SAFE_INTEGER;
        const pb = typeof b.price === 'number' && b.price > 0 ? b.price : Number.MAX_SAFE_INTEGER;
        return pa - pb;
      });
    }
    if (sortBy === 'price_desc') {
      return [...list].sort((a, b) => {
        const pa = typeof a.price === 'number' && a.price > 0 ? a.price : -1;
        const pb = typeof b.price === 'number' && b.price > 0 ? b.price : -1;
        return pb - pa;
      });
    }
    return list;
  }, [trips, search, category, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-[#F4F1EA]">
          {category === 'pilgrimage'
            ? 'برامج الحج والعمرة'
            : category === 'leisure'
            ? 'الرحلات الترفيهية'
            : 'برامج الحج والعمرة والرحلات'}
        </h1>
        <p className="text-sm text-[#9BA8BC] mt-1">
          استعرض باقات الحج والعمرة المتكاملة في مكة والمدينة، أو تصفح الرحلات الترفيهية الإضافية
        </p>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="rounded-2xl bg-[#12233B] border border-white/10 p-4 mb-8 flex flex-col lg:flex-row gap-4 lg:items-center lg:justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-[#9BA8BC] absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث باسم الباقة أو الوجهة (مثل مكة، المدينة، العلا)..."
            aria-label="البحث عن باقة أو رحلة"
            className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 pr-10 pl-4 py-2 text-sm text-[#F4F1EA] placeholder:text-[#9BA8BC] focus:border-[#C5A15B] focus:outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex flex-wrap items-center gap-1.5 bg-[#0B172A] p-1 rounded-xl border border-white/10">
            {FILTER_TABS.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => handleCategoryChange(cat.id)}
                className={`min-h-[38px] px-3.5 py-1.5 rounded-lg text-xs font-semibold transition whitespace-nowrap ${
                  category === cat.id
                    ? 'bg-[#C5A15B] text-[#0B172A]'
                    : 'text-[#CBD5E1] hover:text-white'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-[#C5A15B]" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
              aria-label="ترتيب الرحلات"
              className="min-h-[42px] rounded-xl bg-[#0B172A] border border-white/15 px-3 py-2 text-xs font-medium text-[#F4F1EA] focus:border-[#C5A15B] focus:outline-none"
            >
              <option value="featured">الترتيب الافتراضي</option>
              <option value="price_asc">السعر: من الأقل للأعلى</option>
              <option value="price_desc">السعر: من الأعلى للأقل</option>
            </select>
          </div>
        </div>
      </div>

      {loading && trips.length === 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((n) => (
            <div key={n} className="h-96 rounded-2xl bg-[#12233B] animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl bg-[#12233B] border border-white/10 p-12 text-center">
          <p className="text-base font-semibold text-[#F4F1EA] mb-2">لا توجد برامج مطابقة لبحثك</p>
          <p className="text-sm text-[#9BA8BC] mb-5">جرّب مسح الفلاتر أو البحث بكلمة أخرى.</p>
          <button
            type="button"
            onClick={() => {
              setSearch('');
              handleCategoryChange('all');
              setSortBy('featured');
            }}
            className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#C5A15B] text-[#0B172A] text-sm font-bold"
          >
            إعادة ضبط الفلاتر
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((trip) => (
            <TripCard
              key={trip.id}
              trip={trip}
              refCode={activeReferral?.code}
              compact={category === 'leisure'}
            />
          ))}
        </div>
      )}
    </div>
  );
};
