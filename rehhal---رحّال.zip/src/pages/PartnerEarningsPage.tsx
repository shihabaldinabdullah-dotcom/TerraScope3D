import React, { useEffect, useState } from 'react';
import { PartnerSubNav } from '../components/SubNav';
import { useAuth } from '../context/AuthContext';
import { fetchMarketerCommissions } from '../services/firestoreService';
import type { CommissionRecord } from '../types';
import { formatCustomerLedgerAmount } from '../utils/currency';

const COM_STATUS_AR: Record<CommissionRecord['status'], string> = {
  pending: 'معلقة حتى اكتمال الرحلة',
  eligible: 'مستحقة وجاهزة للسحب',
  paid: 'تم صرفها',
  cancelled: 'ملغاة',
};

export const PartnerEarningsPage: React.FC = () => {
  const { marketer } = useAuth();
  const [commissions, setCommissions] = useState<CommissionRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!marketer) return;
    fetchMarketerCommissions(marketer.uid)
      .then(setCommissions)
      .finally(() => setLoading(false));
  }, [marketer]);

  if (!marketer) return null;

  return (
    <div>
      <PartnerSubNav />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-[#F4F1EA]">سجل الأرباح والعمولات</h1>
          <p className="text-sm text-[#9BA8BC] mt-1">
            تتحول العمولة من «معلقة» إلى «مستحقة» فور تأكيد الدفع واكتمال الرحلة من الإدارة
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="rounded-2xl bg-[#12233B] border border-white/10 p-5">
            <div className="text-xs text-[#9BA8BC]">إجمالي الأرباح التراكمية</div>
            <div className="text-2xl font-bold text-[#F4F1EA] font-mono-num mt-1">
              {formatCustomerLedgerAmount(marketer.totalEarnings, marketer.currency).text}
            </div>
          </div>
          <div className="rounded-2xl bg-[#12233B] border border-white/10 p-5">
            <div className="text-xs text-[#9BA8BC]">الرصيد المتاح للسحب</div>
            <div className="text-2xl font-bold text-[#C5A15B] font-mono-num mt-1">
              {formatCustomerLedgerAmount(marketer.availableBalance, marketer.currency).text}
            </div>
          </div>
          <div className="rounded-2xl bg-[#12233B] border border-white/10 p-5">
            <div className="text-xs text-[#9BA8BC]">عدد العمولات المسجلة</div>
            <div className="text-2xl font-bold text-[#F4F1EA] font-mono-num mt-1">
              {commissions.length}
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-[#12233B] border border-white/10 overflow-x-auto">
          {loading ? (
            <div className="p-8 text-center text-sm text-[#9BA8BC]">جاري تحميل العمولات...</div>
          ) : commissions.length === 0 ? (
            <div className="p-8 text-center text-sm text-[#9BA8BC]">لا توجد عمولات مسجلة بعد.</div>
          ) : (
            <table className="w-full text-right text-sm">
              <thead className="border-b border-white/10 text-xs text-[#9BA8BC]">
                <tr>
                  <th className="px-4 py-3">رقم الحجز</th>
                  <th className="px-4 py-3">الرحلة</th>
                  <th className="px-4 py-3">قيمة الحجز</th>
                  <th className="px-4 py-3">العمولة</th>
                  <th className="px-4 py-3">الحالة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {commissions.map((c) => (
                  <tr key={c.id} className="hover:bg-white/5">
                    <td className="px-4 py-3 font-mono-num text-xs">{c.bookingId}</td>
                    <td className="px-4 py-3 font-medium">{c.tripTitle}</td>
                    <td className="px-4 py-3 font-mono-num">
                      {formatCustomerLedgerAmount(c.bookingAmount, c.currency).text}
                    </td>
                    <td className="px-4 py-3 font-mono-num font-bold text-[#C5A15B]">
                      {formatCustomerLedgerAmount(c.amount, c.currency).text}
                    </td>
                    <td className="px-4 py-3 text-xs">{COM_STATUS_AR[c.status]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
