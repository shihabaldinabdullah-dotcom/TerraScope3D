import React from 'react';
import { Link } from 'react-router-dom';
import { ROUTES } from '../routes/routeRegistry';

export const TermsPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10 sm:py-14 space-y-8">
      <div className="space-y-2">
        <p className="text-xs font-semibold text-[#C5A15B]">الضوابط التنظيمية</p>
        <h1 className="text-2xl sm:text-4xl font-bold text-[#F4F1EA]">الشروط والأحكام</h1>
        <p className="text-xs text-[#9BA8BC]">آخر تحديث: نوفمبر 2026</p>
      </div>

      <div className="rounded-2xl bg-[#12233B] border border-white/10 p-6 sm:p-8 space-y-6 text-sm text-[#CBD5E1] leading-relaxed">
        <section className="space-y-2">
          <h2 className="text-base font-bold text-[#F4F1EA]">1. نطاق الخدمة</h2>
          <p>
            تقدم منصة رحّال (REHHAL) خدمة استعراض وحجز برامج الحج والعمرة المعتمدة، إلى جانب باقات
            ترفيهية مختارة تخضع لتوافر المقاعد والضوابط النظامية.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-[#F4F1EA]">2. الحجز والسداد والإلغاء</h2>
          <p>
            يُعد الحجز مبدئياً إلى حين إتمام السداد وتوثيقه. يحق لصاحب الحجز إلغاء الطلبات المعلقة قبل
            السداد مباشرة من صفحة الحجز، بينما تخضع التعديلات بعد التأكيد لشروط كل برنامج.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-[#F4F1EA]">3. سياسة التقييمات</h2>
          <p>
            يُسمح بتقييم الرحلات حصراً للمشاركين الذين أتمّوا حجزهم وأصبح في حالة «مكتمل» لهذه الرحلة،
            بينما يتاح تقييم تجربة المنصة العامة داخل صفحة الملف الشخصي لصاحب الحساب.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-[#F4F1EA]">4. الدعم والاستفسارات</h2>
          <p>
            للاستفسار عن تفاصيل أي برنامج أو طلب مساعدة بخصوص حجوزاتك، تواصل معنا عبر{' '}
            <Link to={ROUTES.SUPPORT} className="text-[#C5A15B] hover:underline">
              صفحة التواصل الرسمية
            </Link>
            .
          </p>
        </section>
      </div>
    </div>
  );
};
