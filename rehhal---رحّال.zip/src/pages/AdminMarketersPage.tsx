import React, { useEffect, useState } from 'react';
import { AdminSubNav } from '../components/SubNav';
import { useToast } from '../context/ToastContext';
import { adminFetchAllMarketers, adminUpdateMarketerAccount } from '../services/firestoreService';
import type { MarketerProfile } from '../types';
import { formatAdminAmount } from '../utils/currency';

const STATUS_LABELS: Record<MarketerProfile['status'], string> = {
  active: 'نشط ومفعّل',
  pending: 'بانتظار الاعتماد',
  suspended: 'موقوف مؤقتاً',
};

export const AdminMarketersPage: React.FC = () => {
  const { showToast } = useToast();
  const [marketers, setMarketers] = useState<MarketerProfile[]>([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    adminFetchAllMarketers()
      .then(setMarketers)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const updateStatus = async (m: MarketerProfile, next: MarketerProfile['status']) => {
    try {
      await adminUpdateMarketerAccount(m.uid, next, m.commissionRate);
      showToast(`تم تحديث حالة المسوّق إلى: ${STATUS_LABELS[next]}`, 'success');
      load();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'تعذر التحديث', 'error');
    }
  };

  return (
    <div>
      <AdminSubNav />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-[#F4F1EA]">إدارة المسوّقين واعتماد الصلاحيات</h1>
          <p className="text-xs text-[#9BA8BC] mt-1">
            تظهر لوحة المسوّق وروابط المشاركة فقط بعد اعتماد الحساب هنا إلى حالة «نشط ومفعّل»
          </p>
        </div>

        <div className="rounded-2xl bg-[#12233B] border border-white/10 overflow-x-auto">
          {loading ? (
            <div className="p-8 text-center text-sm text-[#9BA8BC]">جاري التحميل...</div>
          ) : marketers.length === 0 ? (
            <div className="p-8 text-center text-sm text-[#9BA8BC]">لا يوجد مسوّقون أو طلبات انضمام بعد.</div>
          ) : (
            <table className="w-full text-right text-sm">
              <thead className="border-b border-white/10 text-xs text-[#9BA8BC]">
                <tr>
                  <th className="px-4 py-3">المسوّق</th>
                  <th className="px-4 py-3">كود الإحالة</th>
                  <th className="px-4 py-3">المدينة / الجوال</th>
                  <th className="px-4 py-3">الرصيد المتاح</th>
                  <th className="px-4 py-3">الحالة</th>
                  <th className="px-4 py-3">إجراء</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {marketers.map((m) => (
                  <tr key={m.uid} className="hover:bg-white/5">
                    <td className="px-4 py-3 font-medium">{m.fullName}</td>
                    <td className="px-4 py-3 font-mono-num text-[#C5A15B] font-bold">{m.referralCode}</td>
                    <td className="px-4 py-3 text-xs">
                      {m.city} · <span className="font-mono-num">{m.phone}</span>
                    </td>
                    <td className="px-4 py-3 font-mono-num">
                      {formatAdminAmount(m.availableBalance, m.currency || 'EGP').text}
                    </td>
                    <td className="px-4 py-3 text-xs">{STATUS_LABELS[m.status]}</td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-2">
                        {m.status !== 'active' && (
                          <button
                            type="button"
                            onClick={() => updateStatus(m, 'active')}
                            className="min-h-[36px] rounded-lg bg-[#C5A15B] px-3 py-1 text-xs font-bold text-[#0B172A] hover:opacity-90"
                          >
                            اعتماد وتفعيل
                          </button>
                        )}
                        {m.status === 'active' && (
                          <button
                            type="button"
                            onClick={() => updateStatus(m, 'suspended')}
                            className="min-h-[36px] rounded-lg border border-red-500/40 px-3 py-1 text-xs font-semibold text-red-300 hover:bg-red-500/10"
                          >
                            إيقاف مؤقت
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
