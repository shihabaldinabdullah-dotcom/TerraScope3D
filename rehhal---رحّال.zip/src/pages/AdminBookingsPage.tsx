import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { AdminSubNav } from '../components/SubNav';
import { useToast } from '../context/ToastContext';
import { ROUTES } from '../routes/routeRegistry';
import {
  adminFetchAllBookings,
  adminUpdateBookingLifecycle,
} from '../services/firestoreService';
import type { Booking } from '../types';
import { formatAdminAmount } from '../utils/currency';

export const AdminBookingsPage: React.FC = () => {
  const { showToast } = useToast();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);

  const loadBookings = () => {
    setLoading(true);
    adminFetchAllBookings()
      .then(setBookings)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadBookings();
  }, []);

  const handleLifecycleChange = async (
    booking: Booking,
    nextStatus: Booking['status'],
    nextPayment: Booking['paymentStatus']
  ) => {
    if (busyId) return;
    setBusyId(booking.id);
    try {
      await adminUpdateBookingLifecycle(booking, nextStatus, nextPayment);
      showToast('تم تحديث حالة الحجز والعمولة بنجاح', 'success');
      loadBookings();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'فشل تحديث الحجز', 'error');
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div>
      <AdminSubNav />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-[#F4F1EA]">إدارة الحجوزات</h1>
          <p className="text-sm text-[#9BA8BC] mt-1">
            تحويل الحجز إلى «مكتمل ومدفوع» يجعل عمولة المسوّق مستحقة للسحب تلقائياً
          </p>
        </div>

        <div className="rounded-2xl bg-[#12233B] border border-white/10 overflow-x-auto">
          {loading ? (
            <div className="p-8 text-center text-sm text-[#9BA8BC]">جاري تحميل الحجوزات...</div>
          ) : bookings.length === 0 ? (
            <div className="p-8 text-center text-sm text-[#9BA8BC]">لا توجد حجوزات مسجلة حالياً.</div>
          ) : (
            <table className="w-full text-right text-sm">
              <thead className="border-b border-white/10 text-xs text-[#9BA8BC]">
                <tr>
                  <th className="px-4 py-3">الحجز</th>
                  <th className="px-4 py-3">العميل</th>
                  <th className="px-4 py-3">الرحلة</th>
                  <th className="px-4 py-3">الإجمالي</th>
                  <th className="px-4 py-3">الإحالة</th>
                  <th className="px-4 py-3">الحالة</th>
                  <th className="px-4 py-3">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {bookings.map((b) => (
                  <tr key={b.id} className="hover:bg-white/5">
                    <td className="px-4 py-3 font-mono-num text-xs">
                      <Link to={ROUTES.bookingDetail(b.id)} className="text-[#C5A15B] hover:underline">
                        {b.id}
                      </Link>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-medium">{b.customerName}</div>
                      <div className="text-xs text-[#9BA8BC]">{b.customerEmail}</div>
                    </td>
                    <td className="px-4 py-3 text-xs">{b.tripTitle}</td>
                    <td className="px-4 py-3 font-mono-num font-semibold">
                      {formatAdminAmount(b.totalAmount, b.currency).text}
                    </td>
                    <td className="px-4 py-3 text-xs font-mono-num">
                      {b.referralCode
                        ? `${b.referralCode} (${formatAdminAmount(b.commissionAmount, b.currency).text})`
                        : 'مباشر'}
                    </td>
                    <td className="px-4 py-3 text-xs">
                      {b.status} / {b.paymentStatus}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1.5">
                        {b.status !== 'confirmed' && b.status !== 'completed' && (
                          <button
                            type="button"
                            disabled={busyId === b.id}
                            onClick={() => handleLifecycleChange(b, 'confirmed', 'paid')}
                            className="min-h-[34px] rounded-lg bg-emerald-600/20 border border-emerald-500/40 px-2.5 py-1 text-xs font-semibold text-emerald-200 hover:bg-emerald-600/35 disabled:opacity-50"
                          >
                            تأكيد الدفع
                          </button>
                        )}
                        {b.status !== 'completed' && b.status !== 'cancelled' && (
                          <button
                            type="button"
                            disabled={busyId === b.id}
                            onClick={() => handleLifecycleChange(b, 'completed', 'paid')}
                            className="min-h-[34px] rounded-lg bg-[#C5A15B]/20 border border-[#C5A15B]/50 px-2.5 py-1 text-xs font-semibold text-[#C5A15B] hover:bg-[#C5A15B]/30 disabled:opacity-50"
                          >
                            إكمال واستحقاق
                          </button>
                        )}
                        {b.status !== 'cancelled' && (
                          <button
                            type="button"
                            disabled={busyId === b.id}
                            onClick={() => handleLifecycleChange(b, 'cancelled', b.paymentStatus)}
                            className="min-h-[34px] rounded-lg border border-red-500/40 px-2.5 py-1 text-xs text-red-300 hover:bg-red-500/10 disabled:opacity-50"
                          >
                            إلغاء
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
