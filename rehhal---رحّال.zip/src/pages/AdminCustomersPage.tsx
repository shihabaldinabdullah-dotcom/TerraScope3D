import React, { useEffect, useState } from 'react';
import { AdminSubNav } from '../components/SubNav';
import { adminFetchAllUsers } from '../services/firestoreService';
import type { UserProfile } from '../types';

export const AdminCustomersPage: React.FC = () => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminFetchAllUsers()
      .then(setUsers)
      .finally(() => setLoading(false));
  }, []);

  const filtered = users.filter((u) => {
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return (
      u.displayName.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q) ||
      (u.phone || '').includes(q)
    );
  });

  return (
    <div>
      <AdminSubNav />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <h1 className="text-2xl font-bold text-[#F4F1EA]">سجل العملاء ({filtered.length})</h1>
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث بالاسم أو البريد أو الجوال..."
            className="min-h-[42px] w-full sm:w-72 rounded-xl bg-[#12233B] border border-white/15 px-3.5 text-sm text-[#F4F1EA]"
          />
        </div>

        <div className="rounded-2xl bg-[#12233B] border border-white/10 overflow-x-auto">
          {loading ? (
            <div className="p-8 text-center text-sm text-[#9BA8BC]">جاري تحميل بيانات العملاء...</div>
          ) : filtered.length === 0 ? (
            <div className="p-8 text-center text-sm text-[#9BA8BC]">لا توجد نتائج مطابقة.</div>
          ) : (
            <table className="w-full text-right text-sm">
              <thead className="border-b border-white/10 text-xs text-[#9BA8BC]">
                <tr>
                  <th className="px-4 py-3">الاسم</th>
                  <th className="px-4 py-3">البريد الإلكتروني</th>
                  <th className="px-4 py-3">الجوال</th>
                  <th className="px-4 py-3">المدينة</th>
                  <th className="px-4 py-3">الدور</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {filtered.map((u) => (
                  <tr key={u.uid} className="hover:bg-white/5">
                    <td className="px-4 py-3 font-medium">{u.displayName}</td>
                    <td className="px-4 py-3 text-xs text-[#CBD5E1]">{u.email}</td>
                    <td className="px-4 py-3 text-xs font-mono-num">{u.phone || '—'}</td>
                    <td className="px-4 py-3 text-xs">{u.city || '—'}</td>
                    <td className="px-4 py-3 text-xs text-[#C5A15B]">{u.role}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
