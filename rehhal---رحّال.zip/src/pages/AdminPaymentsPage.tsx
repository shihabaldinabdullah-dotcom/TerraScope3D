import React, { useEffect, useState } from 'react';
import { AdminSubNav } from '../components/SubNav';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { adminFetchAllPayouts, adminProcessPayoutRequest } from '../services/firestoreService';
import type { PayoutRequest } from '../types';
import { formatAdminAmount } from '../utils/currency';

export const AdminPaymentsPage: React.FC = () => {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [payouts, setPayouts] = useState<PayoutRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = () => {
    setLoading(true);
    adminFetchAllPayouts()
      .then(setPayouts)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const handleAction = async (
    payout: PayoutRequest,
    nextStatus: 'approved' | 'paid' | 'rejected'
  ) => {
    if (!user || busyId) return;
    setBusyId(payout.id);
    try {
      const note =
        nextStatus === 'paid'
          ? 'تم تنفيذ الحوالة البنكية بنجاح'
          : nextStatus === 'approved'
          ? 'تمت الموافقة وجارٍ التحويل'
          : 'مرفوض لعدم اكتمال بيانات الحساب';
      await adminProcessPayoutRequest({
        payout,
        nextStatus,
        adminNote: note,
        adminUid: user.uid,
      });
      showToast('تمت معالجة طلب السحب بنجاح', 'success');
      load();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'فشل تنفيذ الإجراء', 'error');
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div>
      <AdminSubNav />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <h1 className="text-2xl font-bold text-[#F4F1EA]">إدارة المدفوعات وطلبات السحب</h1>

        <div className="rounded-2xl bg-[#12233B] border border-white/10 overflow-x-auto">
          {loading ? (
            <div className="p-8 text-center text-sm text-[#9BA8BC]">جاري التحميل...</div>
          ) : payouts.length === 0 ? (
            <div className="p-8 text-center text-sm text-[#9BA8BC]">لا توجد طلبات سحب مسجلة.</div>
          ) : (
            <table className="w-full text-right text-sm">
              <thead className="border-b border-white/10 text-xs text-[#9BA8BC]">
                <tr>
                  <th className="px-4 py-3">الشريك</th>
                  <th className="px-4 py-3">المبلغ</th>
                  <th className="px-4 py-3">البنك / الآيبان</th>
                  <th className="px-4 py-3">الحالة</th>
                  <th className="px-4 py-3">المعالجة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {payouts.map((p) => (
                  <tr key={p.id} className="hover:bg-white/5">
                    <td className="px-4 py-3 font-medium">{p.marketerName}</td>
                    <td className="px-4 py-3 font-mono-num font-bold text-[#C5A15B]">
                      {formatAdminAmount(p.amount, p.currency).text}
                    </td>
                    <td className="px-4 py-3 text-xs">
                      <div>{p.bankName}</div>
                      <div className="font-mono-num text-[#9BA8BC]" dir="ltr">{p.iban}</div>
                    </td>
                    <td className="px-4 py-3 text-xs">{p.status}</td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1.5">
                        {p.status === 'pending' && (
                          <button
                            type="button"
                            disabled={busyId === p.id}
                            onClick={() => handleAction(p, 'approved')}
                            className="min-h-[34px] rounded-lg border border-[#C5A15B]/50 px-2.5 py-1 text-xs font-semibold text-[#C5A15B] hover:bg-[#C5A15B]/10"
                          >
                            اعتماد
                          </button>
                        )}
                        {(p.status === 'pending' || p.status === 'approved') && (
                          <button
                            type="button"
                            disabled={busyId === p.id}
                            onClick={() => handleAction(p, 'paid')}
                            className="min-h-[34px] rounded-lg bg-emerald-600/20 border border-emerald-500/40 px-2.5 py-1 text-xs font-semibold text-emerald-200 hover:bg-emerald-600/35"
                          >
                            تأكيد التحويل
                          </button>
                        )}
                        {p.status === 'pending' && (
                          <button
                            type="button"
                            disabled={busyId === p.id}
                            onClick={() => handleAction(p, 'rejected')}
                            className="min-h-[34px] rounded-lg border border-red-500/40 px-2.5 py-1 text-xs text-red-300 hover:bg-red-500/10"
                          >
                            رفض
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
