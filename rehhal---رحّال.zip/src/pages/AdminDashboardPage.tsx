import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, CalendarCheck, Compass, Users, Wallet } from 'lucide-react';
import { AdminSubNav } from '../components/SubNav';
import { ROUTES } from '../routes/routeRegistry';
import {
  adminFetchAllBookings,
  adminFetchAllMarketers,
  adminFetchAllPayouts,
  adminFetchContactRequests,
  fetchTrips,
} from '../services/firestoreService';

import { formatEgpAmount, isApprovedEgpCurrency } from '../utils/currency';

export const AdminDashboardPage: React.FC = () => {
  const [counts, setCounts] = useState({
    trips: 0,
    bookings: 0,
    revenueEgp: 0,
    legacyNonEgpBookings: 0,
    marketers: 0,
    pendingPayouts: 0,
    newContacts: 0,
  });

  useEffect(() => {
    Promise.all([
      fetchTrips(),
      adminFetchAllBookings(),
      adminFetchAllMarketers(),
      adminFetchAllPayouts(),
      adminFetchContactRequests(),
    ])
      .then(([trips, bookings, marketers, payouts, contacts]) => {
        const paidBookings = bookings.filter((b) => b.paymentStatus === 'paid');
        const revenueEgp = paidBookings
          .filter((b) => isApprovedEgpCurrency(b.currency))
          .reduce((sum, b) => sum + b.totalAmount, 0);
        const legacyNonEgpBookings = bookings.filter((b) => !isApprovedEgpCurrency(b.currency)).length;
        const pendingPayouts = payouts.filter((p) => p.status === 'pending').length;
        const newContacts = contacts.filter((c) => c.status === 'new').length;
        setCounts({
          trips: trips.length,
          bookings: bookings.length,
          revenueEgp,
          legacyNonEgpBookings,
          marketers: marketers.length,
          pendingPayouts,
          newContacts,
        });
      })
      .catch(() => undefined);
  }, []);

  return (
    <div>
      <AdminSubNav />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-[#F4F1EA]">لوحة تحكم الإدارة</h1>
          <p className="text-sm text-[#9BA8BC] mt-1">
            متابعة شاملة للرحلات والحجوزات والشركاء وطلبات السحب بالعملة المعتمدة (ج.م)
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="rounded-2xl bg-[#12233B] border border-white/10 p-5">
            <div className="flex items-center justify-between text-xs text-[#9BA8BC] mb-2">
              <span>إجمالي الرحلات</span>
              <Compass className="w-4 h-4 text-[#C5A15B]" />
            </div>
            <div className="text-2xl font-bold font-mono-num">{counts.trips}</div>
          </div>

          <div className="rounded-2xl bg-[#12233B] border border-white/10 p-5">
            <div className="flex items-center justify-between text-xs text-[#9BA8BC] mb-2">
              <span>إجمالي الحجوزات</span>
              <CalendarCheck className="w-4 h-4 text-[#C5A15B]" />
            </div>
            <div className="text-2xl font-bold font-mono-num">{counts.bookings}</div>
          </div>

          <div className="rounded-2xl bg-[#12233B] border border-white/10 p-5">
            <div className="flex items-center justify-between text-xs text-[#9BA8BC] mb-2">
              <span>المسوّقون النشطون</span>
              <Users className="w-4 h-4 text-[#C5A15B]" />
            </div>
            <div className="text-2xl font-bold font-mono-num">{counts.marketers}</div>
          </div>

          <div className="rounded-2xl bg-[#12233B] border border-white/10 p-5">
            <div className="flex items-center justify-between text-xs text-[#9BA8BC] mb-2">
              <span>الإيرادات المحصلة (ج.م)</span>
              <Wallet className="w-4 h-4 text-[#C5A15B]" />
            </div>
            <div className="text-2xl font-bold text-[#C5A15B] font-mono-num">
              {formatEgpAmount(counts.revenueEgp)}
            </div>
            {counts.legacyNonEgpBookings > 0 && (
              <p className="text-[11px] text-amber-300 mt-1">
                يوجد {counts.legacyNonEgpBookings} حجز بعملة سابقة بانتظار المراجعة
              </p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Link
            to={ROUTES.ADMIN_BOOKINGS}
            className="rounded-2xl bg-[#12233B] border border-white/10 hover:border-[#C5A15B]/50 p-6 flex items-center justify-between transition"
          >
            <div>
              <h2 className="text-lg font-bold text-[#F4F1EA]">إدارة الحجوزات والعمولات</h2>
              <p className="text-xs text-[#9BA8BC] mt-1">تأكيد الدفع وإتمام الرحلات لتحرير عمولات الشركاء</p>
            </div>
            <ArrowLeft className="w-5 h-5 text-[#C5A15B]" />
          </Link>

          <Link
            to={ROUTES.ADMIN_PAYMENTS}
            className="rounded-2xl bg-[#12233B] border border-white/10 hover:border-[#C5A15B]/50 p-6 flex items-center justify-between transition"
          >
            <div>
              <h2 className="text-lg font-bold text-[#F4F1EA]">
                مراجعة طلبات السحب ({counts.pendingPayouts} معلقة)
              </h2>
              <p className="text-xs text-[#9BA8BC] mt-1">اعتماد وتنفيذ طلبات تحويل أرباح المسوّقين</p>
            </div>
            <ArrowLeft className="w-5 h-5 text-[#C5A15B]" />
          </Link>

          <Link
            to={ROUTES.ADMIN_REVIEWS}
            className="rounded-2xl bg-[#12233B] border border-white/10 hover:border-[#C5A15B]/50 p-6 flex items-center justify-between transition"
          >
            <div>
              <h2 className="text-lg font-bold text-[#F4F1EA]">تقييمات المنصة والرحلات</h2>
              <p className="text-xs text-[#9BA8BC] mt-1">مراجعة تقييمات العملاء للمنصة والرحلات المكتملة</p>
            </div>
            <ArrowLeft className="w-5 h-5 text-[#C5A15B]" />
          </Link>

          <Link
            to={ROUTES.ADMIN_CONTACTS}
            className="rounded-2xl bg-[#12233B] border border-white/10 hover:border-[#C5A15B]/50 p-6 flex items-center justify-between transition"
          >
            <div>
              <h2 className="text-lg font-bold text-[#F4F1EA]">
                طلبات التواصل ({counts.newContacts} جديدة)
              </h2>
              <p className="text-xs text-[#9BA8BC] mt-1">متابعة طلبات التواصل عبر واتساب والاتصال الهاتفي</p>
            </div>
            <ArrowLeft className="w-5 h-5 text-[#C5A15B]" />
          </Link>
        </div>
      </div>
    </div>
  );
};
