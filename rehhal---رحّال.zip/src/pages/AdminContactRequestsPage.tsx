import React, { useEffect, useMemo, useState } from 'react';
import {
  CheckCircle2,
  Clock,
  ExternalLink,
  MessageCircle,
  Phone,
  Save,
  Trash2,
} from 'lucide-react';
import { AdminSubNav } from '../components/SubNav';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import {
  adminDeleteContactRequest,
  adminFetchContactRequests,
  adminUpdateContactRequest,
} from '../services/firestoreService';
import type { ContactRequest, ContactRequestStatus } from '../types';

const STATUS_LABELS: Record<ContactRequestStatus, string> = {
  new: 'جديد',
  in_progress: 'جارٍ التواصل',
  contacted: 'تم التواصل',
  completed: 'مكتمل',
};

const STATUS_STYLES: Record<ContactRequestStatus, string> = {
  new: 'bg-amber-500/15 text-amber-300 border-amber-500/40',
  in_progress: 'bg-sky-500/15 text-sky-300 border-sky-500/40',
  contacted: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40',
  completed: 'bg-white/10 text-[#CBD5E1] border-white/20',
};

function formatRequestDate(ts: unknown): string {
  if (!ts) return '—';
  try {
    let date: Date | null = null;
    if (ts instanceof Date) {
      date = ts;
    } else if (typeof ts === 'object' && ts !== null && 'toDate' in ts && typeof (ts as { toDate: () => Date }).toDate === 'function') {
      date = (ts as { toDate: () => Date }).toDate();
    } else if (typeof ts === 'object' && ts !== null && 'seconds' in ts && typeof (ts as { seconds: number }).seconds === 'number') {
      date = new Date((ts as { seconds: number }).seconds * 1000);
    }
    if (!date || Number.isNaN(date.getTime())) return '—';
    return new Intl.DateTimeFormat('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  } catch {
    return '—';
  }
}

function normalizeCustomerWhatsapp(phone: string): string | null {
  const digits = phone.replace(/[^\d]/g, '');
  if (digits.length < 8) return null;
  if (digits.startsWith('05') && digits.length === 10) {
    return `966${digits.slice(1)}`;
  }
  return digits;
}

export const AdminContactRequestsPage: React.FC = () => {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [requests, setRequests] = useState<ContactRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | ContactRequestStatus>('all');
  const [statusEdits, setStatusEdits] = useState<Record<string, ContactRequestStatus>>({});
  const [noteEdits, setNoteEdits] = useState<Record<string, string>>({});
  const [savingId, setSavingId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const loadRequests = async () => {
    setLoading(true);
    try {
      const data = await adminFetchContactRequests();
      setRequests(data);
      const nextStatuses: Record<string, ContactRequestStatus> = {};
      const nextNotes: Record<string, string> = {};
      for (const r of data) {
        nextStatuses[r.id] = r.status;
        nextNotes[r.id] = r.adminNote || '';
      }
      setStatusEdits(nextStatuses);
      setNoteEdits(nextNotes);
    } catch {
      showToast('تعذر تحميل طلبات التواصل', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRequests();
  }, []);

  const filteredRequests = useMemo(() => {
    if (filter === 'all') return requests;
    return requests.filter((r) => r.status === filter);
  }, [requests, filter]);

  const counts = useMemo(() => {
    return {
      all: requests.length,
      new: requests.filter((r) => r.status === 'new').length,
      in_progress: requests.filter((r) => r.status === 'in_progress').length,
      contacted: requests.filter((r) => r.status === 'contacted').length,
      completed: requests.filter((r) => r.status === 'completed').length,
    };
  }, [requests]);

  const handleSave = async (req: ContactRequest) => {
    setSavingId(req.id);
    try {
      const nextStatus = statusEdits[req.id] || req.status;
      const nextNote = noteEdits[req.id] ?? '';
      await adminUpdateContactRequest({
        requestId: req.id,
        status: nextStatus,
        adminNote: nextNote,
        adminUid: user?.uid || 'admin',
      });
      setRequests((prev) =>
        prev.map((item) =>
          item.id === req.id
            ? { ...item, status: nextStatus, adminNote: nextNote }
            : item
        )
      );
      showToast('تم تحديث حالة طلب التواصل بنجاح', 'success');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'تعذر تحديث الطلب', 'error');
    } finally {
      setSavingId(null);
    }
  };

  const handleDelete = async (id: string) => {
    setSavingId(id);
    try {
      await adminDeleteContactRequest(id);
      setRequests((prev) => prev.filter((item) => item.id !== id));
      setConfirmDeleteId(null);
      showToast('تم حذف طلب التواصل', 'info');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'تعذر حذف الطلب', 'error');
    } finally {
      setSavingId(null);
    }
  };

  return (
    <div>
      <AdminSubNav />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-[#F4F1EA]">طلبات التواصل</h1>
            <p className="text-sm text-[#9BA8BC] mt-1">
              متابعة طلبات التواصل الواردة عبر واتساب والاتصال الهاتفي وتحديث حالتها
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {(
              [
                { key: 'all', label: `الكل (${counts.all})` },
                { key: 'new', label: `جديد (${counts.new})` },
                { key: 'in_progress', label: `جارٍ التواصل (${counts.in_progress})` },
                { key: 'contacted', label: `تم التواصل (${counts.contacted})` },
                { key: 'completed', label: `مكتمل (${counts.completed})` },
              ] as const
            ).map((tab) => (
              <button
                key={tab.key}
                type="button"
                onClick={() => setFilter(tab.key)}
                className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold transition ${
                  filter === tab.key
                    ? 'bg-[#C5A15B] text-[#0B172A]'
                    : 'bg-[#12233B] text-[#CBD5E1] border border-white/10 hover:border-[#C5A15B]/40'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="rounded-2xl bg-[#12233B] border border-white/10 p-10 text-center text-sm text-[#9BA8BC]">
            جاري تحميل طلبات التواصل...
          </div>
        ) : filteredRequests.length === 0 ? (
          <div className="rounded-2xl bg-[#12233B] border border-white/10 p-10 text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-[#C5A15B] mx-auto" />
            <p className="text-sm text-[#CBD5E1]">لا توجد طلبات تواصل ضمن هذا التصنيف حالياً.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredRequests.map((req) => {
              const customerWa = normalizeCustomerWhatsapp(req.phone);
              const cleanTel = req.phone.replace(/[^\d+]/g, '');
              return (
                <article
                  key={req.id}
                  className="rounded-2xl bg-[#12233B] border border-white/10 p-5 sm:p-6 space-y-4"
                >
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div className="space-y-1.5">
                      <div className="flex flex-wrap items-center gap-2.5">
                        <h2 className="text-lg font-bold text-[#F4F1EA]">{req.name}</h2>
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-lg border text-[11px] font-semibold ${
                            STATUS_STYLES[req.status]
                          }`}
                        >
                          {STATUS_LABELS[req.status]}
                        </span>
                        <span className="inline-flex items-center gap-1 rounded-lg bg-[#0B172A] border border-white/10 px-2.5 py-0.5 text-[11px] text-[#CBD5E1]">
                          {req.preferredMethod === 'whatsapp' ? (
                            <>
                              <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                              <span>واتساب</span>
                            </>
                          ) : (
                            <>
                              <Phone className="w-3.5 h-3.5 text-[#C5A15B]" />
                              <span>اتصال هاتفي</span>
                            </>
                          )}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-4 text-xs text-[#9BA8BC]">
                        <span className="font-mono-num text-[#F4F1EA]" dir="ltr">
                          {req.phone}
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-[#C5A15B]" />
                          <span>{formatRequestDate(req.createdAt)}</span>
                        </span>
                        {req.officialWhatsapp && (
                          <span>
                            رقم المنصة:{' '}
                            <span className="font-mono-num text-[#CBD5E1]" dir="ltr">
                              {req.officialWhatsapp}
                            </span>
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      {customerWa && (
                        <a
                          href={`https://wa.me/${customerWa}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl bg-emerald-600/20 border border-emerald-500/40 px-3.5 py-1.5 text-xs font-semibold text-emerald-200 hover:bg-emerald-600/30 transition"
                        >
                          <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                          <span>بدء واتساب مع العميل</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                      {cleanTel && (
                        <a
                          href={`tel:${cleanTel}`}
                          className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl border border-white/15 bg-[#0B172A] px-3.5 py-1.5 text-xs font-semibold text-[#F4F1EA] hover:border-[#C5A15B] transition"
                        >
                          <Phone className="w-3.5 h-3.5 text-[#C5A15B]" />
                          <span>اتصال بالعميل</span>
                        </a>
                      )}
                    </div>
                  </div>

                  {req.message && (
                    <div className="rounded-xl bg-[#0B172A] border border-white/10 p-3.5 text-sm text-[#CBD5E1] leading-relaxed">
                      {req.message}
                    </div>
                  )}

                  <div className="pt-2 border-t border-white/10 grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
                    <div className="md:col-span-3">
                      <label
                        htmlFor={`crq-status-${req.id}`}
                        className="block text-[11px] text-[#9BA8BC] mb-1"
                      >
                        حالة الطلب
                      </label>
                      <select
                        id={`crq-status-${req.id}`}
                        value={statusEdits[req.id] || req.status}
                        onChange={(e) =>
                          setStatusEdits((prev) => ({
                            ...prev,
                            [req.id]: e.target.value as ContactRequestStatus,
                          }))
                        }
                        className="w-full min-h-[40px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-xs text-[#F4F1EA]"
                      >
                        <option value="new">جديد</option>
                        <option value="in_progress">جارٍ التواصل</option>
                        <option value="contacted">تم التواصل</option>
                        <option value="completed">مكتمل</option>
                      </select>
                    </div>

                    <div className="md:col-span-6">
                      <label
                        htmlFor={`crq-note-${req.id}`}
                        className="block text-[11px] text-[#9BA8BC] mb-1"
                      >
                        ملاحظات الإدارة
                      </label>
                      <input
                        id={`crq-note-${req.id}`}
                        type="text"
                        maxLength={500}
                        value={noteEdits[req.id] ?? ''}
                        onChange={(e) =>
                          setNoteEdits((prev) => ({ ...prev, [req.id]: e.target.value }))
                        }
                        placeholder="أضف ملاحظة متابعة..."
                        className="w-full min-h-[40px] rounded-xl bg-[#0B172A] border border-white/15 px-3 text-xs text-[#F4F1EA]"
                      />
                    </div>

                    <div className="md:col-span-3 flex items-center justify-end gap-2">
                      <button
                        type="button"
                        disabled={savingId === req.id}
                        onClick={() => handleSave(req)}
                        className="min-h-[40px] inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#C5A15B] text-[#0B172A] px-4 py-2 text-xs font-bold hover:opacity-90 disabled:opacity-50 transition"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span>{savingId === req.id ? 'جاري الحفظ...' : 'حفظ التحديث'}</span>
                      </button>

                      {confirmDeleteId === req.id ? (
                        <button
                          type="button"
                          disabled={savingId === req.id}
                          onClick={() => handleDelete(req.id)}
                          className="min-h-[40px] inline-flex items-center gap-1 rounded-xl bg-red-600/80 text-white px-3 py-2 text-xs font-bold hover:bg-red-600 transition"
                        >
                          تأكيد الحذف
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(req.id)}
                          aria-label="حذف طلب التواصل"
                          className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-xl border border-red-500/30 bg-red-500/10 text-red-300 hover:bg-red-500/20 transition"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
