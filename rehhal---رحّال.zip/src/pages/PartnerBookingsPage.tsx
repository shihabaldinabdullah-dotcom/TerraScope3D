import React, { useEffect, useState } from 'react';
import { PartnerSubNav } from '../components/SubNav';
import { useAuth } from '../context/AuthContext';
import { fetchMarketerReferredBookings } from '../services/firestoreService';
import type { Booking } from '../types';
import { formatCustomerLedgerAmount } from '../utils/currency';

export const PartnerBookingsPage: React.FC = () => {
  const { marketer } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!marketer) return;
    fetchMarketerReferredBookings(marketer.uid)
      .then(setBookings)
      .finally(() => setLoading(false));
  }, [marketer]);

  if (!marketer) return null;

  return (
    <div>
      <PartnerSubNav />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-[#F4F1EA]">الحجوزات المحالة عبر روابطك</h1>
          <p className="text-sm text-[#9BA8BC] mt-1">
            يتم عرض تفاصيل الحجز والعمولة دون كشف بيانات الاتصال الحساسة للعميل
          </p>
        </div>

        <div className="rounded-2xl bg-[#12233B] border border-white/10 overflow-x-auto">
          {loading ? (
            <div className="p-8 text-center text-sm text-[#9BA8BC]">جاري التحميل...</div>
          ) : bookings.length === 0 ? (
            <div className="p-8 text-center text-sm text-[#9BA8BC]">لم تُسجل حجوزات محالة بعد.</div>
          ) : (
            <table className="w-full text-right text-sm">
              <thead className="border-b border-white/10 text-xs text-[#9BA8BC]">
                <tr>
                  <th className="px-4 py-3">رقم الحجز</th>
                  <th className="px-4 py-3">الرحلة</th>
                  <th className="px-4 py-3">تاريخ الانطلاق</th>
                  <th className="px-4 py-3">الضيوف</th>
                  <th className="px-4 py-3">الإجمالي</th>
                  <th className="px-4 py-3">العمولة</th>
                  <th className="px-4 py-3">الحالة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {bookings.map((b) => (
                  <tr key={b.id} className="hover:bg-white/5">
                    <td className="px-4 py-3 font-mono-num text-xs">{b.id}</td>
                    <td className="px-4 py-3 font-medium">{b.tripTitle}</td>
                    <td className="px-4 py-3 font-mono-num text-xs">{b.travelDate}</td>
                    <td className="px-4 py-3 font-mono-num">{b.guests}</td>
                    <td className="px-4 py-3 font-mono-num">
                      {formatCustomerLedgerAmount(b.totalAmount, b.currency).text}
                    </td>
                    <td className="px-4 py-3 font-mono-num text-[#C5A15B] font-bold">
                      {formatCustomerLedgerAmount(b.commissionAmount, b.currency).text}
                    </td>
                    <td className="px-4 py-3 text-xs">{b.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
