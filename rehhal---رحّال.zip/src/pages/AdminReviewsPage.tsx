import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Star, Trash2 } from 'lucide-react';
import { AdminSubNav } from '../components/SubNav';
import { useToast } from '../context/ToastContext';
import {
  adminDeletePlatformReview,
  adminDeleteTripReview,
  adminFetchAllPlatformReviews,
  adminFetchAllTripReviews,
} from '../services/firestoreService';
import type { PlatformReview, TripReview } from '../types';

export const AdminReviewsPage: React.FC = () => {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<'platform' | 'trips'>('platform');
  const [platformReviews, setPlatformReviews] = useState<PlatformReview[]>([]);
  const [tripReviews, setTripReviews] = useState<TripReview[]>([]);
  const [loading, setLoading] = useState(true);

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [pRevs, tRevs] = await Promise.all([
        adminFetchAllPlatformReviews(),
        adminFetchAllTripReviews(),
      ]);
      setPlatformReviews(pRevs);
      setTripReviews(tRevs);
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'تعذر تحميل التقييمات', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  const platformAvg = useMemo(() => {
    if (platformReviews.length === 0) return '—';
    const sum = platformReviews.reduce((acc, r) => acc + r.rating, 0);
    return (sum / platformReviews.length).toFixed(1);
  }, [platformReviews]);

  const tripAvg = useMemo(() => {
    if (tripReviews.length === 0) return '—';
    const sum = tripReviews.reduce((acc, r) => acc + r.rating, 0);
    return (sum / tripReviews.length).toFixed(1);
  }, [tripReviews]);

  const handleDeletePlatformReview = async (userId: string) => {
    try {
      await adminDeletePlatformReview(userId);
      setPlatformReviews((prev) => prev.filter((r) => r.id !== userId));
      showToast('تم حذف تقييم المنصة', 'info');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'تعذر الحذف', 'error');
    }
  };

  const handleDeleteTripReview = async (reviewId: string) => {
    try {
      await adminDeleteTripReview(reviewId);
      setTripReviews((prev) => prev.filter((r) => r.id !== reviewId));
      showToast('تم حذف تقييم الرحلة', 'info');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'تعذر الحذف', 'error');
    }
  };

  return (
    <div>
      <AdminSubNav />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-[#F4F1EA]">إدارة ومراجعة التقييمات</h1>
            <p className="text-xs sm:text-sm text-[#9BA8BC] mt-1">
              فصل كامل بين تقييمات استخدام منصة رحّال وتقييمات الرحلات المكتملة
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-[#12233B] border border-white/10 px-4 py-2 text-xs">
              <span className="text-[#9BA8BC] block">متوسط المنصة</span>
              <span className="text-base font-bold text-[#C5A15B] font-mono-num">
                {platformAvg} ({platformReviews.length})
              </span>
            </div>
            <div className="rounded-xl bg-[#12233B] border border-white/10 px-4 py-2 text-xs">
              <span className="text-[#9BA8BC] block">متوسط الرحلات</span>
              <span className="text-base font-bold text-[#C5A15B] font-mono-num">
                {tripAvg} ({tripReviews.length})
              </span>
            </div>
          </div>
        </div>

        {/* Separated Tabs */}
        <div className="flex items-center gap-2 border-b border-white/10 pb-3">
          <button
            type="button"
            onClick={() => setActiveTab('platform')}
            className={`min-h-[42px] px-4 py-2 rounded-xl text-sm font-semibold transition ${
              activeTab === 'platform'
                ? 'bg-[#C5A15B] text-[#0B172A]'
                : 'text-[#CBD5E1] hover:bg-white/5'
            }`}
          >
            تقييمات منصة رحّال ({platformReviews.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('trips')}
            className={`min-h-[42px] px-4 py-2 rounded-xl text-sm font-semibold transition ${
              activeTab === 'trips'
                ? 'bg-[#C5A15B] text-[#0B172A]'
                : 'text-[#CBD5E1] hover:bg-white/5'
            }`}
          >
            تقييمات الرحلات ({tripReviews.length})
          </button>
        </div>

        {loading ? (
          <div className="h-40 rounded-2xl bg-[#12233B] animate-pulse" />
        ) : activeTab === 'platform' ? (
          platformReviews.length === 0 ? (
            <div className="rounded-2xl bg-[#12233B] border border-white/10 p-10 text-center text-sm text-[#9BA8BC]">
              لا توجد تقييمات عامة للمنصة بعد.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {platformReviews.map((rev) => (
                <div
                  key={rev.id}
                  className="rounded-2xl bg-[#12233B] border border-white/10 p-5 space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-sm font-bold text-[#F4F1EA]">{rev.userName}</div>
                      <div className="text-[11px] text-[#9BA8BC] font-mono-num">
                        UID: {rev.userId}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="inline-flex items-center gap-1 text-xs font-bold text-[#C5A15B] font-mono-num">
                        <Star className="w-3.5 h-3.5 fill-[#C5A15B]" />
                        {rev.rating} / 5
                      </span>
                      <button
                        type="button"
                        onClick={() => handleDeletePlatformReview(rev.id)}
                        aria-label={`حذف تقييم ${rev.userName}`}
                        className="min-h-[34px] min-w-[34px] inline-flex items-center justify-center rounded-lg border border-red-500/35 text-red-300 hover:bg-red-500/10"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  {rev.comment && (
                    <p className="text-xs sm:text-sm text-[#CBD5E1] leading-relaxed">
                      {rev.comment}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )
        ) : tripReviews.length === 0 ? (
          <div className="rounded-2xl bg-[#12233B] border border-white/10 p-10 text-center text-sm text-[#9BA8BC]">
            لا توجد تقييمات للرحلات من الحجوزات المكتملة بعد.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {tripReviews.map((rev) => (
              <div
                key={rev.id}
                className="rounded-2xl bg-[#12233B] border border-white/10 p-5 space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-sm font-bold text-[#F4F1EA]">{rev.userName}</div>
                    <div className="text-[11px] text-[#C5A15B] font-mono-num">
                      الرحلة: {rev.tripId} · الحجز: {rev.bookingId}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center gap-1 text-xs font-bold text-[#C5A15B] font-mono-num">
                      <Star className="w-3.5 h-3.5 fill-[#C5A15B]" />
                      {rev.rating} / 5
                    </span>
                    <button
                      type="button"
                      onClick={() => handleDeleteTripReview(rev.id)}
                      aria-label={`حذف تقييم الرحلة ${rev.id}`}
                      className="min-h-[34px] min-w-[34px] inline-flex items-center justify-center rounded-lg border border-red-500/35 text-red-300 hover:bg-red-500/10"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                {rev.comment && (
                  <p className="text-xs sm:text-sm text-[#CBD5E1] leading-relaxed">
                    {rev.comment}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
