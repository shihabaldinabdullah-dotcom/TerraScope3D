export type UserRole = 'customer' | 'marketer' | 'admin';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  phone?: string;
  city?: string;
  role: UserRole;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export type TripCategory = 'hajj' | 'umrah' | 'desert' | 'coastal' | 'mountain' | 'heritage';

export type ProgramTier = 'hajj' | 'umrah' | 'umrah_vip' | 'leisure';

export const TRIP_CATEGORY_LABELS: Record<TripCategory, string> = {
  hajj: 'الحج',
  umrah: 'العمرة',
  desert: 'ترفيهية · صحراوية',
  coastal: 'ترفيهية · بحرية',
  mountain: 'ترفيهية · جبلية',
  heritage: 'ترفيهية · تراثية',
};

export function isPilgrimageCategory(category: TripCategory): boolean {
  return category === 'hajj' || category === 'umrah';
}

export interface Trip {
  id: string;
  title: string;
  subtitle: string;
  destination: string;
  category: TripCategory;
  durationDays: number | null;
  price: number | null;
  currency?: string;
  maxGuests: number;
  rating?: number;
  reviewsCount?: number;
  imageUrl: string;
  description: string;
  highlights: string[];
  services?: string[];
  terms?: string;
  departureDates: string[];
  active: boolean;
  featured: boolean;
  sliderVisible?: boolean;
  sliderOrder?: number;
  displayOrder?: number;
  programTier?: ProgramTier;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export type BookingStatus = 'pending_payment' | 'confirmed' | 'completed' | 'cancelled';
export type PaymentStatus = 'unpaid' | 'paid' | 'refunded';
export type CommissionStatus = 'none' | 'pending' | 'eligible' | 'paid';

export interface Booking {
  id: string;
  userId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  tripId: string;
  tripTitle: string;
  travelDate: string;
  guests: number;
  unitPrice: number;
  totalAmount: number;
  currency?: string;
  notes?: string;
  status: BookingStatus;
  paymentStatus: PaymentStatus;
  paymentMethod?: string;
  paymentRef?: string;
  referralCode: string | null;
  marketerId: string | null;
  referralSignature?: string | null;
  commissionAmount: number;
  commissionStatus: CommissionStatus;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface MarketerProfile {
  uid: string;
  fullName: string;
  phone: string;
  city: string;
  channel?: string;
  referralCode: string;
  commissionRate: number;
  status: 'active' | 'pending' | 'suspended';
  totalEarnings: number;
  availableBalance: number;
  pendingBalance: number;
  currency?: string;
  clicksCount?: number;
  conversionsCount?: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface CommissionRecord {
  id: string;
  marketerId: string;
  bookingId: string;
  tripId: string;
  tripTitle: string;
  referralCode: string;
  bookingAmount: number;
  commissionRate: number;
  amount: number;
  currency?: string;
  status: 'pending' | 'eligible' | 'paid' | 'cancelled';
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface PayoutRequest {
  id: string;
  marketerId: string;
  marketerName: string;
  amount: number;
  currency?: string;
  iban: string;
  bankName: string;
  accountHolder: string;
  status: 'pending' | 'approved' | 'paid' | 'rejected';
  adminNote?: string;
  processedBy?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface SupportTicket {
  id: string;
  userId: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  bookingId?: string;
  status: 'open' | 'in_progress' | 'resolved';
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface PlatformSettings {
  commissionRate: number;
  minPayoutAmount: number;
  currency: string;
  supportEmail: string;
  supportPhone: string;
  whatsappNumber?: string;
  aboutText?: string;
  xUrl?: string;
  instagramUrl?: string;
  tiktokUrl?: string;
  snapchatUrl?: string;
  updatedAt?: unknown;
}

export interface PlatformReview {
  id: string;
  userId: string;
  userName: string;
  rating: number;
  comment?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface TripReview {
  id: string;
  tripId: string;
  bookingId: string;
  userId: string;
  userName: string;
  rating: number;
  comment?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export type ContactRequestMethod = 'whatsapp' | 'phone';
export type ContactRequestStatus = 'new' | 'in_progress' | 'contacted' | 'completed';

export interface ContactRequest {
  id: string;
  name: string;
  phone: string;
  preferredMethod: ContactRequestMethod;
  message?: string;
  officialWhatsapp?: string;
  userId?: string | null;
  status: ContactRequestStatus;
  adminNote?: string;
  processedBy?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

