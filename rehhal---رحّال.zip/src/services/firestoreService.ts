import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { CURATED_TRIPS } from '../data/curatedTrips';
import { auth, db, handleFirestoreError, OperationType } from '../firebase/firebase';
import type { ActiveReferral } from '../context/ReferralContext';
import type {
  Booking,
  CommissionRecord,
  ContactRequest,
  ContactRequestMethod,
  ContactRequestStatus,
  MarketerProfile,
  PayoutRequest,
  PlatformReview,
  PlatformSettings,
  SupportTicket,
  Trip,
  TripReview,
  UserProfile,
} from '../types';

function assertOnlineForFinancialAction() {
  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    throw new Error('لا يمكن تنفيذ الحجوزات أو العمليات المالية دون اتصال بالإنترنت.');
  }
}

export const DEFAULT_PLATFORM_SETTINGS: PlatformSettings = {
  commissionRate: 0.08,
  minPayoutAmount: 200,
  currency: 'EGP',
  supportEmail: 'support@rehhal.sa',
  supportPhone: '+966500000100',
  whatsappNumber: '+966500000100',
  aboutText:
    'منصة رحّال (REHHAL) متخصصة في تنظيم وتقديم برامج الحج والعمرة وتسهيل الوصول إلى تفاصيل الرحلات وإتمام الحجز بوضوح وموثوقية.',
  xUrl: '',
  instagramUrl: '',
  tiktokUrl: '',
  snapchatUrl: '',
};

const CATEGORY_PRIORITY: Record<Trip['category'], number> = {
  hajj: 0,
  umrah: 1,
  heritage: 2,
  desert: 3,
  coastal: 4,
  mountain: 5,
};

export function sortTripsByStrategy(list: Trip[]): Trip[] {
  return [...list].sort((a, b) => {
    const catDiff = (CATEGORY_PRIORITY[a.category] ?? 9) - (CATEGORY_PRIORITY[b.category] ?? 9);
    if (catDiff !== 0) return catDiff;
    const orderA = typeof a.displayOrder === 'number' ? a.displayOrder : 999;
    const orderB = typeof b.displayOrder === 'number' ? b.displayOrder : 999;
    if (orderA !== orderB) return orderA - orderB;
    return a.title.localeCompare(b.title, 'ar');
  });
}

export async function fetchTrips(): Promise<Trip[]> {
  try {
    const snap = await getDocs(collection(db, 'trips'));
    if (snap.empty) {
      return sortTripsByStrategy(CURATED_TRIPS);
    }
    const curatedMap = new Map(CURATED_TRIPS.map((c) => [c.id, c]));
    const list = snap.docs.map((d) => {
      const raw = d.data() as Trip;
      const fallback = curatedMap.get(d.id);
      return {
        ...fallback,
        ...raw,
        currency: raw.currency || fallback?.currency || 'SAR',
        id: d.id,
      } as Trip;
    });
    return list.length > 0 ? sortTripsByStrategy(list) : sortTripsByStrategy(CURATED_TRIPS);
  } catch {
    return sortTripsByStrategy(CURATED_TRIPS);
  }
}

export async function fetchTripById(tripId: string): Promise<Trip | null> {
  const fallback = CURATED_TRIPS.find((t) => t.id === tripId) || null;
  try {
    const snap = await getDoc(doc(db, 'trips', tripId));
    if (snap.exists()) {
      const raw = snap.data() as Trip;
      return {
        ...(fallback || {}),
        ...raw,
        currency: raw.currency || fallback?.currency || 'SAR',
        id: snap.id,
      } as Trip;
    }
  } catch {
    // Fallback to curated catalog if offline or unseeded
  }
  return fallback;
}

export async function createBookingWithAttribution(params: {
  userId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  trip: Trip;
  travelDate: string;
  guests: number;
  notes?: string;
  referral: ActiveReferral | null;
}): Promise<string> {
  assertOnlineForFinancialAction();

  if (
    typeof params.trip.price !== 'number' ||
    params.trip.price <= 0 ||
    params.trip.currency !== 'EGP'
  ) {
    throw new Error('تسعير هذه الباقة بالجنيه المصري قيد التحديث من الإدارة، يرجى طلب التواصل.');
  }

  const bookingId = `bkg_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
  const unitPrice = params.trip.price;
  const totalAmount = unitPrice * params.guests;
  const hasReferral = Boolean(params.referral && params.referral.marketerId !== params.userId);
  const commissionRate = hasReferral ? params.referral!.commissionRate : 0;
  const commissionAmount = hasReferral ? Math.round(totalAmount * commissionRate) : 0;

  const tripRef = doc(db, 'trips', params.trip.id);
  const bookingRef = doc(db, 'bookings', bookingId);

  const batch = writeBatch(db);
  batch.set(bookingRef, {
    userId: params.userId,
    customerName: params.customerName.trim(),
    customerEmail: params.customerEmail.trim(),
    customerPhone: params.customerPhone.trim(),
    tripId: params.trip.id,
    tripTitle: params.trip.title,
    travelDate: params.travelDate,
    guests: params.guests,
    unitPrice,
    totalAmount,
    currency: 'EGP',
    notes: (params.notes || '').trim(),
    status: 'pending_payment',
    paymentStatus: 'unpaid',
    referralCode: hasReferral ? params.referral!.code : null,
    marketerId: hasReferral ? params.referral!.marketerId : null,
    referralSignature: hasReferral ? params.referral!.signature : null,
    commissionAmount,
    commissionStatus: hasReferral ? 'pending' : 'none',
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  if (hasReferral && params.referral) {
    const commissionId = `com_${bookingId}`;
    batch.set(doc(db, 'commissions', commissionId), {
      marketerId: params.referral.marketerId,
      bookingId,
      tripId: params.trip.id,
      tripTitle: params.trip.title,
      referralCode: params.referral.code,
      bookingAmount: totalAmount,
      commissionRate: params.referral.commissionRate,
      amount: commissionAmount,
      currency: 'EGP',
      status: 'pending',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  }

  try {
    const tripCheck = await getDoc(tripRef);
    if (!tripCheck.exists()) {
      throw new Error('لم يتم تهيئة هذه الرحلة في قاعدة البيانات بعد. يرجى تهيئة الكتالوج من حساب الإدارة.');
    }
    await batch.commit();
    return bookingId;
  } catch (err) {
    if (err instanceof Error && err.message.includes('تهيئة')) throw err;
    handleFirestoreError(err, OperationType.WRITE, `bookings/${bookingId}`);
  }
}

export async function confirmBookingPayment(params: {
  bookingId: string;
  userId: string;
  amount: number;
  paymentMethod: 'mada' | 'visa' | 'apple_pay' | 'bank_transfer';
}): Promise<string> {
  assertOnlineForFinancialAction();

  const idToken = auth.currentUser ? await auth.currentUser.getIdToken() : '';
  if (!idToken) {
    throw new Error('يجب تسجيل الدخول لإتمام الدفع.');
  }

  const authRes = await fetch('/api/payments/authorize', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${idToken}`,
    },
    body: JSON.stringify({
      ...params,
      currency: 'EGP',
    }),
  });

  if (!authRes.ok) {
    const errJson = (await authRes.json().catch(() => ({}))) as { error?: string };
    throw new Error(errJson.error || 'فشل التحقق من عملية الدفع مع الخادم');
  }

  const { paymentRef } = (await authRes.json()) as { paymentRef: string };

  try {
    await updateDoc(doc(db, 'bookings', params.bookingId), {
      status: 'confirmed',
      paymentStatus: 'paid',
      paymentMethod: params.paymentMethod,
      paymentRef,
      updatedAt: serverTimestamp(),
    });
    return paymentRef;
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `bookings/${params.bookingId}`);
  }
}

export async function cancelPendingBooking(bookingId: string): Promise<void> {
  assertOnlineForFinancialAction();
  try {
    await updateDoc(doc(db, 'bookings', bookingId), {
      status: 'cancelled',
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `bookings/${bookingId}`);
  }
}

export async function fetchBookingById(bookingId: string): Promise<Booking | null> {
  try {
    const snap = await getDoc(doc(db, 'bookings', bookingId));
    if (!snap.exists()) return null;
    const raw = snap.data() as Booking;
    return { ...raw, currency: raw.currency || 'SAR', id: snap.id };
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `bookings/${bookingId}`);
  }
}

export async function fetchCustomerBookings(userId: string): Promise<Booking[]> {
  try {
    const q = query(
      collection(db, 'bookings'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => {
      const raw = d.data() as Booking;
      return { ...raw, currency: raw.currency || 'SAR', id: d.id };
    });
  } catch (err) {
    try {
      const qFallback = query(collection(db, 'bookings'), where('userId', '==', userId));
      const snap = await getDocs(qFallback);
      return snap.docs.map((d) => {
        const raw = d.data() as Booking;
        return { ...raw, currency: raw.currency || 'SAR', id: d.id };
      });
    } catch {
      handleFirestoreError(err, OperationType.LIST, 'bookings');
    }
  }
}

export async function fetchUserCompletedBookingsForTrip(
  userId: string,
  tripId: string
): Promise<Booking[]> {
  try {
    const q = query(collection(db, 'bookings'), where('userId', '==', userId));
    const snap = await getDocs(q);
    return snap.docs
      .map((d) => {
        const raw = d.data() as Booking;
        return { ...raw, currency: raw.currency || 'SAR', id: d.id };
      })
      .filter((b) => b.tripId === tripId && b.status === 'completed');
  } catch {
    return [];
  }
}

// --- Platform Reviews (Profile -> Admin, completely separate from trip_reviews) ---

export async function fetchMyPlatformReview(userId: string): Promise<PlatformReview | null> {
  try {
    const snap = await getDoc(doc(db, 'platform_reviews', userId));
    if (!snap.exists()) return null;
    return { ...(snap.data() as PlatformReview), id: snap.id };
  } catch {
    return null;
  }
}

export async function savePlatformReview(params: {
  userId: string;
  userName: string;
  rating: number;
  comment?: string;
}): Promise<void> {
  assertOnlineForFinancialAction();
  const rating = Math.min(5, Math.max(1, Math.round(params.rating)));
  const cleanName = params.userName.trim().length >= 2 ? params.userName.trim().slice(0, 120) : 'عميل رحّال';
  const cleanComment = (params.comment || '').trim().slice(0, 1000);
  const reviewRef = doc(db, 'platform_reviews', params.userId);

  try {
    const existingSnap = await getDoc(reviewRef);
    if (existingSnap.exists()) {
      await updateDoc(reviewRef, {
        userName: cleanName,
        rating,
        comment: cleanComment,
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(reviewRef, {
        userId: params.userId,
        userName: cleanName,
        rating,
        comment: cleanComment,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `platform_reviews/${params.userId}`);
  }
}

export async function adminFetchAllPlatformReviews(): Promise<PlatformReview[]> {
  try {
    const snap = await getDocs(collection(db, 'platform_reviews'));
    return snap.docs.map((d) => ({ ...(d.data() as PlatformReview), id: d.id }));
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'platform_reviews');
  }
}

export async function adminDeletePlatformReview(userId: string): Promise<void> {
  assertOnlineForFinancialAction();
  try {
    await deleteDoc(doc(db, 'platform_reviews', userId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `platform_reviews/${userId}`);
  }
}

// --- Trip Reviews (inside TripDetailPage, strictly gated to completed bookings) ---

export async function fetchTripReviews(tripId: string): Promise<TripReview[]> {
  try {
    const q = query(collection(db, 'trip_reviews'), where('tripId', '==', tripId));
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({ ...(d.data() as TripReview), id: d.id }));
  } catch {
    return [];
  }
}

export async function saveTripReview(params: {
  tripId: string;
  bookingId: string;
  userId: string;
  userName: string;
  rating: number;
  comment?: string;
}): Promise<string> {
  assertOnlineForFinancialAction();
  const rating = Math.min(5, Math.max(1, Math.round(params.rating)));
  const cleanName = params.userName.trim().length >= 2 ? params.userName.trim().slice(0, 120) : 'ضيف رحّال';
  const cleanComment = (params.comment || '').trim().slice(0, 1000);
  const reviewId = `trv_${params.bookingId}`;
  const reviewRef = doc(db, 'trip_reviews', reviewId);

  try {
    const existingSnap = await getDoc(reviewRef);
    if (existingSnap.exists()) {
      await updateDoc(reviewRef, {
        userName: cleanName,
        rating,
        comment: cleanComment,
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(reviewRef, {
        tripId: params.tripId,
        bookingId: params.bookingId,
        userId: params.userId,
        userName: cleanName,
        rating,
        comment: cleanComment,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
    return reviewId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `trip_reviews/${reviewId}`);
  }
}

export async function adminFetchAllTripReviews(): Promise<TripReview[]> {
  try {
    const snap = await getDocs(collection(db, 'trip_reviews'));
    return snap.docs.map((d) => ({ ...(d.data() as TripReview), id: d.id }));
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'trip_reviews');
  }
}

export async function adminDeleteTripReview(reviewId: string): Promise<void> {
  assertOnlineForFinancialAction();
  try {
    await deleteDoc(doc(db, 'trip_reviews', reviewId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `trip_reviews/${reviewId}`);
  }
}

// --- Partner Marketer Operations ---

export async function registerPartnerMarketer(params: {
  uid: string;
  fullName: string;
  phone: string;
  city: string;
  channel: string;
  requestedCode: string;
}): Promise<string> {
  assertOnlineForFinancialAction();

  const code = params.requestedCode.trim().toUpperCase().replace(/[^A-Z0-9_\-]/g, '');
  if (!/^[A-Z0-9_\-]{3,32}$/.test(code)) {
    throw new Error('كود الإحالة يجب أن يتكون من 3 إلى 32 حرفاً أو رقماً إنجليزياً.');
  }

  const existingCode = await getDoc(doc(db, 'referral_codes', code));
  if (existingCode.exists()) {
    throw new Error('كود الإحالة هذا مستخدم مسبقاً، يرجى اختيار كود آخر.');
  }

  const batch = writeBatch(db);
  batch.set(doc(db, 'referral_codes', code), {
    code,
    marketerId: params.uid,
    marketerName: params.fullName.trim(),
    commissionRate: 0.08,
    active: false,
    createdAt: serverTimestamp(),
  });

  batch.set(doc(db, 'marketers', params.uid), {
    uid: params.uid,
    fullName: params.fullName.trim(),
    phone: params.phone.trim(),
    city: params.city.trim(),
    channel: params.channel.trim(),
    referralCode: code,
    commissionRate: 0.08,
    status: 'pending',
    totalEarnings: 0,
    availableBalance: 0,
    pendingBalance: 0,
    currency: 'EGP',
    clicksCount: 0,
    conversionsCount: 0,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  try {
    await batch.commit();
    return code;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `marketers/${params.uid}`);
  }
}

export async function fetchMarketerReferredBookings(marketerId: string): Promise<Booking[]> {
  try {
    const q = query(collection(db, 'bookings'), where('marketerId', '==', marketerId));
    const snap = await getDocs(q);
    return snap.docs.map((d) => {
      const raw = d.data() as Booking;
      return { ...raw, currency: raw.currency || 'SAR', id: d.id };
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'bookings');
  }
}

export async function fetchMarketerCommissions(marketerId: string): Promise<CommissionRecord[]> {
  try {
    const q = query(collection(db, 'commissions'), where('marketerId', '==', marketerId));
    const snap = await getDocs(q);
    return snap.docs.map((d) => {
      const raw = d.data() as CommissionRecord;
      return { ...raw, currency: raw.currency || 'SAR', id: d.id };
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'commissions');
  }
}

export async function fetchMarketerPayouts(marketerId: string): Promise<PayoutRequest[]> {
  try {
    const q = query(collection(db, 'payout_requests'), where('marketerId', '==', marketerId));
    const snap = await getDocs(q);
    return snap.docs.map((d) => {
      const raw = d.data() as PayoutRequest;
      return { ...raw, currency: raw.currency || 'SAR', id: d.id };
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'payout_requests');
  }
}

export async function submitPayoutRequest(params: {
  marketer: MarketerProfile;
  amount: number;
  iban: string;
  bankName: string;
  accountHolder: string;
}): Promise<string> {
  assertOnlineForFinancialAction();

  if (params.amount < 100) {
    throw new Error('الحد الأدنى لطلب السحب هو 100 ج.م.');
  }
  if (params.amount > params.marketer.availableBalance) {
    throw new Error('المبلغ المطلوب يتجاوز الرصيد القابل للسحب حالياً.');
  }

  const payoutId = `pay_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
  try {
    await setDoc(doc(db, 'payout_requests', payoutId), {
      marketerId: params.marketer.uid,
      marketerName: params.marketer.fullName,
      amount: params.amount,
      currency: 'EGP',
      iban: params.iban.trim().toUpperCase(),
      bankName: params.bankName.trim(),
      accountHolder: params.accountHolder.trim(),
      status: 'pending',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return payoutId;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `payout_requests/${payoutId}`);
  }
}

export async function createSupportTicket(params: {
  userId: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  bookingId?: string;
}): Promise<string> {
  assertOnlineForFinancialAction();
  const ticketId = `tkt_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
  try {
    await setDoc(doc(db, 'support_tickets', ticketId), {
      userId: params.userId,
      name: params.name.trim(),
      email: params.email.trim(),
      subject: params.subject.trim(),
      message: params.message.trim(),
      ...(params.bookingId?.trim() ? { bookingId: params.bookingId.trim() } : {}),
      status: 'open',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return ticketId;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `support_tickets/${ticketId}`);
  }
}

export async function fetchUserTickets(userId: string): Promise<SupportTicket[]> {
  try {
    const q = query(collection(db, 'support_tickets'), where('userId', '==', userId));
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({ ...(d.data() as SupportTicket), id: d.id }));
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'support_tickets');
  }
}

// --- Admin Operations ---

export async function adminFetchAllBookings(): Promise<Booking[]> {
  try {
    const snap = await getDocs(collection(db, 'bookings'));
    return snap.docs.map((d) => {
      const raw = d.data() as Booking;
      return { ...raw, currency: raw.currency || 'SAR', id: d.id };
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'bookings');
  }
}

export async function adminFetchAllUsers(): Promise<UserProfile[]> {
  try {
    const snap = await getDocs(collection(db, 'users'));
    return snap.docs.map((d) => d.data() as UserProfile);
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'users');
  }
}

export async function adminFetchAllMarketers(): Promise<MarketerProfile[]> {
  try {
    const snap = await getDocs(collection(db, 'marketers'));
    return snap.docs.map((d) => d.data() as MarketerProfile);
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'marketers');
  }
}

export async function adminFetchAllCommissions(): Promise<CommissionRecord[]> {
  try {
    const snap = await getDocs(collection(db, 'commissions'));
    return snap.docs.map((d) => {
      const raw = d.data() as CommissionRecord;
      return { ...raw, currency: raw.currency || 'SAR', id: d.id };
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'commissions');
  }
}

export async function adminFetchAllPayouts(): Promise<PayoutRequest[]> {
  try {
    const snap = await getDocs(collection(db, 'payout_requests'));
    return snap.docs.map((d) => {
      const raw = d.data() as PayoutRequest;
      return { ...raw, currency: raw.currency || 'SAR', id: d.id };
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'payout_requests');
  }
}

export async function adminSaveTrip(trip: Trip, isNew: boolean): Promise<void> {
  assertOnlineForFinancialAction();
  const ref = doc(db, 'trips', trip.id);
  const payload = {
    title: trip.title.trim(),
    subtitle: trip.subtitle.trim(),
    destination: trip.destination.trim(),
    category: trip.category,
    durationDays: typeof trip.durationDays === 'number' && trip.durationDays >= 1 ? trip.durationDays : null,
    price: typeof trip.price === 'number' && trip.price > 0 ? trip.price : null,
    currency: trip.currency === 'SAR' ? 'SAR' : 'EGP',
    maxGuests: trip.maxGuests,
    imageUrl: trip.imageUrl.trim(),
    description: trip.description.trim(),
    highlights: (trip.highlights || []).map((h) => h.trim()).filter(Boolean).slice(0, 12),
    services: (trip.services || []).map((s) => s.trim()).filter(Boolean).slice(0, 16),
    terms: (trip.terms || '').trim().slice(0, 2000),
    departureDates: (trip.departureDates || []).map((d) => d.trim()).filter(Boolean).slice(0, 20),
    active: Boolean(trip.active),
    featured: Boolean(trip.featured),
    sliderVisible: Boolean(trip.sliderVisible),
    sliderOrder: typeof trip.sliderOrder === 'number' ? Math.max(0, Math.min(999, trip.sliderOrder)) : 99,
    displayOrder: typeof trip.displayOrder === 'number' ? Math.max(0, Math.min(9999, trip.displayOrder)) : 99,
    programTier: trip.programTier || (trip.category === 'hajj' ? 'hajj' : trip.category === 'umrah' ? 'umrah' : 'leisure'),
  };

  try {
    if (isNew) {
      await setDoc(ref, {
        id: trip.id,
        ...payload,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(ref, {
        ...payload,
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `trips/${trip.id}`);
  }
}

export async function adminUpdateBookingLifecycle(
  booking: Booking,
  nextStatus: Booking['status'],
  nextPaymentStatus: Booking['paymentStatus']
): Promise<void> {
  assertOnlineForFinancialAction();

  const nextCommissionStatus =
    booking.marketerId && nextStatus === 'completed' && nextPaymentStatus === 'paid'
      ? 'eligible'
      : booking.marketerId && nextStatus === 'cancelled'
      ? 'none'
      : booking.commissionStatus;

  const batch = writeBatch(db);
  batch.update(doc(db, 'bookings', booking.id), {
    status: nextStatus,
    paymentStatus: nextPaymentStatus,
    commissionStatus: nextCommissionStatus,
    updatedAt: serverTimestamp(),
  });

  if (booking.marketerId) {
    const comId = `com_${booking.id}`;
    const comRef = doc(db, 'commissions', comId);
    const comSnap = await getDoc(comRef);

    if (comSnap.exists()) {
      const prevComStatus = comSnap.data().status;
      const targetComStatus =
        nextStatus === 'completed' && nextPaymentStatus === 'paid'
          ? 'eligible'
          : nextStatus === 'cancelled'
          ? 'cancelled'
          : 'pending';

      batch.update(comRef, {
        status: targetComStatus,
        updatedAt: serverTimestamp(),
      });

      if (prevComStatus !== 'eligible' && targetComStatus === 'eligible') {
        const marketerRef = doc(db, 'marketers', booking.marketerId);
        const mSnap = await getDoc(marketerRef);
        if (mSnap.exists()) {
          const m = mSnap.data() as MarketerProfile;
          batch.update(marketerRef, {
            availableBalance: (m.availableBalance || 0) + booking.commissionAmount,
            totalEarnings: (m.totalEarnings || 0) + booking.commissionAmount,
            conversionsCount: (m.conversionsCount || 0) + 1,
            updatedAt: serverTimestamp(),
          });
        }
      }
    }
  }

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `bookings/${booking.id}`);
  }
}

export async function adminProcessPayoutRequest(params: {
  payout: PayoutRequest;
  nextStatus: 'approved' | 'paid' | 'rejected';
  adminNote: string;
  adminUid: string;
}): Promise<void> {
  assertOnlineForFinancialAction();

  const batch = writeBatch(db);
  batch.update(doc(db, 'payout_requests', params.payout.id), {
    status: params.nextStatus,
    adminNote: params.adminNote.trim(),
    processedBy: params.adminUid,
    updatedAt: serverTimestamp(),
  });

  if (params.nextStatus === 'paid' && params.payout.status !== 'paid') {
    const marketerRef = doc(db, 'marketers', params.payout.marketerId);
    const mSnap = await getDoc(marketerRef);
    if (mSnap.exists()) {
      const m = mSnap.data() as MarketerProfile;
      batch.update(marketerRef, {
        availableBalance: Math.max(0, (m.availableBalance || 0) - params.payout.amount),
        updatedAt: serverTimestamp(),
      });
    }
  }

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `payout_requests/${params.payout.id}`);
  }
}

export async function adminUpdateMarketerAccount(
  marketerId: string,
  status: MarketerProfile['status'],
  commissionRate: number
): Promise<void> {
  assertOnlineForFinancialAction();
  try {
    const marketerRef = doc(db, 'marketers', marketerId);
    const mSnap = await getDoc(marketerRef);
    const marketerData = mSnap.exists() ? (mSnap.data() as MarketerProfile) : null;

    const batch = writeBatch(db);
    batch.update(marketerRef, {
      status,
      commissionRate,
      updatedAt: serverTimestamp(),
    });

    if (marketerData?.referralCode) {
      batch.update(doc(db, 'referral_codes', marketerData.referralCode), {
        active: status === 'active',
        commissionRate,
      });
    }

    const userRef = doc(db, 'users', marketerId);
    const uSnap = await getDoc(userRef);
    if (uSnap.exists()) {
      const existingRole = (uSnap.data() as UserProfile).role;
      if (existingRole !== 'admin') {
        batch.update(userRef, {
          role: status === 'active' ? 'marketer' : 'customer',
          updatedAt: serverTimestamp(),
        });
      }
    }

    await batch.commit();

    if (status === 'active' && marketerData?.referralCode) {
      const token = await auth.currentUser?.getIdToken().catch(() => '');
      if (token) {
        fetch('/api/referrals/register', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            code: marketerData.referralCode,
            marketerId,
            marketerName: marketerData.fullName,
            commissionRate,
          }),
        }).catch(() => undefined);
      }
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `marketers/${marketerId}`);
  }
}

export async function fetchPlatformSettings(): Promise<PlatformSettings> {
  try {
    const snap = await getDoc(doc(db, 'settings', 'platform'));
    if (snap.exists()) {
      return {
        ...DEFAULT_PLATFORM_SETTINGS,
        ...(snap.data() as PlatformSettings),
      };
    }
  } catch {
    // Fallback defaults
  }
  return DEFAULT_PLATFORM_SETTINGS;
}

export async function adminSavePlatformSettings(settings: PlatformSettings): Promise<void> {
  assertOnlineForFinancialAction();
  const payload = {
    commissionRate: settings.commissionRate,
    minPayoutAmount: settings.minPayoutAmount,
    currency: 'EGP',
    supportEmail: settings.supportEmail.trim(),
    supportPhone: settings.supportPhone.trim(),
    whatsappNumber: (settings.whatsappNumber || '').trim().slice(0, 32),
    aboutText: (settings.aboutText || '').trim().slice(0, 600),
    xUrl: (settings.xUrl || '').trim().slice(0, 250),
    instagramUrl: (settings.instagramUrl || '').trim().slice(0, 250),
    tiktokUrl: (settings.tiktokUrl || '').trim().slice(0, 250),
    snapchatUrl: (settings.snapchatUrl || '').trim().slice(0, 250),
    updatedAt: serverTimestamp(),
  };

  try {
    await setDoc(doc(db, 'settings', 'platform'), payload);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, 'settings/platform');
  }
}

// --- Contact Requests (Footer/Support Modal -> Firebase -> Admin Panel) ---

export async function submitContactRequest(params: {
  name: string;
  phone: string;
  preferredMethod: ContactRequestMethod;
  message?: string;
  officialWhatsapp?: string;
  userId?: string | null;
}): Promise<string> {
  assertOnlineForFinancialAction();

  const cleanName = params.name.trim().slice(0, 120);
  const cleanPhone = params.phone.trim().slice(0, 32);
  const digits = cleanPhone.replace(/[^\d]/g, '');

  if (cleanName.length < 2) {
    throw new Error('يرجى إدخال الاسم الكامل (حرفين على الأقل).');
  }
  if (!/^[+0-9\s\-()]{7,32}$/.test(cleanPhone) || digits.length < 8) {
    throw new Error('يرجى إدخال رقم هاتف صحيح للتواصل.');
  }

  const requestId = `crq_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
  const cleanMessage = (params.message || '').trim().slice(0, 500);
  const cleanOfficialWhatsapp = (params.officialWhatsapp || '').trim().slice(0, 32);

  try {
    await setDoc(doc(db, 'contact_requests', requestId), {
      name: cleanName,
      phone: cleanPhone,
      preferredMethod: params.preferredMethod,
      ...(cleanMessage ? { message: cleanMessage } : {}),
      ...(cleanOfficialWhatsapp ? { officialWhatsapp: cleanOfficialWhatsapp } : {}),
      userId: params.userId || null,
      status: 'new',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return requestId;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `contact_requests/${requestId}`);
  }
}

export async function adminFetchContactRequests(): Promise<ContactRequest[]> {
  try {
    const q = query(collection(db, 'contact_requests'), orderBy('createdAt', 'desc'));
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({ ...(d.data() as ContactRequest), id: d.id }));
  } catch (err) {
    try {
      const snap = await getDocs(collection(db, 'contact_requests'));
      return snap.docs.map((d) => ({ ...(d.data() as ContactRequest), id: d.id }));
    } catch {
      handleFirestoreError(err, OperationType.LIST, 'contact_requests');
    }
  }
}

export async function adminUpdateContactRequest(params: {
  requestId: string;
  status: ContactRequestStatus;
  adminNote: string;
  adminUid: string;
}): Promise<void> {
  assertOnlineForFinancialAction();
  try {
    await updateDoc(doc(db, 'contact_requests', params.requestId), {
      status: params.status,
      adminNote: params.adminNote.trim().slice(0, 500),
      processedBy: params.adminUid,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `contact_requests/${params.requestId}`);
  }
}

export async function adminDeleteContactRequest(requestId: string): Promise<void> {
  assertOnlineForFinancialAction();
  try {
    await deleteDoc(doc(db, 'contact_requests', requestId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `contact_requests/${requestId}`);
  }
}

