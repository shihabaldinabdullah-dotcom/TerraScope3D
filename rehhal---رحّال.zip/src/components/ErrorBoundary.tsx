import React from 'react';
import { AlertTriangle, Home, RotateCcw } from 'lucide-react';
import { ROUTES } from '../routes/routeRegistry';

interface State {
  hasError: boolean;
  errorMessage: string;
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return {
      hasError: true,
      errorMessage: error.message || 'حدث خطأ غير متوقع في التطبيق.',
    };
  }

  render() {
    if (this.state.hasError) {
      let friendly = 'تعذر إتمام العملية أو تحميل البيانات. يرجى التحقق من الاتصال أو الصلاحيات.';
      try {
        const parsed = JSON.parse(this.state.errorMessage) as { error?: string; operationType?: string };
        if (parsed.error && parsed.error.toLowerCase().includes('permission')) {
          friendly = 'ليست لديك صلاحية كافية للوصول إلى هذه البيانات أو تنفيذ هذا الإجراء.';
        }
      } catch {
        // Non-JSON error
      }

      return (
        <div className="min-h-screen bg-[#0B172A] text-[#F4F1EA] flex items-center justify-center p-6">
          <div className="max-w-md w-full rounded-2xl bg-[#12233B] border border-[#C5A15B]/30 p-8 text-center">
            <div className="w-12 h-12 rounded-xl bg-amber-500/15 text-[#C5A15B] flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h1 className="text-xl font-bold mb-2">تنبيه في النظام</h1>
            <p className="text-sm text-[#CBD5E1] leading-relaxed mb-6">{friendly}</p>
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                type="button"
                onClick={() => window.location.reload()}
                className="flex-1 min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-[#C5A15B] text-[#0B172A] px-4 py-2.5 text-sm font-bold hover:opacity-90 transition"
              >
                <RotateCcw className="w-4 h-4" />
                إعادة المحاولة
              </button>
              <a
                href={ROUTES.HOME}
                className="flex-1 min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl border border-[#C5A15B]/40 text-[#F4F1EA] px-4 py-2.5 text-sm font-medium hover:bg-white/5 transition"
              >
                <Home className="w-4 h-4" />
                العودة للرئيسية
              </a>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
