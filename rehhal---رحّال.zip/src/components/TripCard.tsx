import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Compass } from 'lucide-react';
import { TRIP_CATEGORY_LABELS, type Trip } from '../types';
import { ROUTES } from '../routes/routeRegistry';
import { formatCustomerAmount } from '../utils/currency';

export const TripCard: React.FC<{
  trip: Trip;
  refCode?: string | null;
  compact?: boolean;
}> = ({ trip, refCode, compact = false }) => {
  const [imgError, setImgError] = useState(false);

  const approvedEgpPrice = formatCustomerAmount(trip.price, trip.currency);
  const hasDuration = typeof trip.durationDays === 'number' && trip.durationDays > 0;
  const nextDate = trip.departureDates && trip.departureDates.length > 0 ? trip.departureDates[0] : null;
  const detailUrl = ROUTES.tripDetail(trip.id, refCode);

  return (
    <article
      className={`group flex flex-col rounded-2xl bg-[#12233B] border overflow-hidden transition-transform duration-200 hover:-translate-y-0.5 hover:border-[#C5A15B]/55 ${
        compact ? 'border-white/10' : 'border-white/15'
      }`}
    >
      <Link
        to={detailUrl}
        className={`relative block w-full bg-[#0B172A] overflow-hidden ${
          compact ? 'aspect-[16/9]' : 'aspect-[4/3]'
        }`}
      >
        {!imgError && trip.imageUrl ? (
          <img
            src={trip.imageUrl}
            alt={trip.title}
            loading="lazy"
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-[#12233B] to-[#0B172A] text-[#C5A15B] p-6 text-center">
            <Compass className="w-10 h-10 mb-2 opacity-80" />
            <span className="text-sm font-medium text-[#FFFFFF]">{trip.destination}</span>
          </div>
        )}
      </Link>

      <div className={`flex flex-col flex-1 ${compact ? 'p-4 gap-2.5' : 'p-5 sm:p-6 gap-3'}`}>
        <div className="flex flex-wrap items-center gap-2 text-xs font-bold text-[#C5A15B]">
          <span>{TRIP_CATEGORY_LABELS[trip.category]}</span>
          <span aria-hidden="true">·</span>
          <span className="text-[#CBD5E1]">{trip.destination}</span>
          {hasDuration && (
            <>
              <span aria-hidden="true">·</span>
              <span className="font-mono-num text-[#CBD5E1]">{trip.durationDays} أيام</span>
            </>
          )}
        </div>

        <h3
          className={`font-bold text-[#FFFFFF] leading-snug group-hover:text-[#C5A15B] transition-colors ${
            compact ? 'text-base sm:text-lg' : 'text-lg sm:text-xl'
          }`}
        >
          <Link to={detailUrl}>{trip.title}</Link>
        </h3>

        {!compact && (
          <p className="text-sm text-[#E2E8F0] line-clamp-2 leading-relaxed flex-1">
            {trip.subtitle}
          </p>
        )}

        <div className="pt-3 mt-auto border-t border-white/10 space-y-3">
          <div>
            {approvedEgpPrice ? (
              <div className="flex items-baseline gap-1.5">
                <span className="text-xs text-[#CBD5E1]">تبدأ من</span>
                <span
                  className={`font-extrabold text-[#FFFFFF] font-mono-num ${
                    compact ? 'text-sm' : 'text-base'
                  }`}
                >
                  {approvedEgpPrice}
                </span>
              </div>
            ) : nextDate ? (
              <div className="flex items-center justify-between gap-2 text-xs text-[#CBD5E1]">
                <span>التسعير بـ ج.م عند الاستفسار</span>
                <span className="font-mono-num text-[#FFFFFF]">{nextDate}</span>
              </div>
            ) : (
              <span className="text-xs text-[#CBD5E1]">التسعير بـ ج.م عند الاستفسار</span>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2">
            <Link
              to={`${detailUrl}#booking-form`}
              className="min-h-[42px] inline-flex items-center justify-center gap-1 rounded-xl bg-[#C5A15B] text-[#0B172A] px-3 py-2 text-xs sm:text-sm font-extrabold hover:opacity-90 transition whitespace-nowrap"
            >
              <span>احجز الآن</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </Link>
            <Link
              to={detailUrl}
              className="min-h-[42px] inline-flex items-center justify-center rounded-xl border border-white/25 bg-[#0B172A]/70 text-[#FFFFFF] px-3 py-2 text-xs sm:text-sm font-bold hover:border-[#C5A15B] hover:text-[#C5A15B] transition whitespace-nowrap"
            >
              التفاصيل
            </Link>
          </div>
        </div>
      </div>
    </article>
  );
};
