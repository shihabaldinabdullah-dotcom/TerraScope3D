import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, ChevronLeft, ChevronRight, Compass } from 'lucide-react';
import { ROUTES } from '../routes/routeRegistry';
import type { Trip } from '../types';

interface HeroSliderProps {
  slides: Trip[];
  refCode?: string | null;
}

export const HeroSlider: React.FC<HeroSliderProps> = ({ slides, refCode }) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [userPaused, setUserPaused] = useState(false);
  const [hoverPaused, setHoverPaused] = useState(false);
  const [imgErrors, setImgErrors] = useState<Record<string, boolean>>({});

  useEffect(() => {
    if (activeIndex >= slides.length) {
      setActiveIndex(0);
    }
  }, [slides.length, activeIndex]);

  useEffect(() => {
    if (slides.length <= 1 || userPaused || hoverPaused) return;
    if (typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) {
      return;
    }

    const timer = window.setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % slides.length);
    }, 6000);

    return () => window.clearInterval(timer);
  }, [slides.length, userPaused, hoverPaused]);

  if (slides.length === 0) {
    return null;
  }

  const currentTrip = slides[activeIndex] || slides[0];

  const handleSelectSlide = (index: number) => {
    setUserPaused(true);
    setActiveIndex(index);
  };

  const handlePrev = () => {
    setUserPaused(true);
    setActiveIndex((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const handleNext = () => {
    setUserPaused(true);
    setActiveIndex((prev) => (prev + 1) % slides.length);
  };

  return (
    <section
      aria-label="الرحلات المختارة"
      onMouseEnter={() => setHoverPaused(true)}
      onMouseLeave={() => setHoverPaused(false)}
      onFocusCapture={() => setHoverPaused(true)}
      onBlurCapture={() => setHoverPaused(false)}
      className="max-w-7xl mx-auto px-4 sm:px-6 pt-5 sm:pt-8"
    >
      <div className="relative rounded-2xl overflow-hidden border border-[#C5A15B]/30 bg-[#12233B] min-h-[380px] sm:min-h-[460px] lg:min-h-[520px] flex items-end">
        {/* Background Slides Layer */}
        {slides.map((slide, index) => {
          const isActive = index === activeIndex;
          const hasError = Boolean(imgErrors[slide.id]);
          return (
            <div
              key={slide.id}
              aria-hidden={!isActive}
              className={`absolute inset-0 transition-opacity duration-500 ease-out ${
                isActive ? 'opacity-100 z-0' : 'opacity-0 pointer-events-none z-0'
              }`}
            >
              {!hasError && slide.imageUrl ? (
                <img
                  src={slide.imageUrl}
                  alt={slide.title}
                  referrerPolicy="no-referrer"
                  onError={() => setImgErrors((prev) => ({ ...prev, [slide.id]: true }))}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-[#12233B] to-[#0B172A] flex items-center justify-center">
                  <Compass className="w-16 h-16 text-[#C5A15B]/35" />
                </div>
              )}
              {/* Strong dark contrast scrims so image never obscures foreground text */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B172A] via-[#0B172A]/65 to-[#0B172A]/25" />
              <div className="absolute inset-0 bg-gradient-to-l from-[#0B172A]/85 via-[#0B172A]/35 to-transparent" />
            </div>
          );
        })}

        {/* Active Slide Content with Dedicated High-Contrast Dark Scrim Panel */}
        <div className="relative z-10 w-full p-4 sm:p-8 lg:p-10 flex flex-col lg:flex-row lg:items-end justify-between gap-5">
          <div className="max-w-2xl rounded-2xl bg-[#0B172A]/85 backdrop-blur-md border border-white/15 p-5 sm:p-7 space-y-3 sm:space-y-4 shadow-2xl">
            <h1 className="text-xl sm:text-3xl lg:text-[2.45rem] font-extrabold text-[#FFFFFF] leading-snug [text-wrap:balance]">
              <Link
                to={ROUTES.tripDetail(currentTrip.id, refCode)}
                className="hover:text-[#C5A15B] transition-colors"
              >
                {currentTrip.title}
              </Link>
            </h1>

            <p className="text-sm sm:text-base text-[#E2E8F0] leading-relaxed max-w-xl line-clamp-2">
              {currentTrip.subtitle}
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-1">
              <Link
                to={`${ROUTES.tripDetail(currentTrip.id, refCode)}#booking-form`}
                className="min-h-[46px] inline-flex items-center justify-center gap-2 rounded-xl bg-[#C5A15B] text-[#0B172A] px-6 py-2.5 text-sm sm:text-base font-extrabold hover:opacity-95 transition whitespace-nowrap shadow-lg"
              >
                <span>احجز الآن</span>
                <ArrowLeft className="w-4 h-4" />
              </Link>
              <Link
                to={ROUTES.tripDetail(currentTrip.id, refCode)}
                className="min-h-[46px] inline-flex items-center justify-center rounded-xl border border-white/35 bg-[#12233B]/90 text-[#FFFFFF] px-6 py-2.5 text-sm font-bold hover:border-[#C5A15B] hover:text-[#C5A15B] transition whitespace-nowrap"
              >
                التفاصيل
              </Link>
            </div>
          </div>

          {/* Slide Navigation Controls & Indicators */}
          {slides.length > 1 && (
            <div className="flex items-center justify-between lg:justify-end gap-4 rounded-xl bg-[#0B172A]/80 backdrop-blur-sm border border-white/10 px-3.5 py-2 self-stretch lg:self-auto">
              <div className="flex items-center gap-1.5" role="tablist" aria-label="اختر الشريحة">
                {slides.map((slide, idx) => {
                  const selected = idx === activeIndex;
                  return (
                    <button
                      key={slide.id}
                      type="button"
                      role="tab"
                      aria-selected={selected}
                      aria-label={`الانتقال إلى ${slide.title}`}
                      onClick={() => handleSelectSlide(idx)}
                      className="min-h-[36px] px-1 flex items-center justify-center"
                    >
                      <span
                        className={`block h-1.5 rounded-full transition-all duration-300 ${
                          selected ? 'w-7 bg-[#C5A15B]' : 'w-2 bg-white/40 hover:bg-white/70'
                        }`}
                      />
                    </button>
                  );
                })}
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-[#E2E8F0] font-mono-num px-1">
                  {activeIndex + 1} / {slides.length}
                </span>
                <button
                  type="button"
                  onClick={handlePrev}
                  aria-label="الشريحة السابقة"
                  className="min-h-[42px] min-w-[42px] inline-flex items-center justify-center rounded-xl border border-white/25 bg-[#12233B] text-[#FFFFFF] hover:border-[#C5A15B] hover:text-[#C5A15B] transition"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
                <button
                  type="button"
                  onClick={handleNext}
                  aria-label="الشريحة التالية"
                  className="min-h-[42px] min-w-[42px] inline-flex items-center justify-center rounded-xl border border-white/25 bg-[#12233B] text-[#FFFFFF] hover:border-[#C5A15B] hover:text-[#C5A15B] transition"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
