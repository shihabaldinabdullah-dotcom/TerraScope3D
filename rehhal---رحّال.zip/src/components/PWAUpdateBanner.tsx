import React, { useEffect, useState } from 'react';
import { RefreshCw, X } from 'lucide-react';

export const PWAUpdateBanner: React.FC = () => {
  const [waitingWorker, setWaitingWorker] = useState<ServiceWorker | null>(null);

  useEffect(() => {
    const onSwUpdate = (event: Event) => {
      const customEvent = event as CustomEvent<{ worker?: ServiceWorker }>;
      if (customEvent.detail?.worker) {
        setWaitingWorker(customEvent.detail.worker);
      }
    };

    window.addEventListener('rehhal-sw-update', onSwUpdate);
    return () => window.removeEventListener('rehhal-sw-update', onSwUpdate);
  }, []);

  if (!waitingWorker) return null;

  const handleApplyUpdate = () => {
    waitingWorker.postMessage({ type: 'SKIP_WAITING' });
    setWaitingWorker(null);
  };

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-20 lg:bottom-6 left-4 right-4 sm:right-auto sm:left-6 z-50 max-w-sm rounded-2xl bg-[#12233B] border border-[#C5A15B]/50 p-4 shadow-2xl flex items-center justify-between gap-3"
    >
      <div className="space-y-0.5 text-xs">
        <div className="font-bold text-[#F4F1EA]">يتوفر تحديث جديد لتطبيق رحّال</div>
        <div className="text-[#CBD5E1]">اضغط تحديث لتطبيق التحسينات الأخيرة بأمان.</div>
      </div>
      <div className="flex items-center gap-1.5 shrink-0">
        <button
          type="button"
          onClick={handleApplyUpdate}
          className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl bg-[#C5A15B] text-[#0B172A] px-3 py-1.5 text-xs font-bold hover:opacity-90 transition"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>تحديث الآن</span>
        </button>
        <button
          type="button"
          onClick={() => setWaitingWorker(null)}
          aria-label="تأجيل التحديث"
          className="min-h-[38px] min-w-[38px] inline-flex items-center justify-center rounded-xl text-[#9BA8BC] hover:text-white transition"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
