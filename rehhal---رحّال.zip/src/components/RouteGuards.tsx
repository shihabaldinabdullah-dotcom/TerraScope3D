import React from 'react';
import { Link, Navigate, useLocation } from 'react-router-dom';
import { ShieldAlert } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { ROUTES } from '../routes/routeRegistry';

const AuthLoadingState: React.FC = () => (
  <div className="min-h-[60vh] flex items-center justify-center p-6">
    <div className="flex flex-col items-center gap-3 text-[#9BA8BC]">
      <div className="w-8 h-8 rounded-full border-2 border-[#C5A15B] border-t-transparent animate-spin" />
      <span className="text-sm">جاري التحقق من الجلسة والصلاحيات...</span>
    </div>
  </div>
);

export const RequireAuth: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) return <AuthLoadingState />;
  if (!user) {
    const returnTo = `${location.pathname}${location.search}`;
    return <Navigate to={ROUTES.loginWithRedirect(returnTo)} state={{ from: returnTo }} replace />;
  }
  return <>{children}</>;
};

export const RequireMarketer: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isMarketer, loading } = useAuth();
  const location = useLocation();

  if (loading) return <AuthLoadingState />;
  if (!user) {
    const returnTo = `${location.pathname}${location.search}`;
    return <Navigate to={ROUTES.loginWithRedirect(returnTo)} state={{ from: returnTo }} replace />;
  }
  if (!isMarketer) {
    return <Navigate to={ROUTES.profileAffiliate()} replace />;
  }
  return <>{children}</>;
};

export const RequireAdmin: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isAdmin, loading } = useAuth();
  const location = useLocation();

  if (loading) return <AuthLoadingState />;
  if (!user) {
    const returnTo = `${location.pathname}${location.search}`;
    return <Navigate to={ROUTES.loginWithRedirect(returnTo)} state={{ from: returnTo }} replace />;
  }
  if (!isAdmin) {
    return (
      <div className="max-w-lg mx-auto my-16 px-6">
        <div className="rounded-2xl bg-[#12233B] border border-red-500/40 p-8 text-center">
          <div className="w-12 h-12 rounded-xl bg-red-500/15 text-red-400 flex items-center justify-center mx-auto mb-4">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <h1 className="text-xl font-bold text-[#F4F1EA] mb-2">وصول غير مصرح به (403)</h1>
          <p className="text-sm text-[#CBD5E1] mb-6 leading-relaxed">
            هذه الصفحة مخصصة لإدارة منصة رحّال فقط. تم تسجيل رفض الوصول لحماية بيانات النظام.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              to={ROUTES.HOME}
              className="min-h-[44px] inline-flex items-center justify-center rounded-xl bg-[#C5A15B] text-[#0B172A] px-5 py-2.5 text-sm font-bold hover:opacity-90 transition"
            >
              العودة للرئيسية
            </Link>
            <Link
              to={ROUTES.TRIPS}
              className="min-h-[44px] inline-flex items-center justify-center rounded-xl border border-[#C5A15B]/35 text-[#F4F1EA] px-5 py-2.5 text-sm font-medium hover:bg-white/5 transition"
            >
              تصفح الرحلات
            </Link>
          </div>
        </div>
      </div>
    );
  }
  return <>{children}</>;
};
