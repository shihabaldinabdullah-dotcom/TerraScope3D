import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { ROUTES } from '../routes/routeRegistry';

export const PartnerSubNav: React.FC = () => {
  const items = [
    { to: ROUTES.PARTNERS_DASHBOARD, label: 'لوحة المسوّق', end: true },
    { to: ROUTES.PARTNERS_REFERRALS, label: 'روابط الإحالة', end: false },
    { to: ROUTES.PARTNERS_BOOKINGS, label: 'الحجوزات المحالة', end: false },
    { to: ROUTES.PARTNERS_EARNINGS, label: 'الأرباح والعمولات', end: false },
    { to: ROUTES.PARTNERS_PAYOUTS, label: 'طلبات السحب', end: false },
  ];

  return (
    <div className="border-b border-white/10 bg-[#12233B]/70">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 overflow-x-auto">
        <nav aria-label="قائمة التسويق بالعمولة" className="flex items-center gap-2 py-2.5">
          <Link
            to={ROUTES.profileAffiliate()}
            className="min-h-[40px] inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold text-[#C5A15B] border border-[#C5A15B]/30 hover:bg-[#C5A15B]/10 whitespace-nowrap shrink-0 transition"
          >
            <ArrowRight className="w-3.5 h-3.5" />
            <span>الملف الشخصي</span>
          </Link>
          {items.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `min-h-[40px] inline-flex items-center px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap shrink-0 transition ${
                  isActive
                    ? 'bg-[#C5A15B] text-[#0B172A] font-bold'
                    : 'text-[#CBD5E1] hover:bg-white/5 hover:text-white'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </div>
  );
};

export const AdminSubNav: React.FC = () => {
  const items = [
    { to: ROUTES.ADMIN, label: 'نظرة عامة', end: true },
    { to: ROUTES.ADMIN_TRIPS, label: 'الرحلات والسلايدر', end: false },
    { to: ROUTES.ADMIN_BOOKINGS, label: 'الحجوزات', end: false },
    { to: ROUTES.ADMIN_CONTACTS, label: 'طلبات التواصل', end: false },
    { to: ROUTES.ADMIN_REVIEWS, label: 'التقييمات', end: false },
    { to: ROUTES.ADMIN_CUSTOMERS, label: 'العملاء', end: false },
    { to: ROUTES.ADMIN_MARKETERS, label: 'المسوّقون', end: false },
    { to: ROUTES.ADMIN_COMMISSIONS, label: 'العمولات', end: false },
    { to: ROUTES.ADMIN_PAYMENTS, label: 'المدفوعات والسحب', end: false },
    { to: ROUTES.ADMIN_SETTINGS, label: 'الإعدادات والتواصل', end: false },
  ];

  return (
    <div className="border-b border-white/10 bg-[#12233B]/70">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 overflow-x-auto">
        <nav aria-label="قائمة إدارة المنصة" className="flex items-center gap-2 py-2.5">
          {items.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `min-h-[40px] inline-flex items-center px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap shrink-0 transition ${
                  isActive
                    ? 'bg-[#C5A15B] text-[#0B172A] font-bold'
                    : 'text-[#CBD5E1] hover:bg-white/5 hover:text-white'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </div>
  );
};
