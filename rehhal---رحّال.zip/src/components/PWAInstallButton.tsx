import React, { useEffect, useState } from 'react';
import { Download, Monitor, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC<{ variant?: 'compact' | 'full' }> = ({
  variant = 'full',
}) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [showGuideModal, setShowGuideModal] = useState(false);

  useEffect(() => {
    if (!showGuideModal) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setShowGuideModal(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [showGuideModal]);

  // Suppress install CTA once running inside installed standalone / TWA window
  if (isInstalled) return null;

  const handleAction = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (accepted) return;
    }
    setShowGuideModal(true);
  };

  const buttonLabel = isInstallable
    ? 'تثبيت تطبيق رحّال'
    : isIOS
    ? 'تثبيت على آيفون'
    : isAndroid
    ? 'تثبيت التطبيق على أندرويد'
    : 'تثبيت التطبيق';

  const IconComponent = isIOS || isAndroid ? Smartphone : isInstallable ? Download : Monitor;

  return (
    <>
      <button
        type="button"
        onClick={handleAction}
        className={`inline-flex items-center justify-center gap-2 rounded-xl border border-[#C5A15B]/50 bg-[#C5A15B]/15 text-[#C5A15B] hover:bg-[#C5A15B] hover:text-[#0B172A] transition whitespace-nowrap shrink-0 min-h-[44px] ${
          variant === 'compact' ? 'px-3.5 py-2 text-xs font-semibold' : 'px-5 py-2.5 text-sm font-bold'
        }`}
      >
        <IconComponent className="w-4 h-4 shrink-0" />
        <span>{buttonLabel}</span>
      </button>

      {showGuideModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="pwa-install-guide-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
          onClick={() => setShowGuideModal(false)}
        >
          <div
            className="w-full max-w-md rounded-2xl bg-[#12233B] border border-[#C5A15B]/35 p-6 shadow-2xl space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between gap-3">
              <h3 id="pwa-install-guide-title" className="text-lg font-bold text-[#F4F1EA]">
                {isIOS
                  ? 'تثبيت رحّال على آيفون وآيباد'
                  : isAndroid
                  ? 'تثبيت رحّال على هاتف أندرويد'
                  : 'تثبيت رحّال على الكمبيوتر'}
              </h3>
              <button
                type="button"
                onClick={() => setShowGuideModal(false)}
                aria-label="إغلاق نافذة التثبيت"
                className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center text-[#9BA8BC] hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {isIOS ? (
              <ol className="space-y-2.5 text-sm text-[#CBD5E1] list-decimal list-inside leading-relaxed">
                <li>افتح منصة رحّال في متصفح <strong>Safari</strong>.</li>
                <li>اضغط على زر <strong>المشاركة (Share)</strong> في شريط المتصفح السفلي.</li>
                <li>اختر <strong>«إضافة إلى الشاشة الرئيسية» (Add to Home Screen)</strong> ثم اضغط «إضافة».</li>
              </ol>
            ) : isAndroid ? (
              <ol className="space-y-2.5 text-sm text-[#CBD5E1] list-decimal list-inside leading-relaxed">
                <li>افتح قائمة المتصفح (النقاط الثلاث أعلى يمين الشاشة في Chrome أو Samsung Internet).</li>
                <li>اختر <strong>«تثبيت التطبيق» (Install app)</strong> أو <strong>«إضافة إلى الشاشة الرئيسية»</strong>.</li>
                <li>أكّد التثبيت ليظهر تطبيق رحّال كتطبيق مستقل على جهازك.</li>
              </ol>
            ) : (
              <ol className="space-y-2.5 text-sm text-[#CBD5E1] list-decimal list-inside leading-relaxed">
                <li>في Chrome أو Microsoft Edge: اضغط أيقونة <strong>«تثبيت»</strong> في شريط العنوان أعلى المتصفح.</li>
                <li>في Safari على macOS: اختر من القائمة العلوية <strong>ملف (File) ← إضافة إلى Dock</strong>.</li>
                <li>سيُفتح تطبيق رحّال في نافذة مستقلة مع وصول سريع للرحلات وحجوزاتك.</li>
              </ol>
            )}

            <button
              type="button"
              onClick={() => setShowGuideModal(false)}
              className="w-full min-h-[44px] rounded-xl bg-[#C5A15B] text-[#0B172A] text-sm font-bold hover:opacity-90 transition"
            >
              فهمت ذلك
            </button>
          </div>
        </div>
      )}
    </>
  );
};
