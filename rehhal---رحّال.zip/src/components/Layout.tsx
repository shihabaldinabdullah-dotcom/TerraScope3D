import React, { useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import {
  CalendarCheck,
  Compass,
  ExternalLink,
  Home,
  LogOut,
  Mail,
  Menu,
  MessageCircle,
  Phone,
  Shield,
  User as UserIcon,
  X,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useReferral } from '../context/ReferralContext';
import { usePlatformSettings } from '../context/SettingsContext';
import { ROUTES } from '../routes/routeRegistry';
import type { ContactRequestMethod } from '../types';
import { ContactRequestModal } from './ContactRequestModal';
import { PWAInstallButton } from './PWAInstallButton';

function isValidExternalUrl(url?: string): boolean {
  if (!url) return false;
  try {
    const u = new URL(url.trim());
    return u.protocol === 'https:' || u.protocol === 'http:';
  } catch {
    return false;
  }
}

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, profile, isAdmin, logout } = useAuth();
  const { activeReferral } = useReferral();
  const { settings } = usePlatformSettings();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [contactModalOpen, setContactModalOpen] = useState(false);
  const [contactModalMethod, setContactModalMethod] = useState<ContactRequestMethod>('whatsapp');
  const location = useLocation();
  const navigate = useNavigate();

  const openContactModal = (method: ContactRequestMethod) => {
    setContactModalMethod(method);
    setContactModalOpen(true);
  };

  const handleLogout = async () => {
    await logout();
    setMobileMenuOpen(false);
    navigate(ROUTES.HOME);
  };

  const params = new URLSearchParams(location.search);
  const currentCat = params.get('category');
  const isPilgrimageActive =
    location.pathname === ROUTES.TRIPS &&
    (currentCat === 'pilgrimage' || currentCat === 'hajj' || currentCat === 'umrah');
  const isAllTripsActive = location.pathname === ROUTES.TRIPS && !isPilgrimageActive;

  // Top Bar Nav Links: الرئيسية، برامج الحج والعمرة، الرحلات، حجوزاتي، تواصل معنا (+ الإدارة للمشرف فقط)
  const navLinks = [
    { to: ROUTES.HOME, label: 'الرئيسية', active: location.pathname === ROUTES.HOME },
    {
      to: ROUTES.tripsWithCategory('pilgrimage'),
      label: 'برامج الحج والعمرة',
      active: isPilgrimageActive,
    },
    { to: ROUTES.TRIPS, label: 'الرحلات', active: isAllTripsActive },
    {
      to: ROUTES.MY_BOOKINGS,
      label: 'حجوزاتي',
      active: location.pathname.startsWith(ROUTES.MY_BOOKINGS),
    },
    {
      to: ROUTES.SUPPORT,
      label: 'تواصل معنا',
      active: location.pathname === ROUTES.SUPPORT,
    },
  ];

  const loginUrl = ROUTES.loginWithRedirect(`${location.pathname}${location.search}`);

  const socialItems = [
    { label: 'إكس (X)', url: settings.xUrl },
    { label: 'إنستغرام', url: settings.instagramUrl },
    { label: 'تيك توك', url: settings.tiktokUrl },
    { label: 'سناب شات', url: settings.snapchatUrl },
  ].filter((item) => isValidExternalUrl(item.url));

  return (
    <div className="min-h-screen flex flex-col bg-[#0B172A] text-[#F4F1EA] overflow-x-clip">
      {/* Top Bar Contract: 3 zones separated by gap-8 */}
      <header className="sticky top-0 z-40 h-16 border-b border-[#C5A15B]/20 bg-[#0B172A]/95 backdrop-blur-md">
        <div className="max-w-7xl mx-auto h-full px-4 sm:px-6 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <Link
            to={ROUTES.HOME}
            className="text-lg sm:text-xl font-bold tracking-tight text-[#F4F1EA] whitespace-nowrap shrink-0 flex items-center gap-2"
          >
            <span className="font-brand-latin text-[#C5A15B]">REHHAL</span>
            <span aria-hidden="true" className="text-[#C5A15B]/50">
              ·
            </span>
            <span>رحّال</span>
          </Link>

          {/* Zone 2: 5 concise single-line public nav links (+ الإدارة for Admin only) */}
          <nav
            aria-label="التنقل الرئيسي"
            className="hidden lg:flex items-center gap-6 text-sm font-medium"
          >
            {navLinks.map((item) => (
              <Link
                key={item.label}
                to={item.to}
                className={`whitespace-nowrap shrink-0 py-1 transition-colors border-b-2 ${
                  item.active
                    ? 'text-[#C5A15B] border-[#C5A15B]'
                    : 'text-[#CBD5E1] border-transparent hover:text-white hover:border-[#C5A15B]/40'
                }`}
              >
                {item.label}
              </Link>
            ))}
            {isAdmin && (
              <NavLink
                to={ROUTES.ADMIN}
                className={({ isActive }) =>
                  `whitespace-nowrap shrink-0 py-1 transition-colors border-b-2 ${
                    isActive
                      ? 'text-[#C5A15B] border-[#C5A15B]'
                      : 'text-[#CBD5E1] border-transparent hover:text-white hover:border-[#C5A15B]/40'
                  }`
                }
              >
                الإدارة
              </NavLink>
            )}
          </nav>

          {/* Zone 3: Install CTA + primary action on desktop + mobile drawer toggle */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <PWAInstallButton variant="compact" />
            {user ? (
              <Link
                to={ROUTES.PROFILE}
                className="hidden sm:inline-flex items-center gap-2 min-h-[40px] px-4 py-2 rounded-xl bg-[#12233B] border border-[#C5A15B]/40 text-sm font-semibold text-[#F4F1EA] hover:border-[#C5A15B] transition whitespace-nowrap shrink-0 max-w-[190px]"
              >
                <UserIcon className="w-4 h-4 text-[#C5A15B] shrink-0" />
                <span className="truncate">
                  {profile?.displayName || user.displayName || 'الملف الشخصي'}
                </span>
              </Link>
            ) : (
              <Link
                to={loginUrl}
                className="hidden sm:inline-flex items-center justify-center min-h-[40px] px-5 py-2 rounded-xl bg-[#C5A15B] text-[#0B172A] text-sm font-bold hover:opacity-90 transition whitespace-nowrap shrink-0"
              >
                تسجيل الدخول
              </Link>
            )}

            <button
              type="button"
              onClick={() => setMobileMenuOpen((v) => !v)}
              aria-label={mobileMenuOpen ? 'إغلاق القائمة' : 'فتح القائمة'}
              aria-expanded={mobileMenuOpen}
              className="lg:hidden min-h-[44px] min-w-[44px] inline-flex items-center justify-center rounded-xl border border-white/15 bg-[#12233B] text-[#F4F1EA] hover:border-[#C5A15B]/50 transition"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Active Referral Attribution Bar (only when ?ref= is active) */}
      {activeReferral && (
        <div className="bg-[#12233B] border-b border-[#C5A15B]/25 px-4 py-2 text-xs text-[#CBD5E1]">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
            <span>
              تم تفعيل رمز الإحالة الموثق:{' '}
              <strong className="text-[#C5A15B] font-mono-num">{activeReferral.code}</strong>
              {' · '}
              <span>{activeReferral.marketerName}</span>
            </span>
            <span className="text-[#9BA8BC]">يُحفظ رمز الإحالة تلقائياً حتى إتمام الحجز</span>
          </div>
        </div>
      )}

      {/* Mobile Slide-Down Menu Drawer (Public Links Only, Zero Marketers Promotion) */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#12233B] border-b border-[#C5A15B]/25 px-4 py-4 space-y-2">
          {navLinks.map((item) => (
            <Link
              key={item.label}
              to={item.to}
              onClick={() => setMobileMenuOpen(false)}
              className={`block min-h-[44px] px-4 py-2.5 rounded-xl text-sm font-semibold ${
                item.active ? 'bg-[#C5A15B] text-[#0B172A]' : 'text-[#F4F1EA] hover:bg-white/5'
              }`}
            >
              {item.label}
            </Link>
          ))}
          {isAdmin && (
            <NavLink
              to={ROUTES.ADMIN}
              onClick={() => setMobileMenuOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-2 min-h-[44px] px-4 py-2.5 rounded-xl text-sm font-semibold ${
                  isActive ? 'bg-[#C5A15B] text-[#0B172A]' : 'text-[#C5A15B] hover:bg-white/5'
                }`
              }
            >
              <Shield className="w-4 h-4" />
              <span>لوحة الإدارة</span>
            </NavLink>
          )}
          <div className="pt-2 border-t border-white/10 flex flex-col gap-2">
            <PWAInstallButton variant="full" />
            {user ? (
              <>
                <Link
                  to={ROUTES.PROFILE}
                  onClick={() => setMobileMenuOpen(false)}
                  className="min-h-[44px] flex items-center justify-center gap-2 rounded-xl border border-[#C5A15B]/40 text-sm font-semibold text-[#F4F1EA]"
                >
                  <UserIcon className="w-4 h-4 text-[#C5A15B]" />
                  <span>الملف الشخصي</span>
                </Link>
                <button
                  type="button"
                  onClick={handleLogout}
                  className="min-h-[44px] flex items-center justify-center gap-2 rounded-xl border border-red-500/40 text-sm font-semibold text-red-300"
                >
                  <LogOut className="w-4 h-4" />
                  <span>تسجيل الخروج</span>
                </button>
              </>
            ) : (
              <Link
                to={loginUrl}
                onClick={() => setMobileMenuOpen(false)}
                className="min-h-[44px] flex items-center justify-center rounded-xl bg-[#C5A15B] text-[#0B172A] text-sm font-bold"
              >
                تسجيل الدخول
              </Link>
            )}
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 pb-24 lg:pb-14">{children}</main>

      {/* Official Clean Footer — Grouped Without Nav Link Duplication */}
      <footer className="border-t border-white/10 bg-[#0B172A] py-12 px-4 sm:px-6 mb-16 lg:mb-0">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-10 text-sm">
          {/* Column 1: About REHHAL */}
          <div className="space-y-4">
            <div className="font-bold text-lg text-[#F4F1EA]">
              <span className="font-brand-latin text-[#C5A15B]">REHHAL</span> · رحّال
            </div>
            <p className="text-[#CBD5E1] leading-relaxed max-w-sm">
              {settings.aboutText ||
                'منصة رحّال متخصصة في تنظيم وتقديم برامج الحج والعمرة وتسهيل الوصول إلى تفاصيل الرحلات والحجز بوضوح وموثوقية.'}
            </p>
          </div>

          {/* Column 2: روابط المنصة (Platform Info Only, No Duplicated Nav Links) */}
          <div className="space-y-3">
            <h4 className="font-bold text-[#FFFFFF]">روابط المنصة</h4>
            <ul className="space-y-2.5 text-[#CBD5E1]">
              <li>
                <Link to={ROUTES.ABOUT} className="hover:text-[#C5A15B] transition-colors">
                  من نحن
                </Link>
              </li>
              <li>
                <Link to={ROUTES.PRIVACY} className="hover:text-[#C5A15B] transition-colors">
                  سياسة الخصوصية
                </Link>
              </li>
              <li>
                <Link to={ROUTES.TERMS} className="hover:text-[#C5A15B] transition-colors">
                  الشروط والأحكام
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 3: المساعدة والتواصل */}
          <div className="space-y-4">
            <h4 className="font-bold text-[#FFFFFF]">المساعدة والتواصل</h4>
            <div className="space-y-3 text-[#CBD5E1]">
              <div>
                <button
                  type="button"
                  onClick={() => openContactModal('whatsapp')}
                  className="min-h-[44px] inline-flex items-center gap-2 rounded-xl bg-emerald-600/20 border border-emerald-500/50 px-5 py-2.5 text-sm font-bold text-emerald-200 hover:bg-emerald-600/30 transition"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span>اطلب التواصل عبر واتساب</span>
                </button>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => openContactModal('phone')}
                  className="min-h-[38px] inline-flex items-center gap-1.5 rounded-lg border border-white/20 bg-[#12233B] px-3.5 py-1.5 text-xs font-semibold text-[#F4F1EA] hover:border-[#C5A15B] hover:text-[#C5A15B] transition"
                >
                  <Phone className="w-3.5 h-3.5 text-[#C5A15B]" />
                  <span>اطلب التواصل</span>
                </button>
              </div>

              {settings.supportEmail && (
                <div>
                  <a
                    href={`mailto:${settings.supportEmail}`}
                    className="inline-flex items-center gap-2 text-xs text-[#CBD5E1] hover:text-[#C5A15B] transition"
                  >
                    <Mail className="w-3.5 h-3.5 text-[#C5A15B]" />
                    <span dir="ltr">{settings.supportEmail}</span>
                  </a>
                </div>
              )}

              {socialItems.length > 0 && (
                <div className="pt-1 flex flex-wrap items-center gap-3 text-xs">
                  {socialItems.map((social) => (
                    <a
                      key={social.label}
                      href={social.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[#CBD5E1] hover:text-[#C5A15B] transition underline-offset-4 hover:underline"
                    >
                      <span>{social.label}</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto mt-10 pt-6 border-t border-white/10 text-center sm:text-right text-xs text-[#9BA8BC]">
          <span>© 2026 REHHAL · رحّال. جميع الحقوق محفوظة.</span>
        </div>
      </footer>

      {/* Mobile Bottom Thumb-Zone Navigation Bar (<= 15% sticky height cap) */}
      <nav
        aria-label="التنقل السفلي للهاتف"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0B172A]/95 backdrop-blur-md border-t border-[#C5A15B]/25 pb-safe"
      >
        <div className="grid grid-cols-4 h-16 items-center">
          <NavLink
            to={ROUTES.HOME}
            end
            className={({ isActive }) =>
              `flex flex-col items-center justify-center min-h-[44px] gap-1 text-[11px] font-medium ${
                isActive ? 'text-[#C5A15B]' : 'text-[#9BA8BC]'
              }`
            }
          >
            <Home className="w-5 h-5" />
            <span>الرئيسية</span>
          </NavLink>
          <Link
            to={ROUTES.TRIPS}
            className={`flex flex-col items-center justify-center min-h-[44px] gap-1 text-[11px] font-medium ${
              location.pathname === ROUTES.TRIPS || location.pathname.startsWith('/trip')
                ? 'text-[#C5A15B]'
                : 'text-[#9BA8BC]'
            }`}
          >
            <Compass className="w-5 h-5" />
            <span>الرحلات</span>
          </Link>
          <NavLink
            to={ROUTES.MY_BOOKINGS}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center min-h-[44px] gap-1 text-[11px] font-medium ${
                isActive ? 'text-[#C5A15B]' : 'text-[#9BA8BC]'
              }`
            }
          >
            <CalendarCheck className="w-5 h-5" />
            <span>حجوزاتي</span>
          </NavLink>
          <NavLink
            to={ROUTES.PROFILE}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center min-h-[44px] gap-1 text-[11px] font-medium ${
                isActive ? 'text-[#C5A15B]' : 'text-[#9BA8BC]'
              }`
            }
          >
            <UserIcon className="w-5 h-5" />
            <span>حسابي</span>
          </NavLink>
        </div>
      </nav>

      <ContactRequestModal
        open={contactModalOpen}
        initialMethod={contactModalMethod}
        onClose={() => setContactModalOpen(false)}
      />
    </div>
  );
};
