import React, { useEffect, useRef, useState } from 'react';
import { CheckCircle2, MessageCircle, Phone, Send, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { usePlatformSettings } from '../context/SettingsContext';
import { useToast } from '../context/ToastContext';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { submitContactRequest } from '../services/firestoreService';
import type { ContactRequestMethod } from '../types';

interface ContactRequestModalProps {
  open: boolean;
  initialMethod?: ContactRequestMethod;
  onClose: () => void;
}

export const ContactRequestModal: React.FC<ContactRequestModalProps> = ({
  open,
  initialMethod = 'whatsapp',
  onClose,
}) => {
  const { user, profile } = useAuth();
  const { settings } = usePlatformSettings();
  const { showToast } = useToast();
  const isOnline = useOnlineStatus();

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [preferredMethod, setPreferredMethod] = useState<ContactRequestMethod>(initialMethod);
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const submitLockRef = useRef(false);

  useEffect(() => {
    if (open) {
      setPreferredMethod(initialMethod);
      setError(null);
      setSubmitted(false);
      if (user) {
        setName((prev) => prev || profile?.displayName || user.displayName || '');
        setPhone((prev) => prev || profile?.phone || '');
      }
    }
  }, [open, initialMethod, user, profile]);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !submitting) {
        onClose();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open, submitting, onClose]);

  if (!open) return null;

  const officialWhatsapp = (settings.whatsappNumber || settings.supportPhone || '').trim();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitLockRef.current || submitting) return;

    if (!isOnline) {
      setError('يتطلب إرسال طلب التواصل اتصالاً بالإنترنت.');
      return;
    }

    const cleanName = name.trim();
    const cleanPhone = phone.trim();
    const digits = cleanPhone.replace(/[^\d]/g, '');

    if (cleanName.length < 2) {
      setError('يرجى إدخال الاسم الكامل بشكل صحيح (حرفين على الأقل).');
      return;
    }

    if (!/^[+0-9\s\-()]{7,32}$/.test(cleanPhone) || digits.length < 8) {
      setError('يرجى إدخال رقم هاتف صحيح (8 أرقام على الأقل).');
      return;
    }

    setError(null);
    setSubmitting(true);
    submitLockRef.current = true;

    try {
      await submitContactRequest({
        name: cleanName,
        phone: cleanPhone,
        preferredMethod,
        message,
        officialWhatsapp: preferredMethod === 'whatsapp' ? officialWhatsapp : '',
        userId: user?.uid || null,
      });
      setSubmitted(true);
      setMessage('');
      showToast('تم إرسال طلبك بنجاح، وسيقوم فريق رحّال بالتواصل معك في أقرب وقت', 'success');
    } catch (err) {
      const msg =
        err instanceof Error && !err.message.startsWith('{')
          ? err.message
          : 'تعذر إرسال طلب التواصل حالياً، يرجى المحاولة مرة أخرى.';
      setError(msg);
      showToast(msg, 'error');
    } finally {
      setSubmitting(false);
      submitLockRef.current = false;
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="contact-modal-title"
      onClick={() => {
        if (!submitting) onClose();
      }}
    >
      <div
        className="w-full sm:max-w-lg rounded-t-2xl sm:rounded-2xl bg-[#12233B] border border-[#C5A15B]/35 p-6 sm:p-7 space-y-5 max-h-[92vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <h2 id="contact-modal-title" className="text-xl font-bold text-[#F4F1EA]">
              اطلب التواصل مع فريق رحّال
            </h2>
            <p className="text-xs text-[#9BA8BC] mt-1">
              اترك بياناتك وسيتواصل معك فريق رحّال عبر الوسيلة التي تفضلها
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              if (!submitting) onClose();
            }}
            aria-label="إغلاق نافذة طلب التواصل"
            className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-xl border border-white/15 bg-[#0B172A] text-[#CBD5E1] hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {submitted ? (
          <div className="rounded-2xl bg-[#0B172A] border border-emerald-500/40 p-6 text-center space-y-4">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
            <p className="text-base font-bold text-[#F4F1EA] leading-relaxed">
              تم إرسال طلبك بنجاح، وسيقوم فريق رحّال بالتواصل معك في أقرب وقت
            </p>
            <p className="text-xs text-[#9BA8BC]">
              وسيلة التواصل المختارة:{' '}
              <span className="text-[#C5A15B] font-semibold">
                {preferredMethod === 'whatsapp' ? 'واتساب' : 'اتصال هاتفي'}
              </span>
            </p>
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] w-full rounded-xl bg-[#C5A15B] text-[#0B172A] px-5 py-2.5 text-sm font-bold hover:opacity-90 transition"
            >
              إغلاق
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div
                role="alert"
                className="rounded-xl bg-red-500/15 border border-red-500/40 px-4 py-2.5 text-xs text-red-200"
              >
                {error}
              </div>
            )}

            <div>
              <label htmlFor="crq-name" className="block text-xs font-semibold text-[#CBD5E1] mb-1.5">
                الاسم *
              </label>
              <input
                id="crq-name"
                type="text"
                required
                minLength={2}
                maxLength={120}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="الاسم الكامل"
                className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA] focus:border-[#C5A15B] focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="crq-phone" className="block text-xs font-semibold text-[#CBD5E1] mb-1.5">
                رقم الهاتف *
              </label>
              <input
                id="crq-phone"
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="05XXXXXXXX أو +9665XXXXXXXX"
                dir="ltr"
                className="w-full min-h-[44px] rounded-xl bg-[#0B172A] border border-white/15 px-3.5 text-sm text-[#F4F1EA] font-mono-num focus:border-[#C5A15B] focus:outline-none text-right"
              />
            </div>

            <div>
              <span className="block text-xs font-semibold text-[#CBD5E1] mb-2">
                وسيلة التواصل المفضلة *
              </span>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setPreferredMethod('whatsapp')}
                  className={`min-h-[46px] flex items-center justify-center gap-2 rounded-xl border px-3 py-2 text-xs sm:text-sm font-semibold transition ${
                    preferredMethod === 'whatsapp'
                      ? 'border-[#C5A15B] bg-[#C5A15B]/15 text-[#F4F1EA]'
                      : 'border-white/15 bg-[#0B172A] text-[#9BA8BC] hover:text-white'
                  }`}
                >
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span>واتساب</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreferredMethod('phone')}
                  className={`min-h-[46px] flex items-center justify-center gap-2 rounded-xl border px-3 py-2 text-xs sm:text-sm font-semibold transition ${
                    preferredMethod === 'phone'
                      ? 'border-[#C5A15B] bg-[#C5A15B]/15 text-[#F4F1EA]'
                      : 'border-white/15 bg-[#0B172A] text-[#9BA8BC] hover:text-white'
                  }`}
                >
                  <Phone className="w-4 h-4 text-[#C5A15B]" />
                  <span>اتصال هاتفي</span>
                </button>
              </div>
              {preferredMethod === 'whatsapp' && officialWhatsapp && (
                <p className="text-[11px] text-[#9BA8BC] mt-2">
                  سيتواصل معك فريق رحّال من رقم الواتساب الرسمي:{' '}
                  <span className="font-mono-num text-[#CBD5E1]" dir="ltr">
                    {officialWhatsapp}
                  </span>
                </p>
              )}
            </div>

            <div>
              <label
                htmlFor="crq-message"
                className="block text-xs font-semibold text-[#CBD5E1] mb-1.5"
              >
                سبب طلب التواصل أو رسالة مختصرة (اختياري)
              </label>
              <textarea
                id="crq-message"
                rows={3}
                maxLength={500}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="مثال: استفسار عن باقة عمرة أو موعد محدد..."
                className="w-full rounded-xl bg-[#0B172A] border border-white/15 px-3.5 py-2.5 text-sm text-[#F4F1EA] focus:border-[#C5A15B] focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full min-h-[48px] inline-flex items-center justify-center gap-2 rounded-xl bg-[#C5A15B] text-[#0B172A] px-6 py-2.5 text-sm font-bold hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition"
            >
              <Send className="w-4 h-4" />
              <span>{submitting ? 'جاري إرسال طلب التواصل...' : 'إرسال طلب التواصل'}</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
