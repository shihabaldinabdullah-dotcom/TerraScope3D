/**
 * Centralized Route Registry for REHHAL (رحّال).
 * All navigation links, redirects, and route definitions MUST reference this file.
 */
export const ROUTES = {
  HOME: '/',
  TRIPS: '/trips',
  TRIP_DETAIL_PATTERN: '/trip/:tripId',
  BOOKING_DETAIL_PATTERN: '/booking/:bookingId',
  MY_BOOKINGS: '/my-bookings',
  PROFILE: '/profile',
  SUPPORT: '/support',
  ABOUT: '/about',
  PRIVACY: '/privacy',
  TERMS: '/terms',
  LOGIN: '/login',

  // Partner / Marketer Workspace (accessed exclusively via Profile -> التسويق بالعمولة, protected by RequireMarketer)
  PARTNERS: '/partners',
  PARTNERS_REGISTER: '/partners/register',
  PARTNERS_DASHBOARD: '/partners/dashboard',
  PARTNERS_REFERRALS: '/partners/referrals',
  PARTNERS_EARNINGS: '/partners/earnings',
  PARTNERS_BOOKINGS: '/partners/bookings',
  PARTNERS_PAYOUTS: '/partners/payouts',

  // Admin Console
  ADMIN: '/admin',
  ADMIN_TRIPS: '/admin/trips',
  ADMIN_BOOKINGS: '/admin/bookings',
  ADMIN_CUSTOMERS: '/admin/customers',
  ADMIN_MARKETERS: '/admin/marketers',
  ADMIN_COMMISSIONS: '/admin/commissions',
  ADMIN_PAYMENTS: '/admin/payments',
  ADMIN_CONTACTS: '/admin/contacts',
  ADMIN_REVIEWS: '/admin/reviews',
  ADMIN_SETTINGS: '/admin/settings',

  // Route Helpers
  tripsWithCategory: (category: string): string =>
    `/trips?category=${encodeURIComponent(category)}`,

  profileAffiliate: (): string => '/profile?tab=affiliate',
  profilePlatformReview: (): string => '/profile?tab=review',

  tripDetail: (tripId: string, refCode?: string | null): string => {
    const base = `/trip/${encodeURIComponent(tripId)}`;
    if (refCode && refCode.trim()) {
      return `${base}?ref=${encodeURIComponent(refCode.trim().toUpperCase())}`;
    }
    return base;
  },

  bookingDetail: (bookingId: string): string => `/booking/${encodeURIComponent(bookingId)}`,

  loginWithRedirect: (returnTo: string): string =>
    `/login?redirect=${encodeURIComponent(returnTo)}`,

  absoluteTripShareUrl: (tripId: string, refCode: string): string => {
    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    return `${origin}${ROUTES.tripDetail(tripId, refCode)}`;
  },
} as const;

export const LEGACY_HASH_ROUTE_MAP: Record<string, string> = {
  '#/': ROUTES.HOME,
  '#/trips': ROUTES.TRIPS,
  '#/my-bookings': ROUTES.MY_BOOKINGS,
  '#/profile': ROUTES.PROFILE,
  '#/support': ROUTES.SUPPORT,
  '#/about': ROUTES.ABOUT,
  '#/privacy': ROUTES.PRIVACY,
  '#/terms': ROUTES.TERMS,
  '#/partners': ROUTES.profileAffiliate(),
  '#/partners/register': ROUTES.profileAffiliate(),
  '#/partners/dashboard': ROUTES.PARTNERS_DASHBOARD,
  '#/partners/referrals': ROUTES.PARTNERS_REFERRALS,
  '#/partners/earnings': ROUTES.PARTNERS_EARNINGS,
  '#/partners/bookings': ROUTES.PARTNERS_BOOKINGS,
  '#/partners/payouts': ROUTES.PARTNERS_PAYOUTS,
  '#/admin': ROUTES.ADMIN,
};
