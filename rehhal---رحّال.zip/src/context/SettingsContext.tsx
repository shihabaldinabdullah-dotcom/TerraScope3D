import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import {
  DEFAULT_PLATFORM_SETTINGS,
  fetchPlatformSettings,
} from '../services/firestoreService';
import type { PlatformSettings } from '../types';

interface SettingsContextValue {
  settings: PlatformSettings;
  refreshSettings: () => Promise<void>;
}

const SettingsContext = createContext<SettingsContextValue>({
  settings: DEFAULT_PLATFORM_SETTINGS,
  refreshSettings: async () => undefined,
});

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<PlatformSettings>(DEFAULT_PLATFORM_SETTINGS);

  const refreshSettings = useCallback(async () => {
    const latest = await fetchPlatformSettings();
    setSettings(latest);
  }, []);

  useEffect(() => {
    refreshSettings().catch(() => undefined);
  }, [refreshSettings]);

  return (
    <SettingsContext.Provider value={{ settings, refreshSettings }}>
      {children}
    </SettingsContext.Provider>
  );
};

export function usePlatformSettings() {
  return useContext(SettingsContext);
}
