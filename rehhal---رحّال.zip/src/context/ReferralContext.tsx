import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase/firebase';

export interface ActiveReferral {
  code: string;
  marketerId: string;
  marketerName: string;
  commissionRate: number;
  signature: string;
  capturedAt: number;
  tripId?: string;
}

interface ReferralContextValue {
  activeReferral: ActiveReferral | null;
  verifying: boolean;
  referralError: string | null;
  captureReferralCode: (rawCode: string, tripId?: string) => Promise<ActiveReferral | null>;
  clearReferral: () => void;
  verifyBeforeBooking: (currentUserId: string) => Promise<ActiveReferral | null>;
}

const STORAGE_KEY = 'rehhal_active_referral_v1';
const SESSION_KEY_NAME = 'rehhal_visitor_session_v1';
const REFERRAL_TTL_MS = 1000 * 60 * 60 * 24 * 7; // 7 days attribution window

function getOrCreateVisitorSession(): string {
  try {
    let existing = window.localStorage.getItem(SESSION_KEY_NAME);
    if (!existing) {
      existing = `vis_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
      window.localStorage.setItem(SESSION_KEY_NAME, existing);
    }
    return existing;
  } catch {
    return `vis_fallback_${Date.now().toString(36)}`;
  }
}

function readStoredReferral(): ActiveReferral | null {
  try {
    const raw =
      window.sessionStorage.getItem(STORAGE_KEY) || window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as ActiveReferral;
    if (!parsed.code || !parsed.marketerId || !parsed.signature) return null;
    if (Date.now() - parsed.capturedAt > REFERRAL_TTL_MS) {
      window.sessionStorage.removeItem(STORAGE_KEY);
      window.localStorage.removeItem(STORAGE_KEY);
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

function persistReferral(ref: ActiveReferral | null) {
  try {
    if (!ref) {
      window.sessionStorage.removeItem(STORAGE_KEY);
      window.localStorage.removeItem(STORAGE_KEY);
      return;
    }
    const serialized = JSON.stringify(ref);
    window.sessionStorage.setItem(STORAGE_KEY, serialized);
    window.localStorage.setItem(STORAGE_KEY, serialized);
  } catch {
    // Ignore storage quota errors
  }
}

const ReferralContext = createContext<ReferralContextValue | undefined>(undefined);

export const ReferralProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const [activeReferral, setActiveReferral] = useState<ActiveReferral | null>(() =>
    typeof window !== 'undefined' ? readStoredReferral() : null
  );
  const [verifying, setVerifying] = useState(false);
  const [referralError, setReferralError] = useState<string | null>(null);

  const captureReferralCode = useCallback(async (rawCode: string, tripId?: string) => {
    const code = rawCode.trim().toUpperCase();
    if (!/^[A-Z0-9_\-]{3,32}$/.test(code)) {
      setReferralError('صيغة كود الإحالة غير صالحة');
      return null;
    }

    setVerifying(true);
    setReferralError(null);

    try {
      const sessionKey = getOrCreateVisitorSession();
      // Step 1: Server-side validation & click deduplication + HMAC attribution token
      const res = await fetch('/api/referrals/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, tripId: tripId || 'direct', sessionKey }),
      });

      if (res.ok) {
        const data = (await res.json()) as {
          valid: boolean;
          code: string;
          marketerId: string;
          marketerName: string;
          commissionRate: number;
          signature: string;
        };
        if (data.valid) {
          const refObj: ActiveReferral = {
            code: data.code,
            marketerId: data.marketerId,
            marketerName: data.marketerName,
            commissionRate: data.commissionRate,
            signature: data.signature,
            capturedAt: Date.now(),
            tripId,
          };
          setActiveReferral(refObj);
          persistReferral(refObj);
          return refObj;
        }
      }

      // Step 2: Check Firestore directly in case code was activated in another tab
      const snap = await getDoc(doc(db, 'referral_codes', code));
      if (snap.exists() && snap.data().active === true) {
        const retryRes = await fetch('/api/referrals/track', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ code, tripId: tripId || 'direct', sessionKey }),
        });
        if (retryRes.ok) {
          const retryData = await retryRes.json();
          const refObj: ActiveReferral = {
            code: retryData.code,
            marketerId: retryData.marketerId,
            marketerName: retryData.marketerName,
            commissionRate: retryData.commissionRate,
            signature: retryData.signature,
            capturedAt: Date.now(),
            tripId,
          };
          setActiveReferral(refObj);
          persistReferral(refObj);
          return refObj;
        }
      }

      setReferralError('كود الإحالة غير موجود أو غير مفعل حالياً');
      return null;
    } catch {
      setReferralError('تعذر التحقق من كود الإحالة مع الخادم');
      return null;
    } finally {
      setVerifying(false);
    }
  }, []);

  // Automatically capture ?ref= from any route or deep link and preserve across login/navigation/refresh
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const refParam = params.get('ref');
    if (refParam) {
      const tripMatch = location.pathname.match(/^\/trip\/([^/]+)/);
      const tripId = tripMatch ? decodeURIComponent(tripMatch[1]) : undefined;
      captureReferralCode(refParam, tripId);
    } else {
      // Ensure state stays hydrated across refreshes
      const stored = readStoredReferral();
      if (stored && !activeReferral) {
        setActiveReferral(stored);
      }
    }
  }, [location.pathname, location.search, captureReferralCode, activeReferral]);

  const clearReferral = useCallback(() => {
    setActiveReferral(null);
    persistReferral(null);
    setReferralError(null);
  }, []);

  const verifyBeforeBooking = useCallback(
    async (currentUserId: string): Promise<ActiveReferral | null> => {
      const current = activeReferral || readStoredReferral();
      if (!current) return null;

      if (current.marketerId === currentUserId) {
        return null; // Self-referral is never attributed
      }

      const res = await fetch('/api/referrals/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: current.code,
          marketerId: current.marketerId,
          signature: current.signature,
          currentUserId,
        }),
      });

      if (!res.ok) {
        return null;
      }

      const data = await res.json();
      if (!data.valid) return null;

      return current;
    },
    [activeReferral]
  );

  return (
    <ReferralContext.Provider
      value={{
        activeReferral,
        verifying,
        referralError,
        captureReferralCode,
        clearReferral,
        verifyBeforeBooking,
      }}
    >
      {children}
    </ReferralContext.Provider>
  );
};

export function useReferral() {
  const ctx = useContext(ReferralContext);
  if (!ctx) throw new Error('useReferral must be used within ReferralProvider');
  return ctx;
}
