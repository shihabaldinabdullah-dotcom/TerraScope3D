import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  serverTimestamp,
  setDoc,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import {
  auth,
  BOOTSTRAP_ADMIN_EMAIL,
  db,
  googleProvider,
  handleFirestoreError,
  OperationType,
} from '../firebase/firebase';
import { CURATED_TRIPS } from '../data/curatedTrips';
import type { MarketerProfile, PlatformSettings, UserProfile } from '../types';

interface AuthContextValue {
  user: User | null;
  profile: UserProfile | null;
  marketer: MarketerProfile | null;
  isAdmin: boolean;
  isMarketer: boolean;
  loading: boolean;
  signingIn: boolean;
  signInWithGoogle: () => Promise<User | null>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  updateProfileInfo: (updates: { displayName: string; phone: string; city: string }) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

async function seedCatalogIfAdmin(uid: string, email: string) {
  try {
    const tripsSnap = await getDocs(collection(db, 'trips'));
    const existingIds = new Set(tripsSnap.docs.map((d) => d.id));
    const missingTrips = CURATED_TRIPS.filter((t) => !existingIds.has(t.id));

    if (tripsSnap.empty || missingTrips.length > 0) {
      const batch = writeBatch(db);
      for (const trip of missingTrips) {
        batch.set(doc(db, 'trips', trip.id), {
          ...trip,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      if (tripsSnap.empty) {
        batch.set(doc(db, 'settings', 'platform'), {
          commissionRate: 0.08,
          minPayoutAmount: 200,
          currency: 'EGP',
          supportEmail: 'support@rehhal.sa',
          supportPhone: '+966500000100',
          whatsappNumber: '+966500000100',
          aboutText:
            'منصة رحّال (REHHAL) متخصصة في تنظيم وتقديم برامج الحج والعمرة وتسهيل الوصول إلى تفاصيل الرحلات وإتمام الحجز بوضوح وموثوقية.',
          xUrl: '',
          instagramUrl: '',
          tiktokUrl: '',
          snapchatUrl: '',
          updatedAt: serverTimestamp(),
        } satisfies PlatformSettings);
        batch.set(doc(db, 'admins', uid), {
          uid,
          email,
          addedBy: 'bootstrap',
          createdAt: serverTimestamp(),
        });
      }
      await batch.commit();
    }
  } catch (err) {
    console.warn('Admin seed skipped or failed:', err);
  }
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [marketer, setMarketer] = useState<MarketerProfile | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [signingIn, setSigningIn] = useState(false);

  const loadUserRecords = useCallback(async (firebaseUser: User) => {
    const userRef = doc(db, 'users', firebaseUser.uid);
    let userProfile: UserProfile | null = null;

    try {
      const snap = await getDoc(userRef);
      if (snap.exists()) {
        userProfile = snap.data() as UserProfile;
      } else {
        const initialProfile: UserProfile = {
          uid: firebaseUser.uid,
          email: firebaseUser.email || 'user@rehhal.sa',
          displayName: firebaseUser.displayName || 'مسافر رحّال',
          phone: '',
          city: '',
          role: 'customer',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        };
        await setDoc(userRef, initialProfile);
        userProfile = initialProfile;
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${firebaseUser.uid}`);
    }

    let adminFlag =
      Boolean(firebaseUser.emailVerified) &&
      firebaseUser.email?.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase();

    if (!adminFlag) {
      try {
        const adminSnap = await getDoc(doc(db, 'admins', firebaseUser.uid));
        if (adminSnap.exists()) {
          adminFlag = true;
        }
      } catch {
        // Non-admin user
      }
    }

    if (adminFlag && firebaseUser.email) {
      await seedCatalogIfAdmin(firebaseUser.uid, firebaseUser.email);
    }

    let marketerProfile: MarketerProfile | null = null;
    try {
      const mSnap = await getDoc(doc(db, 'marketers', firebaseUser.uid));
      if (mSnap.exists()) {
        marketerProfile = mSnap.data() as MarketerProfile;
        // Sync active marketer referral code with Express server verification registry
        if (marketerProfile.status === 'active') {
          const token = await firebaseUser.getIdToken().catch(() => '');
          if (token) {
            fetch('/api/referrals/register', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${token}`,
              },
              body: JSON.stringify({
                code: marketerProfile.referralCode,
                marketerId: marketerProfile.uid,
                marketerName: marketerProfile.fullName,
                commissionRate: marketerProfile.commissionRate,
              }),
            }).catch(() => undefined);
          }
        }
      }
    } catch {
      // Not a marketer yet
    }

    setProfile(userProfile);
    setMarketer(marketerProfile);
    setIsAdmin(adminFlag);
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        try {
          await loadUserRecords(firebaseUser);
        } catch (err) {
          console.error(err);
        }
      } else {
        setProfile(null);
        setMarketer(null);
        setIsAdmin(false);
      }
      setLoading(false);
    });
    return () => unsub();
  }, [loadUserRecords]);

  const signInWithGoogle = useCallback(async () => {
    setSigningIn(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      if (result.user) {
        await loadUserRecords(result.user);
      }
      return result.user;
    } finally {
      setSigningIn(false);
    }
  }, [loadUserRecords]);

  const logout = useCallback(async () => {
    await signOut(auth);
    setUser(null);
    setProfile(null);
    setMarketer(null);
    setIsAdmin(false);
  }, []);

  const refreshProfile = useCallback(async () => {
    if (auth.currentUser) {
      await loadUserRecords(auth.currentUser);
    }
  }, [loadUserRecords]);

  const updateProfileInfo = useCallback(
    async (updates: { displayName: string; phone: string; city: string }) => {
      if (!auth.currentUser) throw new Error('يجب تسجيل الدخول أولاً');
      const userRef = doc(db, 'users', auth.currentUser.uid);
      try {
        await updateDoc(userRef, {
          displayName: updates.displayName.trim(),
          phone: updates.phone.trim(),
          city: updates.city.trim(),
          updatedAt: serverTimestamp(),
        });
        await loadUserRecords(auth.currentUser);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${auth.currentUser.uid}`);
      }
    },
    [loadUserRecords]
  );

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        marketer,
        isAdmin,
        isMarketer: Boolean(marketer && marketer.status === 'active'),
        loading,
        signingIn,
        signInWithGoogle,
        logout,
        refreshProfile,
        updateProfileInfo,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
