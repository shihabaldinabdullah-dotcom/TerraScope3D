# REHHAL Security Specification (Phase 0 — Payload-First Security TDD)

## 1. Data Invariants
1. **Role Isolation**: Users cannot self-assign `role: "admin"` or `"marketer"` on `users/{userId}` creation or update. Only `admins/{uid}` documents or the verified bootstrap admin email (`email_verified == true`) grant admin access. Marketer applications start strictly as `status: "pending"` with `referral_codes/{code}.active == false` until approved by Admin.
2. **PII Protection**: `users/{userId}`, `marketers/{marketerId}`, `bookings/{bookingId}`, `payout_requests/{payoutId}`, `support_tickets/{ticketId}`, and `platform_reviews/{userId}` are strictly restricted on `get` and `list` to the owning user (`uid == request.auth.uid`), the attributed marketer (for `bookings` / `commissions`), or `isAdmin()`. Blanket `isSignedIn()` reads are prohibited.
3. **Immutable Referral Attribution**: Once a booking is created with `marketerId` and `referralCode`, neither the customer nor any non-admin user can alter `marketerId`, `referralCode`, `commissionAmount`, `commissionStatus`, or `totalAmount`.
4. **No Self-Referral Fraud**: A user cannot attribute their own booking to themselves (`marketerId != request.auth.uid`).
5. **Financial Integrity**: Marketers cannot modify their own `totalEarnings`, `availableBalance`, `pendingBalance`, `commissionRate`, or `payout_requests/{id}.status`. Only Admins can approve/pay commissions and payouts.
6. **Review Separation & Completed-Booking Enforcement**:
   - `platform_reviews/{userId}` stores overall platform reviews submitted exclusively inside Profile by the authenticated owner (one document per user) and reviewed by Admin—never mixed with trip reviews.
   - `trip_reviews/trv_{bookingId}` strictly enforces via `get(/databases/.../bookings/{bookingId})` that the reviewer owns the booking, the booking belongs to the reviewed `tripId`, and `booking.status == 'completed'`, preventing unverified browsing-only reviews and duplicate per-booking reviews.
7. **Temporal Integrity**: All `createdAt` and `updatedAt` timestamps on Firestore documents must equal `request.time`.
8. **Path Variable & Payload Bounds**: Every document ID must satisfy `^[a-zA-Z0-9_\-]+$` (`<= 128` chars), and every string/array field enforces explicit size bounds.

## 2. The Adversarial Payloads (Must Return PERMISSION_DENIED)
1. **Self-Admin Escalation**: `POST /users/{uid}` with `role: "admin"`.
2. **Unverified Admin Email Spoof**: Request with matching admin email where `email_verified: false`.
3. **Shadow Field Injection**: `POST /bookings/{id}` adding undocumented ghost field `isFreeOverride: true`.
4. **Cross-User Booking Read**: Customer B attempting `get` or `list` on Customer A's booking.
5. **Marketer Attribution Hijack**: Customer updating `bookings/{id}` after creation to swap `marketerId` to another user.
6. **Self-Referral Booking**: User creating `bookings/{id}` where `marketerId == request.auth.uid`.
7. **Fake Referral Code**: User creating `bookings/{id}` with a non-existent or inactive `referralCode`.
8. **Self-Approved Payout**: Marketer creating `payout_requests/{id}` with `status: "paid"` or updating `status` from `"pending"` to `"paid"`.
9. **Marketer Self-Activation / Balance Inflation**: User creating `marketers/{uid}` with `status: "active"` or updating `availableBalance: 50000`.
10. **ID Poisoning**: Creating a document with a 500-character ID or invalid path characters (`../admin`).
11. **Timestamp Forgery**: Creating or updating a document with a backdated client timestamp (`createdAt != request.time`).
12. **Customer Commission Manipulation**: Customer updating `commissions/{id}` to mark it `"eligible"` or `"paid"`.
13. **Uneligible / Duplicate Trip Review**: User creating `trip_reviews/{id}` without a `completed` booking for that exact `tripId` or using a non-deterministic ID to duplicate reviews.
14. **Cross-User Platform Review Tampering**: User B attempting to read, create, or overwrite `platform_reviews/{userA}`.
15. **Contact Request PII Exposure / Status Forgery**: Non-admin or unauthenticated user attempting `get`/`list`/`update` on `contact_requests/{id}`, or submitting `status: "completed"` or malformed phone numbers on creation.
16. **Currency Mismatch / SAR-as-EGP Booking Spoof**: User creating a booking with `currency: "SAR"` or booking a trip whose `trips/{tripId}.currency` has not been approved as `"EGP"` by Admin.

