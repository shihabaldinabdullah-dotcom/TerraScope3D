import { expect, test } from '@playwright/test';

test.describe('REHHAL Redesigned UX, EGP Currency, Footer & Core Systems E2E Suite', () => {
  test('TEST 1: Top Navbar, clean HeroSlider without duplicate strip, EGP-only HomePage, Footer grouping & Contact Modal', async ({ page }) => {
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.goto('/');

    // Top bar contains expected links and zero Marketer links
    const header = page.locator('header');
    await expect(header.getByRole('link', { name: 'الرئيسية' })).toBeVisible();
    await expect(header.getByRole('link', { name: 'برامج الحج والعمرة' })).toBeVisible();
    await expect(header.getByRole('link', { name: 'الرحلات', exact: true })).toBeVisible();
    await expect(header.getByRole('link', { name: 'حجوزاتي' })).toBeVisible();
    await expect(header.getByRole('link', { name: 'تواصل معنا' })).toBeVisible();
    await expect(page.locator('header a[href^="/partners"]')).toHaveCount(0);
    await expect(page.locator('footer a[href^="/partners"]')).toHaveCount(0);
    await expect(page.getByRole('link', { name: /سجّل كمسوّق/ })).toHaveCount(0);

    // Hero Slider is visible without the removed duplicate metadata/price strip
    const sliderSection = page.getByRole('region', { name: 'الرحلات المختارة' });
    await expect(sliderSection).toBeVisible();
    await expect(sliderSection.getByText(/24,900/)).toHaveCount(0);
    await expect(sliderSection.getByText(/ر\.س/)).toHaveCount(0);

    const initialSlideTitle = await sliderSection.locator('h1').textContent();
    await sliderSection.getByRole('button', { name: 'الشريحة التالية' }).click();
    const nextSlideTitle = await sliderSection.locator('h1').textContent();
    expect(nextSlideTitle).not.toEqual(initialSlideTitle);

    await expect(sliderSection.getByRole('link', { name: 'احجز الآن' })).toBeVisible();
    await expect(sliderSection.getByRole('link', { name: 'التفاصيل' })).toBeVisible();

    // Strict Homepage Copy & Currency Integrity:
    // Zero SAR/ر.س, zero minimum age copy, zero priority tier labels
    const bodyText = await page.locator('body').innerText();
    expect(bodyText).not.toMatch(/ر\.س|\bSAR\b/);
    expect(bodyText).not.toContain('الحد الأدنى للعمر');
    expect(bodyText).not.toContain('التخصص الأساسي');
    expect(bodyText).not.toContain('برامج العمرة المميزة');
    expect(bodyText).not.toContain('الأولوية');

    // Homepage Vertical Hierarchy: Slider -> اختار رحلة -> Leisure -> Brief About
    const hajjUmrahHeading = page.getByRole('heading', { name: 'اختار رحلة' });
    const leisureHeading = page.getByRole('heading', { name: 'الرحلات الترفيهية' });
    const aboutHeading = page.getByRole('heading', { name: /رحلة منظمة وواضحة/ });
    await expect(hajjUmrahHeading).toBeVisible();
    await expect(
      page.getByText('رحلتك المميزة تبدأ باختيارك، اكتشف برامج الحج والعمرة واختر الرحلة المناسبة لك، واترك لنا الاهتمام بباقي التفاصيل.')
    ).toBeVisible();
    await expect(leisureHeading).toBeVisible();
    await expect(aboutHeading).toBeVisible();

    // Zero homepage reviews clutter
    await expect(page.getByRole('heading', { name: /تقييم/ })).toHaveCount(0);

    const sliderBox = await sliderSection.boundingBox();
    const hajjBox = await hajjUmrahHeading.boundingBox();
    const leisureBox = await leisureHeading.boundingBox();
    const aboutBox = await aboutHeading.boundingBox();
    expect(sliderBox && hajjBox && leisureBox && aboutBox).toBeTruthy();
    expect(sliderBox!.y).toBeLessThan(hajjBox!.y);
    expect(hajjBox!.y).toBeLessThan(leisureBox!.y);
    expect(leisureBox!.y).toBeLessThan(aboutBox!.y);

    // Footer is cleanly organized into "روابط المنصة" and "المساعدة والتواصل" without duplicated navbar links
    const footer = page.locator('footer');
    await expect(footer.getByRole('heading', { name: 'روابط المنصة' })).toBeVisible();
    await expect(footer.getByRole('heading', { name: 'المساعدة والتواصل' })).toBeVisible();
    await expect(footer.getByRole('link', { name: 'من نحن' })).toBeVisible();
    await expect(footer.getByRole('link', { name: 'سياسة الخصوصية' })).toBeVisible();
    await expect(footer.getByRole('link', { name: 'الشروط والأحكام' })).toBeVisible();

    // No duplicated top/bottom navbar links in footer
    await expect(footer.getByRole('link', { name: 'الرئيسية' })).toHaveCount(0);
    await expect(footer.getByRole('link', { name: 'برامج الحج والعمرة' })).toHaveCount(0);
    await expect(footer.getByRole('link', { name: 'الرحلات' })).toHaveCount(0);
    await expect(footer.getByRole('link', { name: 'تواصل معنا' })).toHaveCount(0);

    // Footer uses Contact Request Modal instead of direct wa.me chat launch
    await expect(footer.locator('a[href^="https://wa.me/"]')).toHaveCount(0);
    await expect(footer.getByRole('button', { name: 'اطلب التواصل', exact: true })).toBeVisible();
    const waRequestBtn = footer.getByRole('button', { name: 'اطلب التواصل عبر واتساب' });
    await expect(waRequestBtn).toBeVisible();

    // Clicking "اطلب التواصل عبر واتساب" opens Contact Request modal (not direct WhatsApp)
    await waRequestBtn.click();
    const modal = page.getByRole('dialog');
    await expect(modal).toBeVisible();
    await expect(modal.getByRole('heading', { name: 'اطلب التواصل مع فريق رحّال' })).toBeVisible();
    await expect(modal.getByLabel('الاسم *')).toBeVisible();
    await expect(modal.getByLabel('رقم الهاتف *')).toBeVisible();
    await expect(modal.getByRole('button', { name: 'واتساب' })).toBeVisible();
    await expect(modal.getByRole('button', { name: 'اتصال هاتفي' })).toBeVisible();
    await modal.getByLabel('الاسم *').fill('أحمد الاختبار');
    await modal.getByLabel('رقم الهاتف *').fill('123');
    await modal.getByRole('button', { name: 'إرسال طلب التواصل' }).click();
    await expect(modal.getByRole('alert')).toContainText('يرجى إدخال رقم هاتف صحيح');
    await modal.getByRole('button', { name: 'إغلاق نافذة طلب التواصل' }).click();
    await expect(modal).toHaveCount(0);

    // Navigate via HeroSlider 'التفاصيل' button to exact trip detail page
    await sliderSection.getByRole('link', { name: 'التفاصيل' }).click();
    await expect(page).toHaveURL(/\/trip\//);

    const detailBody = await page.locator('body').innerText();
    expect(detailBody).not.toMatch(/ر\.س|\bSAR\b/);

    // Non-eligible visitor sees Trip Reviews section policy notice, never a submission form
    await expect(page.getByRole('heading', { name: 'تقييمات المشاركين في الرحلة' })).toBeVisible();
    await expect(page.getByText('التقييم متاح فقط للمشاركين الذين أتمّوا حجزهم لهذه الرحلة.')).toBeVisible();
    await expect(page.getByRole('button', { name: 'نشر تقييم الرحلة' })).toHaveCount(0);

    // Desktop zero horizontal overflow
    const desktopOverflow = await page.evaluate(
      () => document.documentElement.scrollWidth > window.innerWidth
    );
    expect(desktopOverflow).toBe(false);
  });

  test('TEST 2: Standalone About, Privacy, Terms & Trips pages render cleanly without SAR or priority labels', async ({ page }) => {
    await page.goto('/about');
    await expect(page.getByRole('heading', { name: /منصة رحّال/ })).toBeVisible();

    await page.goto('/privacy');
    await expect(page.getByRole('heading', { name: 'سياسة الخصوصية' })).toBeVisible();

    await page.goto('/terms');
    await expect(page.getByRole('heading', { name: 'الشروط والأحكام' })).toBeVisible();

    await page.goto('/trips?category=pilgrimage');
    await expect(page.getByRole('heading', { name: 'برامج الحج والعمرة' })).toBeVisible();
    const tripsBody = await page.locator('body').innerText();
    expect(tripsBody).not.toMatch(/ر\.س|\bSAR\b/);
    expect(tripsBody).not.toContain('الأولوية:');
    await expect(page.locator('select[aria-label="ترتيب الرحلات"] option[value="featured"]')).toHaveText(
      'الترتيب الافتراضي'
    );
  });

  test('TEST 3 & 12: Protected routes redirect to login preserving target path', async ({ page }) => {
    await page.goto('/my-bookings');
    await expect(page).toHaveURL(/\/login\?redirect=%2Fmy-bookings/);
    await page.goto('/admin');
    await expect(page).toHaveURL(/\/login\?redirect=%2Fadmin/);
    await page.goto('/admin/reviews');
    await expect(page).toHaveURL(/\/login\?redirect=%2Fadmin%2Freviews/);
    await page.goto('/admin/contacts');
    await expect(page).toHaveURL(/\/login\?redirect=%2Fadmin%2Fcontacts/);
    await page.goto('/partners/dashboard');
    await expect(page).toHaveURL(/\/login\?redirect=%2Fpartners%2Fdashboard/);
    await page.goto('/profile');
    await expect(page).toHaveURL(/\/login\?redirect=%2Fprofile/);
  });

  test('TEST 4, 9 & 11: Referral deep links work across navigation, reload, browser history, Contact Modal & login redirect', async ({ page }) => {
    await page.goto('/trip/umrah-makkah-madinah-signature?ref=REHHAL101');
    await expect(page.getByText('REHHAL101').first()).toBeVisible();

    await page.goto('/trip/alula-sanctuary?ref=REHHAL101');
    await expect(page.getByText('REHHAL101').first()).toBeVisible();

    await page.reload();
    await expect(page).toHaveURL(/\/trip\/alula-sanctuary\?ref=REHHAL101/);
    await expect(page.getByText('REHHAL101').first()).toBeVisible();

    await page.getByRole('link', { name: 'الرحلات', exact: true }).first().click();
    await expect(page).toHaveURL(/\/trips/);
    await expect(page.getByText('REHHAL101').first()).toBeVisible();

    await page.goBack();
    await expect(page).toHaveURL(/\/trip\/alula-sanctuary\?ref=REHHAL101/);

    // Trip detail inquiry uses Contact Request Modal instead of direct wa.me
    await expect(page.locator('a[href^="https://wa.me/"]')).toHaveCount(0);
    await page.getByRole('button', { name: 'اطلب التواصل عبر واتساب' }).first().click();
    await expect(page.getByRole('dialog')).toBeVisible();
    await page.getByRole('button', { name: 'إغلاق نافذة طلب التواصل' }).click();

    await page.getByRole('button', { name: /تسجيل الدخول/ }).first().click();
    await expect(page).toHaveURL(/\/login\?redirect=/);
    await expect(page.getByText('REHHAL101').first()).toBeVisible();
  });

  test('TEST 5-8: Server-side referral verification, deduplication, tamper rejection, and online payment authorization', async ({ request }) => {
    const uniqueSession = `pw_sess_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const track1 = await request.post('/api/referrals/track', {
      data: { code: 'REHHAL101', tripId: 'umrah-makkah-madinah-signature', sessionKey: uniqueSession },
    });
    expect(track1.ok()).toBeTruthy();
    const d1 = await track1.json();
    expect(d1.valid).toBe(true);
    expect(d1.marketerId).toBe('partner_demo_101');
    expect(d1.deduplicated).toBe(false);

    const track2 = await request.post('/api/referrals/track', {
      data: { code: 'REHHAL101', tripId: 'umrah-makkah-madinah-signature', sessionKey: uniqueSession },
    });
    const d2 = await track2.json();
    expect(d2.deduplicated).toBe(true);

    const tamperRes = await request.post('/api/referrals/verify', {
      data: {
        code: 'REHHAL101',
        marketerId: 'attacker_uid',
        signature: d1.signature,
        currentUserId: 'customer_1',
      },
    });
    expect(tamperRes.status()).toBe(403);

    const selfRefRes = await request.post('/api/referrals/verify', {
      data: {
        code: 'REHHAL101',
        marketerId: 'partner_demo_101',
        signature: d1.signature,
        currentUserId: 'partner_demo_101',
      },
    });
    expect(selfRefRes.status()).toBe(403);

    const unauthPayRes = await request.post('/api/payments/authorize', {
      data: { bookingId: 'bkg_test_1', amount: 4950, currency: 'EGP', paymentMethod: 'mada', userId: 'cust_1' },
    });
    expect(unauthPayRes.status()).toBe(401);

    const unauthRegisterRes = await request.post('/api/referrals/register', {
      data: { code: 'SPOOF', marketerId: 'attacker', marketerName: 'Attacker', commissionRate: 0.35 },
    });
    expect(unauthRegisterRes.status()).toBe(401);
  });

  test('TEST 10 & PWA Readiness: manifest.webmanifest, SW registration, Offline Mode, Install UI, AssetLinks, 404, Console clean & Mobile 375px', async ({ page, context, request }) => {
    const consoleErrors: string[] = [];
    const failedAssets: string[] = [];
    page.on('console', (msg) => {
      if (msg.type() === 'error') consoleErrors.push(msg.text());
    });
    page.on('response', (res) => {
      if (res.status() >= 400 && !res.url().includes('non-existent-route-check')) {
        failedAssets.push(`${res.status()} ${res.url()}`);
      }
    });

    const manifestRes = await request.get('/manifest.webmanifest');
    expect(manifestRes.ok()).toBeTruthy();
    expect(manifestRes.headers()['content-type']).toContain('application/manifest+json');
    expect(manifestRes.headers()['x-content-type-options']).toBe('nosniff');
    const manifest = await manifestRes.json();
    expect(manifest.name).toBe('رحّال REHHAL');
    expect(manifest.short_name).toBe('رحّال');
    expect(manifest.dir).toBe('rtl');
    expect(manifest.lang).toBe('ar');
    expect(manifest.display).toBe('standalone');
    expect(manifest.start_url).toBe('/');
    expect(manifest.scope).toBe('/');
    expect(manifest.theme_color).toBe('#0B172A');
    expect(manifest.background_color).toBe('#0B172A');
    expect(manifest.icons.length).toBeGreaterThanOrEqual(3);
    expect(JSON.stringify(manifest.shortcuts)).not.toContain('/partners/dashboard');

    const swRes = await request.get('/service-worker.js');
    expect(swRes.ok()).toBeTruthy();
    expect(swRes.headers()['content-type']).toContain('javascript');

    const offlineRes = await request.get('/offline.html');
    expect(offlineRes.ok()).toBeTruthy();

    const assetLinksRes = await request.get('/.well-known/assetlinks.json');
    expect(assetLinksRes.ok()).toBeTruthy();
    expect(assetLinksRes.headers()['content-type']).toContain('application/json');

    await page.goto('/');
    // Verify manifest link in DOM & SW registration active
    await expect(page.locator('link[rel="manifest"]')).toHaveAttribute('href', '/manifest.webmanifest');
    const swReady = await page.evaluate(async () => {
      if (!('serviceWorker' in navigator)) return false;
      const reg = await navigator.serviceWorker.ready;
      return Boolean(reg && reg.active);
    });
    expect(swReady).toBe(true);

    // Install button is moved to top header beside login and opens cross-platform install modal when clicked
    await expect(page.locator('footer').getByRole('button', { name: /تثبيت/ })).toHaveCount(0);
    const headerInstallBtn = page.locator('header').getByRole('button', { name: /تثبيت/ });
    await expect(headerInstallBtn).toBeVisible();
    await headerInstallBtn.click();
    await expect(page.getByRole('dialog')).toBeVisible();
    await page.getByRole('button', { name: 'فهمت ذلك' }).click();

    // Simulate Offline transition in browser and check Offline Indicator banner
    await context.setOffline(true);
    await page.evaluate(() => window.dispatchEvent(new Event('offline')));
    await expect(page.getByRole('alert')).toContainText('وضع عدم الاتصال');
    await context.setOffline(false);
    await page.evaluate(() => window.dispatchEvent(new Event('online')));

    await page.goto('/non-existent-route-check');
    await expect(page.getByText('404')).toBeVisible();

    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/');
    const hasHorizontalOverflow = await page.evaluate(
      () => document.documentElement.scrollWidth > window.innerWidth
    );
    expect(hasHorizontalOverflow).toBe(false);

    // Mobile HeroSlider title and primary CTA fit within viewport cleanly
    const mobileSlider = page.getByRole('region', { name: 'الرحلات المختارة' });
    await expect(mobileSlider.locator('h1')).toBeVisible();
    await expect(mobileSlider.getByRole('link', { name: 'احجز الآن' })).toBeVisible();
    await expect(mobileSlider.getByRole('link', { name: 'التفاصيل' })).toBeVisible();

    // Mobile bottom bar uses "الرحلات" linking directly to /trips
    const bottomNav = page.getByRole('navigation', { name: 'التنقل السفلي للهاتف' });
    await expect(bottomNav.getByRole('link', { name: 'الحج والعمرة' })).toHaveCount(0);
    const mobileTripsLink = bottomNav.getByRole('link', { name: 'الرحلات' });
    await expect(mobileTripsLink).toBeVisible();
    await mobileTripsLink.click();
    await expect(page).toHaveURL(/\/trips$/);

    // Zero critical console/asset failures on REHHAL routes
    expect(failedAssets.filter((e) => !e.includes('firestore.googleapis.com'))).toEqual([]);
    expect(consoleErrors.filter((e) => !e.includes('ERR_INTERNET_DISCONNECTED') && !e.includes('WebSocket'))).toEqual([]);
  });
});

